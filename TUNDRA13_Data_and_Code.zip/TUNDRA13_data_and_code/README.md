# TUNDRA13 data and code

This package contains the data, code and figures for the analysis of vegetation associations across 13 Arctic tundra regions.

## Files

- `data/` contains the source tables, model inputs, predictions and supplementary data. `DATA_MANIFEST.csv` lists the files for Supplementary Data D1–D11.
- `code/` contains the model code, geospatial and supplementary analysis scripts, and their original helper scripts in `code/dependencies/`.
- `figures/` contains the four main figures and Supplementary Fig. S1.
- `SHA256SUMS.csv` lists file checksums.

## Running the model check

The model check uses the supplied analysis-ready data. It requires Python and the packages listed in `requirements.txt`.

```sh
python -m pip install -r requirements.txt
python code/reproduce.py check
```

The check writes its outputs to a separate `reproduced_results/` directory. The method scripts retain their original input paths and dependencies; they are not a single runnable GIS workflow.

The original data products and their identifiers are listed in `data/package_metadata.json`. Third-party data remain subject to their providers' terms.
