"""Final regional composition models; numerical functions from the paper analysis."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize, brentq
from scipy.special import logsumexp, expit
CATS = ['GRASS_HERBACEOUS','SHRUB','MOSS_LICHEN','FOREST','WETLAND','SPARSE_BARE']
MODELS = ['A','B_equal','B_object','C','D']
PAIRS = [('C','B_equal'),('C','B_object'),('C','D'),('C','A'),('D','A'),('B_equal','A'),('B_object','A')]
SEED = 20261407
EPS = 1e-12
def fit_c(q,y):
    n=y.sum(axis=1)
    if len(n)!=12 or np.any(n<=0) or np.any((q==0)&(y>0)): raise ValueError('nonestimable training support')
    s=y/n[:,None]
    lq=np.full_like(q,-np.inf); np.log(q,out=lq,where=q>0)
    def fg(x):
        beta=np.r_[0.,x]; z=lq+beta
        lp=z-logsumexp(z,axis=1,keepdims=True); p=np.exp(lp)
        loss=-np.mean(np.sum(s*np.where(s>0,lp,0),axis=1))
        grad=np.mean(p-s,axis=0)[1:]
        return float(loss),grad
    res=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':1000})
    _,g=fg(res.x)
    if not np.isfinite(res.x).all() or np.max(np.abs(g))>2e-6: raise ValueError('C gradient gate failed')
    return np.r_[0.,res.x],float(np.max(np.abs(g)))

def predict(q,b):
    lq=np.full(6,-np.inf); np.log(q,out=lq,where=q>0)
    z=lq+b
    return np.exp(z-logsumexp(z))

def fit_d(q,y):
    n=y.sum(axis=1)
    if len(n)!=12 or np.any(n<=0): raise ValueError('D nonestimable training support')
    grass=y[:,0]/n; x=q[:,0]
    mix=(x>0)&(x<1)
    offsets=np.log(x[mix])-np.log1p(-x[mix])
    def grad(theta):
        predicted=x.copy(); predicted[mix]=expit(offsets+theta)
        return float(np.mean(predicted-grass))
    if not mix.any() or grad(-80)*grad(80)>=0: raise ValueError('D finite weight not identifiable')
    theta=brentq(grad,-80,80,xtol=1e-12)
    return theta,abs(grad(theta))

def score(s,p):
    active=s>0
    raw=float(np.sum(s[active]*np.log(p[active]))) if np.all(p[active]>0) else -np.inf
    return raw

def evaluate(q,y,ids):
    n=y.sum(axis=1)
    if np.any(n<=0) or np.any((q==0)&(y>0)): raise ValueError('zero observed total or q zero with positive RTS')
    rows=[]; predictions=[]; parameters=[]
    for t,cid in enumerate(ids):
        tr=np.arange(13)!=t; train_y=y[tr]; obs=y[t]/n[t]; support=q[t]>0
        b,grad=fit_c(q[tr],train_y); theta,dgrad=fit_d(q[tr],train_y)
        raw={
            'A':q[t].copy(),
            'B_equal':np.mean(train_y/train_y.sum(axis=1)[:,None],axis=0),
            'B_object':train_y.sum(axis=0)/train_y.sum(),
            'C':predict(q[t],b),
            'D':predict(q[t],np.r_[theta,np.zeros(5)])}
        parameters.append({'coverage_id':cid,'training_coverage_n':12,'training_RTS_n':int(train_y.sum()),
                           'D_log_grass_weight':theta,'D_grass_weight':float(np.exp(theta)),
                           'C_max_abs_gradient':grad,'D_abs_gradient':dgrad,
                           **{f'C_beta_{c}':float(b[k]) for k,c in enumerate(CATS)}})
        for name in MODELS:
            p=raw[name].copy(); retained=float(p[support].sum())
            if retained<=0: raise ValueError('zero predicted mass on target support')
            p[~support]=0.; p/=retained
            smooth=(1-EPS)*p+EPS*support/support.sum()
            tv=float(.5*np.abs(obs-p).sum())
            rows.append({'coverage_id':cid,'model':name,'heldout_RTS_n':int(n[t]),
                         'training_RTS_n':int(train_y.sum()),'training_coverage_n':12,
                         'supported_class_n':int(support.sum()),'support_mass_before_normalization':retained,
                         'TV':tv,'logscore_nats_per_RTS':score(obs,smooth),'raw_logscore_nats_per_RTS':score(obs,p),
                         **{f'q_{c}':float(q[t,k]) for k,c in enumerate(CATS)},
                         **{f'y_{c}':int(y[t,k]) for k,c in enumerate(CATS)},
                         **{f'observed_{c}':float(obs[k]) for k,c in enumerate(CATS)},
                         **{f'predicted_{c}':float(p[k]) for k,c in enumerate(CATS)}})
            predictions.append(p)
    df=pd.DataFrame(rows); paired=[]
    for cid in ids:
        d=df[df.coverage_id.eq(cid)].set_index('model')
        for candidate,baseline in PAIRS:
            delta=float(d.loc[baseline,'TV']-d.loc[candidate,'TV'])
            paired.append({'coverage_id':cid,'comparison':candidate+'_vs_'+baseline,
                           'delta_TV':delta,
                           'delta_logscore_nats_per_RTS':float(d.loc[candidate,'logscore_nats_per_RTS']-d.loc[baseline,'logscore_nats_per_RTS']),
                           'G_vs_baseline':delta/d.loc[baseline,'TV'] if d.loc[baseline,'TV']>0 else np.nan})
    return df,pd.DataFrame(paired),pd.DataFrame(parameters)

def advance_legacy_object_stream(rng,y):
    sampled=rng.integers(0,13,size=13)
    for target in np.unique(sampled):
        draw=rng.choice([j for j in range(13) if j!=target],size=12,replace=True)
        for j in draw:
            n=int(y[j].sum()); rng.multinomial(n,y[j]/n)
        n=int(y[target].sum()); rng.multinomial(n,y[target]/n)

def summarize(point,boot,model=False):
    rows=[]; group='model' if model else 'comparison'
    metrics=['TV','logscore_nats_per_RTS'] if model else ['delta_TV','delta_logscore_nats_per_RTS','G_vs_baseline']
    for name,d in point.groupby(group,sort=False):
        bd=boot[boot[group].eq(name)]
        for metric in metrics:
            for stat in ['mean','median']:
                fn=np.mean if stat=='mean' else np.median
                v=float(fn(d[metric])); vals=bd.groupby('replicate')[metric].agg(stat).to_numpy(float)
                rows.append({group:name,'metric':metric,'statistic':stat,'point':v,
                             'bootstrap_center':float(np.median(vals)),
                             'ci025':float(np.quantile(vals,.025)),'ci975':float(np.quantile(vals,.975)),
                             'bootstrap_positive_fraction':float(np.mean(vals>0)),
                             'positive_region_n':int((d[metric]>0).sum()) if not model else np.nan,
                             'replicates_finite_n':len(vals)})
    return pd.DataFrame(rows)
