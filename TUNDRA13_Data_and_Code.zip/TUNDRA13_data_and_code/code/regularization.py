"""Centered six-category penalty used in SM16; all three strengths retained."""
import numpy as np
import pandas as pd
from scipy.optimize import minimize, brentq
from scipy.special import logsumexp, expit
SIGMAS = np.array([10.,5.,2.5])
LABELS = ['sigma_10','sigma_5','sigma_2p5']
CATS = ['GRASS_HERBACEOUS','SHRUB','MOSS_LICHEN','FOREST','WETLAND','SPARSE_BARE']
EPS = 1e-12
P = np.eye(5)-np.ones((5,5))/6
def logq(q):
    z=np.full_like(q,-np.inf); np.log(q,out=z,where=q>0); return z

def fit_batch(q,y):
    """42 joint jobs: 3 fixed sigmas x (13 LOCO fits + one all-region fit)."""
    s=y/y.sum(axis=1,keepdims=True)
    masks=np.vstack([1-np.eye(13),np.ones((1,13))])
    masks=np.tile(masks,(3,1)); lam=np.repeat(1/SIGMAS**2,14)
    lq=logq(q)[None,:,:]
    def objective(x,deriv=False):
        beta=np.column_stack([np.zeros(len(x)),x]); z=lq+beta[:,None,:]
        lp=z-logsumexp(z,axis=2,keepdims=True); p=np.exp(lp)
        ll=-np.sum(np.sum(s[None,:,:]*np.where(s[None,:,:]>0,lp,0),axis=2)*masks,axis=1)
        loss=ll+.5*lam*np.einsum('ni,ij,nj->n',x,P,x)
        if not deriv: return loss
        g=np.sum((p-s[None,:,:])*masks[:,:,None],axis=1)[:,1:]+lam[:,None]*(x@P)
        pp=p[:,:,1:]
        diag=np.sum(pp*masks[:,:,None],axis=1)
        h=-np.einsum('nri,nrj,nr->nij',pp,pp,masks)+lam[:,None,None]*P
        h[:,np.arange(5),np.arange(5)]+=diag
        return loss,g,h
    x=np.zeros((42,5))
    for it in range(80):
        loss,g,h=objective(x,True)
        active=np.max(np.abs(g),axis=1)>1e-10
        if not active.any(): break
        step=np.linalg.solve(h,g[...,None])[...,0]; step[~active]=0
        t=np.ones(42); gd=np.sum(g*step,axis=1)
        for ls in range(40):
            candidate=x-t[:,None]*step
            ok=objective(candidate)<=loss-1e-4*t*gd+2e-14
            if ok.all(): break
            t[~ok]*=.5
        x=candidate
    loss,g,h=objective(x,True)
    if not np.isfinite(x).all() or np.max(np.abs(g))>2e-7:
        raise RuntimeError('penalized C gradient failed: '+str(np.max(np.abs(g))))
    beta=np.column_stack([np.zeros(42),x]).reshape(3,14,6)
    # D occupies the same six-category log-weight space, with only grass differing.
    a=q[:,0]; mixed=(a>0)&(a<1)
    offsets=np.zeros(13); offsets[mixed]=np.log(a[mixed])-np.log1p(-a[mixed])
    theta=np.zeros(42); lmd=lam*5/6
    for _ in range(80):
        pred=np.broadcast_to(a,(42,13)).copy()
        pred[:,mixed]=expit(offsets[mixed][None,:]+theta[:,None])
        dg=np.sum((pred-s[None,:,0])*masks,axis=1)+lmd*theta
        dh=np.sum(pred*(1-pred)*masks,axis=1)+lmd
        if np.max(np.abs(dg))<1e-10: break
        theta-=np.clip(dg/dh,-5,5)
    if np.max(np.abs(dg))>2e-7: raise RuntimeError('penalized D gradient failed')
    return beta,theta.reshape(3,14),np.max(np.abs(g),axis=1).reshape(3,14),np.abs(dg).reshape(3,14)

def fit_global_unpenalized(q,y):
    s=y/y.sum(axis=1,keepdims=True); lq=logq(q)
    def fg(x):
        z=lq+np.r_[0.,x]; lp=z-logsumexp(z,axis=1,keepdims=True)
        loss=-np.mean(np.sum(s*np.where(s>0,lp,0),axis=1))
        return loss,np.mean(np.exp(lp)-s,axis=0)[1:]
    r=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':1000})
    g=fg(r.x)[1]
    if not np.isfinite(r.x).all() or np.max(np.abs(g))>2e-6:
        raise RuntimeError('unpenalized all-region weight fit failed')
    return np.r_[0.,r.x],float(np.max(np.abs(g)))

def predict_all(q,b):
    z=logq(q)+b; return np.exp(z-logsumexp(z,axis=1,keepdims=True))

def metric_rows(q,y,p,ids,model,rep):
    s=y/y.sum(axis=1,keepdims=True); support=q>0
    p=p.copy(); p[~support]=0; p/=p.sum(axis=1,keepdims=True)
    ps=(1-EPS)*p+EPS*support/support.sum(axis=1,keepdims=True)
    rows=[]
    for i,cid in enumerate(ids):
        active=s[i]>0
        raw=float(np.sum(s[i,active]*np.log(p[i,active]))) if np.all(p[i,active]>0) else -np.inf
        rows.append(dict(replicate=rep,coverage_id=cid,model=model,
            TV=float(.5*np.abs(s[i]-p[i]).sum()),
            logscore_nats_per_RTS=float(np.sum(s[i,active]*np.log(ps[i,active]))),
            raw_logscore_nats_per_RTS=raw,
            min_positive_probability=float(p[i,p[i]>0].min()),
            min_observed_probability=float(p[i,active].min()),
            **{'predicted_'+c:float(p[i,j]) for j,c in enumerate(CATS)}))
    return rows

def paired(df):
    rows=[]
    for label in ['unpenalized']+LABELS:
        cm='C' if label=='unpenalized' else 'C_'+label
        dm='D' if label=='unpenalized' else 'D_'+label
        for cand,ref in [(cm,'A'),(cm,'B_equal'),(cm,'B_object'),(cm,dm),(dm,'A')]:
            a=df[df.model.eq(cand)].set_index(['replicate','coverage_id'])
            b=df[df.model.eq(ref)].set_index(['replicate','coverage_id']).reindex(a.index)
            z=pd.DataFrame({'delta_TV':b.TV-a.TV,
              'delta_logscore_nats_per_RTS':a.logscore_nats_per_RTS-b.logscore_nats_per_RTS,
              'delta_raw_logscore_nats_per_RTS':a.raw_logscore_nats_per_RTS-b.raw_logscore_nats_per_RTS,
              'G':(b.TV-a.TV)/b.TV}).reset_index()
            z['setting']=label; z['comparison']=('D_vs_A' if cand==dm else 'C_vs_'+('D' if ref==dm else ref))
            rows.append(z)
    return pd.concat(rows,ignore_index=True)

def summaries(point,boot,keys,metrics):
    rows=[]
    for name,a in point.groupby(keys,sort=False):
        name=name if isinstance(name,tuple) else (name,)
        mask=np.ones(len(boot),bool)
        for k,v in zip(keys,name): mask &= boot[k].eq(v).to_numpy()
        b=boot[mask]
        for m in metrics:
            for stat in ['mean','median']:
                v=float(getattr(a[m],stat)()); vals=b.groupby('replicate')[m].agg(stat)
                finite=np.isfinite(vals.to_numpy())
                rows.append(dict(zip(keys,name),metric=m,statistic=stat,point=v,
                  ci025=float(vals.quantile(.025)),ci975=float(vals.quantile(.975)),
                  bootstrap_center=float(vals.median()),bootstrap_replicates_n=len(vals),
                  bootstrap_finite_n=int(finite.sum()),bootstrap_positive_fraction=float((vals>0).mean()),
                  positive_regions_n=int((a[m]>0).sum())))
    return pd.DataFrame(rows)
