from pathlib import Path
import csv,json,math
import numpy as np
root=Path(r'E:\zuom\gu\RUNS\ROUND_20260828_01')
work=Path(__file__).parent; checks=work/'checks'
source=root/'RTS_NWT2015_022_EXTERNAL_BLIND_VALIDATION_V1'/'NWT2015_022_ACTIVE_RTS_ASSIGNMENT_V1.csv'
detail=list(csv.DictReader((checks/'NWT_ACTIVE_TRAINING_OVERLAP.csv').open(encoding='utf-8-sig')))
assign=list(csv.DictReader(source.open(encoding='utf-8-sig')))
scored=list(csv.DictReader((root/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'nwt'/'results'/'NWT_TUNDRA13_SCORE_BY_CLASS.csv').open(encoding='utf-8-sig')))
cats=[r['vegetation_class'] for r in scored]
q=np.array([float(r['q_area_only']) for r in scored]); p=np.array([float(r['prediction_shared_TUNDRA13']) for r in scored])
assert abs(q.sum()-1)<1e-12 and abs(p.sum()-1)<1e-12
label_ex={int(r['nwt_source_feature_index']) for r in detail if int(r['training_label_positive_overlap_n'])>0}
scene_ex={int(r['nwt_source_feature_index']) for r in detail if int(r['training_image_positive_overlap_n'])>0}
assert label_ex.issubset(scene_ex)
results=[]
for name,excluded in [('ORIGINAL_FROZEN_SCORE',set()),('EXCLUDE_LABEL_INTERSECTIONS',label_ex),('EXCLUDE_TRAINING_SCENE_INTERSECTIONS',scene_ex)]:
    kept=[r for r in assign if r['community'] in cats and int(r['source_feature_index']) not in excluded]
    removed=[r for r in assign if r['community'] in cats and int(r['source_feature_index']) in excluded]
    n=np.array([sum(r['community']==c for r in kept) for c in cats]); s=n/n.sum()
    a=float(.5*abs(s-q).sum()); b=float(.5*abs(s-p).sum())
    results.append({'diagnostic':name,'n':len(kept),'removed_n':len(removed),'removed_source_indices':[int(r['source_feature_index']) for r in removed],'removed_classes':[r['community'] for r in removed],'TV_area':a,'TV_shared_frozen':b,'G':1-b/a,'G_percent':100*(1-b/a),'counts_by_class':dict(zip(cats,n.tolist()))})
assert abs(results[0]['TV_area']-.2495776058488832)<1e-10
assert len(results[1]['removed_source_indices'])==3 and len(results[2]['removed_source_indices'])==5
out={'evaluation':'post hoc source-overlap exclusion diagnostic; original model weights, target background and saved predictions held fixed; primary results not overwritten','rows':results,'uncertainty':'point scores only; no new confidence intervals computed'}
(checks/'NWT_FROZEN_SCORE_EXCLUSION_CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
