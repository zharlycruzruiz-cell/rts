from __future__ import annotations
import gzip, hashlib, importlib.util, itertools, json, math, time, sys
from pathlib import Path

ROOT=Path(r"E:/zuom/gu"); ROUND=ROOT/"RUNS/ROUND_20260828_01"
SOURCE_OUT=ROUND/"RTS_WORLDCOVER_SHARED_RULE_BLIND_REPLICATION_V1"
OUT=ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"worldcover"/"results"
WC=ROUND/"DARTS16_WORLDCOVER_PRODUCT_SENSITIVITY_V1"
BLIND=ROUND/"RTS_SHARED_RULE_BLIND_RECONSTRUCTION_FINAL_AUDIT_V1"
V1=ROUND/"RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V1/checkpoints"
V2=ROUND/"RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V2/unit_cache"
PRE=ROUND/"RTS_PANARCTIC_CONTINUOUS_STATE_PREFLIGHT_V1/regenerated_background"
IDS=[f"DARTS2023_COV_{i:03d}" for i in [1,3,13,14,17,19,21,22,28,31,32,33,35]]
IDS_NUM=[int(u.rsplit("_",1)[1]) for u in IDS]
CLASSES=["GRASS_HERBACEOUS","SHRUB","MOSS_LICHEN","FOREST","WETLAND","SPARSE_BARE"]
REPS=1000; PAIRED_REPS=10000; LABEL_PERMS=720; SEED=20261007
sys.path.insert(0,str(ROOT/"_localdeps"))
import numpy as np,pandas as pd
from pyproj import Transformer
from scipy.stats import spearmanr

def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def rts_path(i,product):
 uid=f"DARTS2023_COV_{i:03d}"
 if product=="WC":return WC/"worldcover_unit_cache"/f"{uid}_RTS_ASSIGNMENTS.csv"
 return (V1 if i in {1,3,13,14,17,21,22} else V2)/f"{uid}_RTS_ASSIGNMENTS.csv"
def area_grid_path(i):
 return (PRE if i in {1,3,13,14,17,21,22} else V2)/f"DARTS2023_COV_{i:03d}_BACKGROUND_GRID.csv"
def split_gz_by_coverage(src,dest,usecols):
 dest.mkdir(parents=True,exist_ok=True)
 seen=set()
 for ch in pd.read_csv(src,usecols=usecols,chunksize=250000):
  for cov,sub in ch.groupby("coverage_id",sort=False):
   if cov not in IDS: continue
   p=dest/f"{cov}.csv.gz"; first=not p.exists()
   sub.to_csv(p,index=False,mode="wt" if first else "at",header=first,compression="gzip")
   seen.add(cov)
 return seen
def block_id(lon,lat):
 tr=Transformer.from_crs(4326,6933,always_xy=True);x,y=tr.transform(np.asarray(lon,float),np.asarray(lat,float))
 bx=np.floor(np.asarray(x)/25000).astype(int);by=np.floor(np.asarray(y)/25000).astype(int)
 return np.char.add(np.char.add("25_",bx.astype(str)),np.char.add("_",by.astype(str))),bx,by
def read_rts(i,product):
 d=pd.read_csv(rts_path(i,product))
 if product=="WC":
  needed=["rts_id","centroid_lon","centroid_lat","worldcover_community","worldcover_ring_pixel_n","worldcover_valid_pixel_n"]
  d=d[needed].copy();d=d.rename(columns={"worldcover_community":"community"})
 else:
  d=d[["rts_id","centroid_lon","centroid_lat","community","ring_pixel_n","raw_valid_pixel_n"]].copy()
  d=d.rename(columns={"ring_pixel_n":"ring_pixel_n","raw_valid_pixel_n":"valid_pixel_n"})
 if d.rts_id.astype(str).duplicated().any():raise RuntimeError(f"duplicate RTS id {product} {IDS[IDS_NUM.index(i)]}")
 d["rts_id"]=d.rts_id.astype(str)
 bid,bx,by=block_id(d.centroid_lon,d.centroid_lat);d["block_id"]=bid;d["block_x"]=bx;d["block_y"]=by
 return d
def qblock_from_rows(df,community_col="worldcover_community"):
 uni=sorted(df.block_id.unique())
 x=(df[df[community_col].isin(CLASSES)].pivot_table(index="block_id",columns=community_col,values="coverage_intersection_area_m2",aggfunc="sum",fill_value=0).reindex(index=uni,columns=CLASSES,fill_value=0))
 return uni,x.to_numpy(float)
def yblock_from_rts(d,valid_ids):
 d=d[d.community.isin(CLASSES)].copy()
 unknown=set(d.block_id)-set(valid_ids)
 if unknown:raise RuntimeError(f"RTS assigned outside background block universe {list(unknown)[:3]}")
 x=pd.crosstab(d.block_id,d.community).reindex(index=valid_ids,columns=CLASSES,fill_value=0)
 return x.to_numpy(float)
def qnormalize(qraw):
 s=qraw.sum(axis=1)
 out=np.divide(qraw,s[:,None],out=np.zeros_like(qraw,dtype=float),where=s[:,None]>0)
 if not np.isfinite(out).all():raise RuntimeError("invalid q matrix")
 return out
def metrics(y,q,p):
 n=float(y.sum());obs=y/n if n>0 else np.zeros_like(y)
 ta=float(.5*np.abs(obs-q).sum());tb=float(.5*np.abs(obs-p).sum());g=(1-tb/ta) if ta>1e-12 else np.nan
 def ll(prob):
  bad=(prob<=0)&(y>0)
  return -np.inf if bad.any() else float(np.sum(y[y>0]*np.log(prob[y>0])))
 la=ll(q);lb=ll(p)
 d=(lb-la)/n if np.isfinite(la) and np.isfinite(lb) else (np.inf if np.isneginf(la) and np.isfinite(lb) else np.nan)
 return {"n_RTS":int(n),"TV_A":ta,"TV_B":tb,"delta_TV":ta-tb,"G":g,"G_status":"SMALL_DENOMINATOR" if ta<=1e-12 else "SCORABLE","LL_A":la,"LL_B":lb,"delta_LL_nats_per_RTS":d,"ll_support_status":"ZERO_SUPPORT" if not np.isfinite(la) or not np.isfinite(lb) else "FINITE"}
def fit_predict(model,qmat,ymat):
 out=[]
 for i,cov in enumerate(IDS):
  train=[j for j in range(len(IDS)) if j!=i]
  beta,info=model.fit_beta(qmat[train],ymat[train],"coverage_equal")
  pred=model.softmax_q_beta(qmat[i],beta)
  out.append((beta,pred,info))
 return out
def upper_corr(a,b):
 ix=np.triu_indices(a.shape[0],1);v=spearmanr(a[ix],b[ix]).statistic
 return float(v) if np.isfinite(v) else np.nan
def dmat(x):return .5*np.abs(x[:,None,:]-x[None,:,:]).sum(axis=2)
def main():
 t0=time.time();model=load("blind_shared_model",BLIND/"scripts/03_run_blind_reconstruction.py")
 # Split compressed anchor assignments into auditable per-coverage support files.
 wcdir=OUT/"work_wc_q_by_coverage";cdir=OUT/"work_cgls_q_by_coverage"
 if not all((wcdir/f"{u}.csv.gz").exists() for u in IDS):
  seen=split_gz_by_coverage(SOURCE_OUT/"WORLDCOVER_BACKGROUND_GRID_ASSIGNMENTS_V1.csv.gz",wcdir,["coverage_id","grid_id","center_lon","center_lat","coverage_intersection_area_m2","worldcover_community","worldcover_support_status","block_id"])
  if seen!=set(IDS):raise RuntimeError(f"WC q split coverage mismatch {seen}")
 if not all((cdir/f"{u}.csv.gz").exists() for u in IDS):
  seen=split_gz_by_coverage(BLIND/"Q_BACKGROUND_GRID_INDEPENDENT.csv.gz",cdir,["coverage_id","grid_id","center_lon","center_lat","coverage_intersection_area_m2","community"])
  if seen!=set(IDS):raise RuntimeError(f"CGLS q split coverage mismatch {seen}")

 # Load product-native RTS classes only after independent WorldCover q has been completed and audited.
 rts_wc={};rts_cg={};qwc_raw={};qcg_raw={};ids_wc_bg={};ids_cg_bg={};block_wc={};block_cg={}
 sample_rows=[];qrows=[];common_qrows=[];common_rts={};native_wcy=[];native_cgy=[]
 # Each coverage is processed separately so common-support matching is by frozen grid_id/object ID.
 for i,cov in zip(IDS_NUM,IDS):
  wd=pd.read_csv(wcdir/f"{cov}.csv.gz");cd=pd.read_csv(cdir/f"{cov}.csv.gz")
  if wd.grid_id.astype(str).duplicated().any() or cd.grid_id.astype(str).duplicated().any():raise RuntimeError(f"duplicate background ID {cov}")
  wd["grid_id"]=wd.grid_id.astype(str);cd["grid_id"]=cd.grid_id.astype(str)
  if len(wd)!=len(cd) or set(wd.grid_id)!=set(cd.grid_id):raise RuntimeError(f"background anchor universe mismatch {cov}")
  # Product-native q uses each product's six-class-valid anchors only.
  wb=wd[wd.worldcover_community.isin(CLASSES)].copy();cb=cd[cd.community.isin(CLASSES)].copy()
  aw=wb.groupby("worldcover_community").coverage_intersection_area_m2.sum().reindex(CLASSES,fill_value=0).to_numpy(float)
  ac=cb.groupby("community").coverage_intersection_area_m2.sum().reindex(CLASSES,fill_value=0).to_numpy(float)
  if aw.sum()<=0 or ac.sum()<=0:raise RuntimeError(f"no six-class q support {cov}")
  qwc_raw[cov]=aw; qcg_raw[cov]=ac
  qrows.append({"coverage_id":cov,"WC_six_class_area_m2":aw.sum(),"CGLS_six_class_area_m2":ac.sum(),**{f"q_WC_{c}":aw[k]/aw.sum() for k,c in enumerate(CLASSES)},**{f"q_CGLS_{c}":ac[k]/ac.sum() for k,c in enumerate(CLASSES)}})
  # Identical anchor IDs with valid six-class support in both products.
  common_bg=wb[["grid_id","center_lon","center_lat","coverage_intersection_area_m2","worldcover_community","block_id"]].merge(
   cb[["grid_id","community"]],on="grid_id",how="inner",validate="one_to_one")
  common_bg=common_bg.rename(columns={"community":"cgls_community"})
  ids_wc_bg[cov]=set(wb.grid_id);ids_cg_bg[cov]=set(cb.grid_id)
  common_qrows.append({"coverage_id":cov,"WC_valid_six_anchor_n":len(wb),"CGLS_valid_six_anchor_n":len(cb),"common_valid_six_anchor_n":len(common_bg),"common_fraction_of_fixed_anchors":len(common_bg)/len(wd),"common_fraction_of_WC_valid":len(common_bg)/len(wb) if len(wb) else np.nan,"common_fraction_of_CGLS_valid":len(common_bg)/len(cb) if len(cb) else np.nan,"common_WC_six_area_m2":float(common_bg.loc[common_bg.worldcover_community.isin(CLASSES),"coverage_intersection_area_m2"].sum()),"common_CGLS_six_area_m2":float(common_bg.loc[common_bg.cgls_community.isin(CLASSES),"coverage_intersection_area_m2"].sum())})

  rw=read_rts(i,"WC");rc=read_rts(i,"CGLS");rts_wc[cov]=rw;rts_cg[cov]=rc
  classes_wc=rw.community; classes_cg=rc.community
  counts_wc=classes_wc.value_counts();account={"coverage_id":cov,"input_RTS":len(rw),"valid_six_class_RTS":int(classes_wc.isin(CLASSES).sum()),"excluded_nonvegetation_RTS":int(classes_wc.eq("EXCLUDED_NON_VEGETATION").sum()),"other_RTS":int(classes_wc.eq("OTHER").sum()),"no_data_RTS":int(classes_wc.eq("NO_DATA_SUPPORT").sum()),"unknown_RTS":int(classes_wc.eq("UNKNOWN").sum()),"unsupported_or_missing_RTS":int((~classes_wc.isin(CLASSES+['EXCLUDED_NON_VEGETATION','OTHER','NO_DATA_SUPPORT','UNKNOWN'])).sum()),"CGLS_valid_six_class_RTS":int(classes_cg.isin(CLASSES).sum()),"WC_q_six_class_anchor_n":int(len(wb)),"WC_q_other_anchor_n":int(wd.worldcover_community.eq("OTHER").sum()),"WC_q_excluded_nonvegetation_anchor_n":int(wd.worldcover_community.eq("EXCLUDED_NON_VEGETATION").sum()),"WC_q_no_data_anchor_n":int(wd.worldcover_community.eq("NO_DATA_SUPPORT").sum()),"WC_q_unknown_anchor_n":int(wd.worldcover_community.eq("UNKNOWN").sum()),"WC_q_uses_RTS_exclusion":False}
  for c in CLASSES:account[f"RTS_n_{c}"]=int(counts_wc.get(c,0))
  sample_rows.append(account)
  # Common-support RTS object IDs valid under both products; do not force category equality.
  cwl=rw[["rts_id","centroid_lon","centroid_lat","community"]].rename(columns={"community":"worldcover_community"}).merge(
   rc[["rts_id","community"]].rename(columns={"community":"cgls_community"}),on="rts_id",how="inner",validate="one_to_one")
  cwl=cwl[cwl.worldcover_community.isin(CLASSES)&cwl.cgls_community.isin(CLASSES)].copy()
  common_rts[cov]=cwl
  # Aggregated block support for product-native spatial bootstrap.
  qdf=wd.copy();qdf["block_id"]=qdf.block_id.astype(str); qdf["coverage_intersection_area_m2"]=pd.to_numeric(qdf.coverage_intersection_area_m2)
  bq,qm=qblock_from_rows(qdf)
  yw=yblock_from_rts(rw,bq);yc=yblock_from_rts(rc,bq)
  block_wc[cov]=(bq,qm,yw);block_cg[cov]=(bq,qm,yc)
  native_wcy.append(np.array([int(classes_wc.isin([c]).sum()) for c in CLASSES],dtype=float))
  native_cgy.append(np.array([int(classes_cg.isin([c]).sum()) for c in CLASSES],dtype=float))
 pd.DataFrame(qrows).to_csv(OUT/"WORLDCOVER_BACKGROUND_Q_RECALCULATED_V1.csv",index=False)
 pd.DataFrame(sample_rows).to_csv(OUT/"WORLDCOVER_SAMPLE_ACCOUNTING_V1.csv",index=False)
 pd.DataFrame(common_qrows).to_csv(OUT/"CGLS_WORLDCOVER_COMMON_SUPPORT_V1.csv",index=False)
 qwc=qnormalize(np.vstack([qwc_raw[c] for c in IDS]));qcg=qnormalize(np.vstack([qcg_raw[c] for c in IDS]))
 yw=np.vstack(native_wcy);yc=np.vstack(native_cgy)
 # strict blind LOCO: for each fold fit on 13, write the target prediction, only then score its class composition.
 result=[];predrows=[];betarows=[];pred_file=OUT/"WORLDCOVER_PREDICTED_COMPOSITIONS_V1.csv"
 for j,cov in enumerate(IDS):
  train=[k for k in range(len(IDS)) if k!=j]
  beta,info=model.fit_beta(qwc[train],yw[train],"coverage_equal")
  p=model.softmax_q_beta(qwc[j],beta)
  obs={"coverage_id":cov,"target_composition_opened_after_prediction":True}
  for k,c in enumerate(CLASSES):obs.update({f"q_{c}":qwc[j,k],f"pred_B_{c}":p[k],f"beta_{c}":beta[k]})
  pd.DataFrame([obs]).to_csv(pred_file,index=False,mode="w" if j==0 else "a",header=j==0)
  y=yw[j];m=metrics(y,qwc[j],p);n=m["n_RTS"];probs=y/n
  row={"coverage_id":cov,**m,"B_better_than_A":bool(m["TV_B"]<m["TV_A"]),"n_WC_input_RTS":len(rts_wc[cov]),"n_WC_six_class_RTS":int(y.sum()),"n_CGLS_six_class_RTS":int(yc[j].sum()),"prediction_written_before_target_composition_open":True,"training_coverage_n":len(IDS)-1,"training_weighting":"coverage_equal"}
  result.append(row)
  for k,c in enumerate(CLASSES):
   predrows.append({"coverage_id":cov,"vegetation_class":c,"q_WC":qwc[j,k],"observed_WC":probs[k],"pred_A_WC":qwc[j,k],"pred_B_WC":p[k],"residual_obs_minus_B":probs[k]-p[k]})
   betarows.append({"target_coverage_id":cov,"vegetation_class":c,"beta_relative_to_grass":beta[k],"beta_centered_mean_zero":beta[k]-float(beta.mean()),**info})
  print(f"native LOCO {j+1}/{len(IDS)} {cov}: G={m['G']:.4f} deltaLL={m['delta_LL_nats_per_RTS']}",flush=True)
 res=pd.DataFrame(result);predlong=pd.DataFrame(predrows);betas=pd.DataFrame(betarows)
 res.to_csv(OUT/"WORLDCOVER_COVERAGE_LOCO_RESULTS_V1.csv",index=False)
 predlong.to_csv(OUT/"WORLDCOVER_PREDICTED_COMPOSITIONS_V1.csv",index=False)
 betas.to_csv(OUT/"WORLDCOVER_LOCO_BETAS_V1.csv",index=False)
 # Object-level score summaries, keeping exact unsmoothed likelihood support visible.
 ll=res[res.ll_support_status.eq("FINITE")]
 dmean=float(ll.delta_LL_nats_per_RTS.mean()) if len(ll) else np.nan
 dweight=float(np.average(ll.delta_LL_nats_per_RTS,weights=ll.n_RTS)) if len(ll) else np.nan
 obj_summary={"finite_coverage_n":len(ll),"coverage_equal_delta_LL_nats_per_RTS":dmean,"RTS_weighted_delta_LL_nats_per_RTS":dweight,"coverage_equal_exp_deltaLL_minus_1":math.exp(dmean)-1 if np.isfinite(dmean) else np.nan,"RTS_weighted_exp_deltaLL_minus_1":math.exp(dweight)-1 if np.isfinite(dweight) else np.nan,"zero_support_coverage_n":int((res.ll_support_status!="FINITE").sum())}
 # 25-km whole-block spatial bootstrap. Reuse only the newly generated 13-zone replicate file when complete.
 boot_file=OUT/"WORLDCOVER_SPATIAL_BOOTSTRAP_SUMMARY_V1.csv"
 if boot_file.exists() and len(pd.read_csv(boot_file))>=.95*REPS:
  bdf=pd.read_csv(boot_file);ci=np.quantile(bdf.median_G,[.025,.975]);p_pos=float(np.mean(bdf.median_G>0))
 else:
  # 25-km whole-block spatial bootstrap. Every background block is in the frame, including blocks with no RTS.
  rng=np.random.default_rng(SEED);boot=[];boot_cov=[];boot_fail=[]
  for b in range(1,REPS+1):
   qb=[];yb=[]
   for cov in IDS:
    blockids,ar,yr=block_wc[cov];ix=rng.integers(0,len(blockids),size=len(blockids))
    a=ar[ix].sum(axis=0);qrow=a/a.sum() if a.sum()>0 else np.full(6,np.nan);qb.append(qrow);yb.append(yr[ix].sum(axis=0))
   qb=np.asarray(qb);yb=np.asarray(yb); gs=[];tvAs=[];tvBs=[]
   if not np.isfinite(qb).all():
    boot_fail.append({"replicate":b,"failure":"sampled blocks contain zero six-class background in a coverage"});continue
   try:
    for j,cov in enumerate(IDS):
     train=[k for k in range(len(IDS)) if k!=j];beta,_=model.fit_beta(qb[train],yb[train],"coverage_equal");p=model.softmax_q_beta(qb[j],beta)
     m=metrics(yb[j],qb[j],p)
     if m["n_RTS"]==0 or m["G_status"]=="SMALL_DENOMINATOR":raise RuntimeError(f"unscoorable sampled target {cov}")
     gs.append(m["G"]);tvAs.append(m["TV_A"]);tvBs.append(m["TV_B"])
    for j,cov in enumerate(IDS):boot_cov.append({"replicate":b,"coverage_id":cov,"G":gs[j],"TV_A":tvAs[j],"TV_B":tvBs[j]})
    boot.append({"replicate":b,"median_G":float(np.median(gs)),"mean_G":float(np.mean(gs)),"positive_coverage_n":int(np.sum(np.asarray(gs)>0)),"median_TV_A":float(np.median(tvAs)),"median_TV_B":float(np.median(tvBs))})
   except Exception as e:boot_fail.append({"replicate":b,"failure":repr(e)})
   if b%100==0:print(f"WC spatial bootstrap {b}/{REPS}; success={len(boot)}",flush=True)
  pd.DataFrame(boot).to_csv(OUT/"WORLDCOVER_SPATIAL_BOOTSTRAP_SUMMARY_V1.csv",index=False)
  pd.DataFrame(boot_cov).to_csv(OUT/"WORLDCOVER_SPATIAL_BOOTSTRAP_V1.csv",index=False)
  pd.DataFrame(boot_fail).to_csv(OUT/"WORLDCOVER_SPATIAL_BOOTSTRAP_FAILURES_V1.csv",index=False)
  if len(boot)<.95*REPS:raise RuntimeError(f"spatial bootstrap success below gate: {len(boot)}/{REPS}")
  bdf=pd.DataFrame(boot);ci=np.quantile(bdf.median_G,[.025,.975]);p_pos=float(np.mean(bdf.median_G>0))
 # Paired common support: same object IDs and same fixed 500m anchors in both products.
 qwc_com=[];qcg_com=[];ywc_com=[];ycg_com=[];common_rows=[];beta_wc_common=[];beta_cg_common=[]
 for cov in IDS:
  cpath=cdir/f"{cov}.csv.gz";wpath=wcdir/f"{cov}.csv.gz"
  cd=pd.read_csv(cpath);wd=pd.read_csv(wpath);cd["grid_id"]=cd.grid_id.astype(str);wd["grid_id"]=wd.grid_id.astype(str)
  common=wd[wd.worldcover_community.isin(CLASSES)][["grid_id","coverage_intersection_area_m2","worldcover_community","block_id"]].merge(
   cd[cd.community.isin(CLASSES)][["grid_id","community"]],on="grid_id",how="inner",validate="one_to_one")
  common=common.rename(columns={"community":"cgls_community"})
  wa=common.groupby("worldcover_community").coverage_intersection_area_m2.sum().reindex(CLASSES,fill_value=0).to_numpy(float)
  ca=common.groupby("cgls_community").coverage_intersection_area_m2.sum().reindex(CLASSES,fill_value=0).to_numpy(float)
  if wa.sum()<=0 or ca.sum()<=0:raise RuntimeError(f"no common valid background area {cov}")
  qwc_com.append(wa/wa.sum());qcg_com.append(ca/ca.sum())
  cw=common_rts[cov];ywrow=cw.worldcover_community.value_counts().reindex(CLASSES,fill_value=0).to_numpy(float);ycrow=cw.cgls_community.value_counts().reindex(CLASSES,fill_value=0).to_numpy(float)
  ywc_com.append(ywrow);ycg_com.append(ycrow)
  common_rows.append({"coverage_id":cov,"common_RTS_object_n":len(cw),"WC_RTS_six_class_native_n":int(rts_wc[cov].community.isin(CLASSES).sum()),"CGLS_RTS_six_class_native_n":int(rts_cg[cov].community.isin(CLASSES).sum()),"WC_valid_bg_anchor_n":len(ids_wc_bg[cov]),"CGLS_valid_bg_anchor_n":len(ids_cg_bg[cov]),"common_bg_anchor_n":len(common),"q_WC_common_area_m2":float(wa.sum()),"q_CGLS_common_area_m2":float(ca.sum()),"RTS_object_IDs_matched":True,"categories_kept_product_specific":True})
 qwc_com=np.asarray(qwc_com);qcg_com=np.asarray(qcg_com);ywc_com=np.asarray(ywc_com);ycg_com=np.asarray(ycg_com)
 loco_wc=[];loco_cg=[];pred_wc=[];pred_cg=[]
 for j,cov in enumerate(IDS):
  train=[k for k in range(len(IDS)) if k!=j]
  bw,iw=model.fit_beta(qwc_com[train],ywc_com[train],"coverage_equal");bc,ic=model.fit_beta(qcg_com[train],ycg_com[train],"coverage_equal")
  pw=model.softmax_q_beta(qwc_com[j],bw);pc=model.softmax_q_beta(qcg_com[j],bc)
  mw=metrics(ywc_com[j],qwc_com[j],pw);mc=metrics(ycg_com[j],qcg_com[j],pc)
  loco_wc.append(mw);loco_cg.append(mc)
  for k,c in enumerate(CLASSES):
   pred_wc.append({"coverage_id":cov,"vegetation_class":c,"q_WC_common":qwc_com[j,k],"obs_WC_common":ywc_com[j,k]/ywc_com[j].sum(),"pred_WC_common":pw[k],"beta_WC_centered":bw[k]-bw.mean()})
   pred_cg.append({"coverage_id":cov,"vegetation_class":c,"q_CGLS_common":qcg_com[j,k],"obs_CGLS_common":ycg_com[j,k]/ycg_com[j].sum(),"pred_CGLS_common":pc[k],"beta_CGLS_centered":bc[k]-bc.mean()})
   beta_wc_common.append({"target_coverage_id":cov,"vegetation_class":c,"beta_WC":bw[k],"beta_WC_centered":bw[k]-bw.mean(),**iw})
   beta_cg_common.append({"target_coverage_id":cov,"vegetation_class":c,"beta_CGLS":bc[k],"beta_CGLS_centered":bc[k]-bc.mean(),**ic})
  common_rows[j].update({"G_WC_common":mw["G"],"G_CGLS_common":mc["G"],"TV_A_WC_common":mw["TV_A"],"TV_B_WC_common":mw["TV_B"],"TV_A_CGLS_common":mc["TV_A"],"TV_B_CGLS_common":mc["TV_B"],"B_better_A_WC_common":mw["TV_B"]<mw["TV_A"],"B_better_A_CGLS_common":mc["TV_B"]<mc["TV_A"]})
 pd.DataFrame(common_rows).to_csv(OUT/"CGLS_WORLDCOVER_COMMON_SUPPORT_V1.csv",index=False)
 pair=pd.DataFrame(common_rows).copy();pair["delta_G_WC_minus_CGLS"]=pair.G_WC_common-pair.G_CGLS_common;pair["delta_TV_CGLS_minus_WC"]=pair.TV_B_CGLS_common-pair.TV_B_WC_common
 pair.to_csv(OUT/"CGLS_WORLDCOVER_PAIRED_RESULTS_V1.csv",index=False)
 pd.DataFrame(pred_wc).to_csv(OUT/"WORLDCOVER_COMMON_SUPPORT_PREDICTIONS_V1.csv",index=False)
 pd.DataFrame(pred_cg).to_csv(OUT/"CGLS_COMMON_SUPPORT_PREDICTIONS_V1.csv",index=False)
 pd.DataFrame(beta_wc_common).to_csv(OUT/"WORLDCOVER_COMMON_SUPPORT_BETAS_V1.csv",index=False)
 pd.DataFrame(beta_cg_common).to_csv(OUT/"CGLS_COMMON_SUPPORT_BETAS_V1.csv",index=False)
 # Product-paired coverage bootstrap, preserving each sampled coverage pair.
 prng=np.random.default_rng(SEED+501);gdiff=pair.delta_G_WC_minus_CGLS.to_numpy(float);gw=pair.G_WC_common.to_numpy(float);gc=pair.G_CGLS_common.to_numpy(float)
 pboot=[]
 for b in range(1,PAIRED_REPS+1):
  ix=prng.integers(0,len(IDS),len(IDS));pboot.append({"replicate":b,"median_delta_G_WC_minus_CGLS":float(np.nanmedian(gdiff[ix])),"mean_delta_G_WC_minus_CGLS":float(np.nanmean(gdiff[ix])),"median_G_WC_common":float(np.nanmedian(gw[ix])),"median_G_CGLS_common":float(np.nanmedian(gc[ix])),"positive_delta_n":int(np.sum(gdiff[ix]>0))})
 pd.DataFrame(pboot).to_csv(OUT/"CGLS_WORLDCOVER_PAIRED_BOOTSTRAP_V1.csv",index=False)
 pdf=pd.DataFrame(pboot);pair_ci=np.quantile(pdf.median_delta_G_WC_minus_CGLS,[.025,.975])
 # Centered association comparison on identical common-support folds.
 bwdf=pd.DataFrame(beta_wc_common);bcdf=pd.DataFrame(beta_cg_common)
 bcomp=bwdf.merge(bcdf,on=["target_coverage_id","vegetation_class"],validate="one_to_one")
 bcomp["centered_beta_difference_WC_minus_CGLS"]=bcomp.beta_WC_centered-bcomp.beta_CGLS_centered
 bcomp.to_csv(OUT/"CGLS_WORLDCOVER_CENTERED_BETA_COMPARISON_V1.csv",index=False)
 beta_stats=[]
 for cov in IDS:
  d=bcomp[bcomp.target_coverage_id.eq(cov)].sort_values("vegetation_class")
  sw=np.sign(d.beta_WC_centered);sc=np.sign(d.beta_CGLS_centered)
  rank=float(spearmanr(d.beta_WC_centered,d.beta_CGLS_centered).statistic)
  beta_stats.append({"coverage_id":cov,"direction_agreement_n_of_6":int(np.sum(sw==sc)),"rank_spearman":rank,"mean_abs_centered_beta_difference":float(np.mean(np.abs(d.centered_beta_difference_WC_minus_CGLS)))})
 pd.DataFrame(beta_stats).to_csv(OUT/"CGLS_WORLDCOVER_BETA_STABILITY_SUMMARY_V1.csv",index=False)
 # Structure correspondence: report raw Δr, but permutation tests only prediction-observation correspondence.
 obs_wc=yw/yw.sum(axis=1,keepdims=True);predmat=predlong.pivot(index="coverage_id",columns="vegetation_class",values="pred_B_WC").loc[IDS,CLASSES].to_numpy(float)
 dq=dmat(qwc);do=dmat(obs_wc);dp=dmat(predmat);rho_q=upper_corr(do,dq);rho_p=upper_corr(do,dp);delta_r=rho_p-rho_q
 srng=np.random.default_rng(SEED+11);snull=np.empty(10000)
 for b in range(len(snull)):
  perm=srng.permutation(len(IDS));snull[b]=upper_corr(do,dp[np.ix_(perm,perm)])
 p_corr=(1+np.sum(snull>=rho_p))/(len(snull)+1)
 structure=pd.DataFrame([{"rho_D_OBS_D_Q":rho_q,"rho_D_OBS_D_PRED":rho_p,"delta_r_pred_minus_q_descriptive_only":delta_r,"permutation_test":"coverage-label permutation tests prediction-observation correspondence, not delta-r improvement","permutation_p_prediction_observation_correspondence":p_corr,"permutations":len(snull)}])
 structure.to_csv(OUT/"WORLDCOVER_STRUCTURE_RECONSTRUCTION_V1.csv",index=False)
 pd.DataFrame({"replicate":np.arange(1,len(snull)+1),"rho_D_OBS_D_PRED_permuted":snull}).to_csv(OUT/"WORLDCOVER_STRUCTURE_COVERAGE_LABEL_PERMUTATION_V1.csv",index=False)
 # Exact 6! shared association label permutations.
 bmat=betas.pivot(index="target_coverage_id",columns="vegetation_class",values="beta_relative_to_grass").loc[IDS,CLASSES].to_numpy(float)
 labels=[]
 for perm in itertools.permutations(range(6)):
  gs=[]
  for j in range(len(IDS)):
   p=model.softmax_q_beta(qwc[j],bmat[j,list(perm)]);m=metrics(yw[j],qwc[j],p);gs.append(m["G"])
  labels.append({"permutation":"|".join(CLASSES[k] for k in perm),"is_identity":perm==tuple(range(6)),"median_G":float(np.nanmedian(gs)),"positive_coverage_n":int(np.sum(np.asarray(gs)>0))})
 ldf=pd.DataFrame(labels);ldf["rank_G_descending"]=ldf.median_G.rank(method="min",ascending=False).astype(int);ident=ldf[ldf.is_identity].iloc[0];ldf.to_csv(OUT/"WORLDCOVER_ASSOCIATION_LABEL_PERMUTATION_V1.csv",index=False)
 # Explicitly report product-sensitive coverages without exclusion.
 sens=[]
 for cov in [f"DARTS2023_COV_{i:03d}" for i in [19,21,22,28]]:
  j=IDS.index(cov)
  for k,c in enumerate(CLASSES):sens.append({"coverage_id":cov,"vegetation_class":c,"q_CGLS":qcg[j,k],"q_WorldCover":qwc[j,k],"obs_CGLS":yc[j,k]/yc[j].sum(),"obs_WorldCover":yw[j,k]/yw[j].sum(),"pred_CGLS":pd.DataFrame(predrows).query("coverage_id == @cov").iloc[k].pred_B_WC if False else np.nan,"pred_WorldCover":predmat[j,k],"G_CGLS_not_recomputed_native":np.nan,"G_WorldCover":res.iloc[j].G})
 # replace prediction columns with canonical frozen CGLS and WC predictions by class.
 cglsp=pd.read_csv(ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"results"/"TUNDRA13_LOCO_PREDICTIONS.csv").query("branch == 'coverage_equal'").pivot(index="coverage_id",columns="vegetation_class",values="predicted_share").loc[IDS,CLASSES].to_numpy(float)
 cgls_transfer=pd.read_csv(ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"results"/"TUNDRA13_LOCO_FOLDS.csv").set_index("coverage_id")
 for r in sens:
  j=IDS.index(r["coverage_id"]);k=CLASSES.index(r["vegetation_class"]);r["pred_CGLS"]=cglsp[j,k];r["G_CGLS"]=float(cgls_transfer.loc[r["coverage_id"],"G_shared_reconstruction"])
 pd.DataFrame(sens).to_csv(OUT/"WORLDCOVER_SENSITIVE_COVERAGE_AUDIT_V1.csv",index=False)
 # Output QC, hashes and main report.
 positive=int((res.G>0).sum());med=float(res.G.median());mean=float(res.G.mean());spmed=float(bdf.median_G.median())
 common_med_wc=float(pair.G_WC_common.median());common_med_cg=float(pair.G_CGLS_common.median())
 both=int((pair.B_better_A_WC_common & pair.B_better_A_CGLS_common).sum());onlyw=int((pair.B_better_A_WC_common & ~pair.B_better_A_CGLS_common).sum());onlyc=int((~pair.B_better_A_WC_common & pair.B_better_A_CGLS_common).sum());bothfail=len(IDS)-both-onlyw-onlyc
 cgls_fold=pd.read_csv(ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"results"/"TUNDRA13_LOCO_FOLDS.csv")
 cgls_sp=float(cgls_fold.G_shared_reconstruction.median());drop=med-cgls_sp
 leave_one_medians=[float(np.median([res.iloc[k].G for k in range(len(IDS)) if k!=j])) for j in range(len(IDS))]
 criteria={"A_strong":bool(spmed>=.50 and ci[0]>0 and positive>=11 and common_med_wc>0 and min(leave_one_medians)>0 and int(ident.rank_G_descending)<=360),
  "B_moderate":bool((.25<=spmed<.50 or 8<=positive<=10) and common_med_wc>0),
  "C_weak":bool(0<spmed<.25 or (positive>7 and positive<11)),"D_reject":bool(spmed<=0 or positive<=7)}
 verdict="A — STRONG_PRODUCT_REPLICATION" if criteria["A_strong"] else "B — MODERATE_PRODUCT_REPLICATION" if criteria["B_moderate"] else "C — WEAK_PRODUCT_REPLICATION" if criteria["C_weak"] else "D — REJECT_PRODUCT_ROBUSTNESS"
 # Influence analysis (remove one coverage from native result; no refitting or selection).
 influence=[]
 for j,cov in enumerate(IDS):
  keep=[k for k in range(len(IDS)) if k!=j];influence.append({"omitted_coverage":cov,"median_G_remaining":float(res.iloc[keep].G.median()),"positive_remaining_n":int((res.iloc[keep].G>0).sum()),"spatial_bootstrap_median_G_not_recomputed":spmed})
 pd.DataFrame(influence).to_csv(OUT/"WORLDCOVER_LOCO_INFLUENCE_V1.csv",index=False)
 # Tile support table adds actual missing support status and product-native sample closure.
 tile=pd.read_csv(SOURCE_OUT/"WORLDCOVER_TILE_COVERAGE_SUPPORT_V1.csv")
 tile=tile[tile.coverage.isin(IDS)].rename(columns={"coverage":"coverage_id"})
 support=tile.merge(pd.DataFrame(sample_rows),on="coverage_id",how="left",validate="one_to_one")
 support.to_csv(OUT/"WORLDCOVER_COVERAGE_SUPPORT_QC_V1.csv",index=False)
 # Hash every decisive input plus source scripts and derived data products.
 inputpaths=[WC/"PARAMETERS.json",WC/"WORLDCOVER_TO_VEGETATION_CROSSWALK_V1.csv",WC/"run_worldcover_sensitivity.py",BLIND/"scripts/03_run_blind_reconstruction.py",BLIND/"Q_BACKGROUND_GRID_INDEPENDENT.csv.gz",SOURCE_OUT/"WORLDCOVER_BACKGROUND_GRID_ASSIGNMENTS_V1.csv.gz",ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"results"/"TUNDRA13_LOCO_PREDICTIONS.csv",ROUND/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"results"/"TRANSFER"/"COVERAGE_TRANSFER_SUMMARY_25KM.csv",ROUND/"RTS_VEGETATION_COUPLING_BRIDGE_PUBLIC_RECHECK/public_sources/DARTS_v1_2/coverage_level2.gpkg",ROUND/"RTS_VEGETATION_COUPLING_BRIDGE_PUBLIC_RECHECK/public_sources/DARTS_v1_2/features_level2.gpkg"]
 for i in IDS_NUM:inputpaths += [rts_path(i,"WC"),rts_path(i,"CGLS"),area_grid_path(i)]
 hashes=[]
 for p in dict.fromkeys(inputpaths):
  if Path(p).exists():hashes.append({"path":str(p),"sha256":sha(p),"size_bytes":Path(p).stat().st_size,"role":"frozen input or independent reconstructed q"})
 pd.DataFrame(hashes).to_csv(OUT/"INPUT_HASHES_V1.csv",index=False)
 summary={"worldcover_native_median_G":med,"worldcover_native_mean_G":mean,"worldcover_native_positive_coverage_n":positive,"worldcover_native_G_quartiles":[float(res.G.quantile(.25)),float(res.G.quantile(.75))],"worldcover_native_G_min_max":[float(res.G.min()),float(res.G.max())],"worldcover_spatial_bootstrap_success":len(bdf),"worldcover_spatial_bootstrap_median_G":spmed,"worldcover_spatial_bootstrap_95CI":[float(ci[0]),float(ci[1])],"P_median_G_gt_0":p_pos,"CGLS_reference_spatial_median_G":cgls_sp,"difference_vs_CGLS_percentage_points":100*drop,"common_support_median_G_CGLS":common_med_cg,"common_support_median_G_WorldCover":common_med_wc,"common_support_paired_median_delta_G":float(pair.delta_G_WC_minus_CGLS.median()),"paired_coverage_bootstrap_95CI_delta_G":[float(pair_ci[0]),float(pair_ci[1])],"common_support_both_improve_n":both,"common_support_only_WC_n":onlyw,"common_support_only_CGLS_n":onlyc,"common_support_both_fail_n":bothfail,"association_label_identity_rank":int(ident.rank_G_descending),"association_label_identity_percentile":float((720-int(ident.rank_G_descending)+1)/720),"association_label_exact_p":float(np.mean(ldf.median_G>=ident.median_G-1e-12)),"structure_rho_obs_q":rho_q,"structure_rho_obs_pred":rho_p,"structure_delta_r_descriptive":delta_r,"structure_permutation_p_obs_pred_correspondence":p_corr,"object_scores":obj_summary,"verdict":verdict,"criteria":criteria}
 (OUT/"SUMMARY_METRICS_V1.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
 # Human-readable report generated only after all requested analyses have run.
 lines=["# RTS WorldCover shared-rule blind replication — final report","", "## 先说结论", "",
 f"1. 换成 WorldCover 后，shared rule {'仍优于' if positive>7 else '没有稳定优于'} 当地面积基准：{positive}/{len(IDS)} 个 coverage 的 G>0。",
 f"2. product-native median G={med:.3f}（均值 {mean:.3f}；四分位数 {res.G.quantile(.25):.3f}–{res.G.quantile(.75):.3f}）。",
 f"3. 25 km 空间块重采样 {len(bdf)}/{REPS} 成功；median G={spmed:.3f}，95% CI {ci[0]:.3f}–{ci[1]:.3f}，P(median G>0)={p_pos:.3f}。",
 f"4. 相对13区CGLS LOCO中位G {cgls_sp:.3f}，WorldCover {'下降' if drop<0 else '上升'} {abs(100*drop):.1f} 个百分点。",
 f"5. common-support 中位 G：CGLS={common_med_cg:.3f}，WorldCover={common_med_wc:.3f}；配对 coverage bootstrap 的 median ΔG={pair.delta_G_WC_minus_CGLS.median():.3f}，95% CI {pair_ci[0]:.3f}–{pair_ci[1]:.3f}。",
 f"6. 共支持结果：两产品都改善 {both}/{len(IDS)}，仅 WorldCover 改善 {onlyw}/{len(IDS)}，仅 CGLS 改善 {onlyc}/{len(IDS)}，两者都未改善 {bothfail}/{len(IDS)}。",
 f"7. label permutation identity 排名 {int(ident.rank_G_descending)}/720（exact p={float(np.mean(ldf.median_G>=ident.median_G-1e-12)):.4f}）。",
 f"8. 结构相关：ρ(D_OBS,D_Q)={rho_q:.3f}；ρ(D_OBS,D_PRED)={rho_p:.3f}；Δr={delta_r:.3f}仅作描述。coverage-label permutation 检验的是 prediction–observation correspondence，p={p_corr:.4g}，不检验Δr增量。",
 f"9. 最终等级：**{verdict}**。",
 "10. 对审稿问题“共享结构是否只是CGLS的产物”的回答："+("YES（可排除明显单产品依赖）" if verdict.startswith("A") else "PARTIAL（存在，但产品敏感）" if verdict.startswith("B") or verdict.startswith("C") else "NO（无法排除明显产品依赖）"),"",
 "## 每个coverage的 product-native LOCO 结果","",
 "详表见 `WORLDCOVER_COVERAGE_LOCO_RESULTS_V1.csv`。G=1−TV_B/TV_A；TV_A很小时保留绝对ΔTV并标 SMALL_DENOMINATOR。",
 "","## 分类与支持闭合","",
 "WorldCover输入对象的逐类账目见 `WORLDCOVER_SAMPLE_ACCOUNTING_V1.csv`。两块缺失官方tile经精确polygon相交审计，与13个正式coverage的相交面积均为0，保留全部13区；不插值、不补洞。盲 q 从全部固定背景锚点重算，不使用RTS footprint、RTS位置、数量或有RTS block筛选。q泄漏机器审计见 `WORLDCOVER_Q_BLIND_LEAKAGE_AUDIT_V1.json`。",
 "","## 如何解释换产品后的变化","",
 "产品-native结果回答完整WorldCover支持下的复现；common-support结果只固定同一RTS对象ID与同一背景锚点集合，类别仍按各产品原始交叉表独立判定。两者不得混成一个估计量。敏感coverage详表见 `WORLDCOVER_SENSITIVE_COVERAGE_AUDIT_V1.csv`；逐区影响见 `WORLDCOVER_LOCO_INFLUENCE_V1.csv`。", "",
 "## 预测分数与结构诊断","",
 f"WorldCover shared相对area-only的对象级无平滑log-score：coverage等权 {obj_summary['coverage_equal_delta_LL_nats_per_RTS']:.4f} nats/RTS，RTS加权 {obj_summary['RTS_weighted_delta_LL_nats_per_RTS']:.4f}；对应几何平均真实类别概率变化分别 {obj_summary['coverage_equal_exp_deltaLL_minus_1']:.2%} 与 {obj_summary['RTS_weighted_exp_deltaLL_minus_1']:.2%}。finite覆盖 {obj_summary['finite_coverage_n']}/{len(IDS)}；零支持保留并报告，不加伪计数。",
 "","## 预先冻结判据核对","",json.dumps(criteria,ensure_ascii=False,indent=2),"",
 "## 文件索引","","主要表包括完整LOCO、逐类预测、beta、1,000次空间bootstrap、common-support配对与10,000次paired coverage bootstrap、720种类别标签排列、结构置换和敏感coverage审计。代码、参数、输入哈希和运行日志均保存在本目录。","",
 "限制：这次是同一DARTS14 13个正式coverage上的产品替换复现，不是新的区域外部验证；WorldCover类别差异反映测量体系变化，不应解释为植被实际变化或因果过程。"]
 (OUT/"TUNDRA13_WORLDCOVER_REPLICATION_REPORT.md").write_text("\n".join(lines),encoding="utf-8")
 (OUT/"RUN_LOG.md").write_text(f"# Run log\n\n- Task: TUNDRA13_WORLDCOVER_REPLICATION\n- Started: logged by process wall time; date 2026-10-08\n- Product/version: ESA WorldCover 2021 v200, native 10m categorical, frozen crosswalk/mask\n- Background q: independently recomputed from all fixed anchors; no RTS exclusion or RTS-conditioned block selection\n- Product-native strict LOCO folds: {len(res)}/{len(IDS)}\n- Spatial bootstrap: {len(bdf)}/{REPS}\n- Common-support paired coverage bootstrap: {PAIRED_REPS}\n- Association label permutations: {LABEL_PERMS}\n- Final verdict: {verdict}\n- No upstream formal outputs or manuscript modified.\n- Runtime minutes (analysis process): {(time.time()-t0)/60:.2f}\n",encoding="utf-8")
 print(json.dumps(summary,indent=2,ensure_ascii=False),flush=True)
if __name__=="__main__":main()
