from __future__ import annotations
import hashlib, json, math, time
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(r'E:\zuom\gu\RUNS\ROUND_20260828_01')
SRC = ROOT / 'RTS_TUNDRA13_FULL_REANALYSIS_V1' / 'results' / 'TRANSFER'
OUT = ROOT / 'RTS_TUNDRA13_FULL_REANALYSIS_V1' / 'results' / 'BLOCK_ABC_25KM'
PANEL_PATH = SRC / 'RECONSTRUCTED_BLOCK_PANEL_25KM.csv'
OLD_SCORE_PATH = SRC / 'BLOCK_TRANSFER_25KM.csv'
CATS = ['FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE']
REF = 'GRASS_HERBACEOUS'
ALPHA = 0.5
BOOT_N = 5000
PARAM_BOOT_N = 2000
NULL_N = 1000
SEED = 20261001

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for buf in iter(lambda:f.read(1024*1024),b''): h.update(buf)
    return h.hexdigest()

def rate_matrix(ncov: np.ndarray, bcov: np.ndarray, correction: float=0.0) -> np.ndarray:
    nt=ncov.sum(axis=-1,keepdims=True)
    bt=bcov.sum(axis=-1,keepdims=True)
    ns=ncov+correction
    den=nt+correction*ncov.shape[-1]
    share=np.divide(ns,den,out=np.zeros_like(ns,dtype=float),where=den>0)
    bshare=np.divide(bcov,bt,out=np.zeros_like(bcov,dtype=float),where=bt>0)
    return np.divide(share,bshare,out=np.zeros_like(share,dtype=float),where=bshare>0)

def b_global_effect(ncov: np.ndarray, bcov: np.ndarray) -> np.ndarray:
    n=ncov.sum(axis=0); b=bcov.sum(axis=0)
    r=rate_matrix(n[None,:],b[None,:],0.0)[0]
    ref=CATS.index(REF)
    if r[ref] <= 0 or not np.isfinite(r[ref]):
        raise RuntimeError('Global B reference rate is not finite and positive.')
    return np.log(np.maximum(r,1e-300)/r[ref])

def hier_effects(ncov: np.ndarray, bcov: np.ndarray, correction: float=ALPHA):
    """Normal-normal empirical-Bayes shrinkage on coverage log-R contrasts."""
    j,k=ncov.shape; ref=CATS.index(REF)
    nall=ncov.sum(axis=0); ball=bcov.sum(axis=0)
    r0=rate_matrix(nall[None,:],ball[None,:],correction)[0]
    if r0[ref] <= 0 or not np.isfinite(r0[ref]):
        raise RuntimeError('Hierarchical reference rate is not finite and positive.')
    theta0=np.log(np.maximum(r0,1e-300)/r0[ref]); theta0[ref]=0.0
    theta=np.tile(theta0,(j,1)); var=np.full((j,k),np.inf); estimable=np.zeros((j,k),bool)
    for c in range(k):
        if c==ref: continue
        ok=(bcov[:,c]>0)&(bcov[:,ref]>0)
        estimable[:,c]=ok
        theta[ok,c]=np.log((ncov[ok,c]+correction)/(ncov[ok,ref]+correction)) + np.log(bcov[ok,ref]/bcov[ok,c])
        var[ok,c]=1.0/(ncov[ok,c]+correction)+1.0/(ncov[ok,ref]+correction)
    tau2=np.zeros(k,float); post=theta.copy(); shrink=np.zeros((j,k),float)
    for c in range(k):
        ok=estimable[:,c]
        if c==ref or ok.sum()<2: continue
        resid=theta[ok,c]-theta0[c]
        # Method-of-moments variance of random effects after subtracting multinomial sampling variance.
        tau2[c]=max(0.0,float(np.mean(resid*resid-var[ok,c])))
        den=tau2[c]+var[ok,c]
        w=np.divide(tau2[c],den,out=np.zeros_like(den),where=den>0)
        post[ok,c]=theta0[c]+w*resid
        shrink[ok,c]=w
    post[:,ref]=0.0
    return theta0,theta,post,tau2,shrink,estimable,var

def probabilities(local_b: np.ndarray, effect: np.ndarray) -> np.ndarray:
    w=np.where(local_b>0,local_b*np.exp(np.clip(effect,-30,30)),0.0)
    s=w.sum(axis=-1,keepdims=True)
    return np.divide(w,s,out=np.full_like(w,np.nan,dtype=float),where=s>0)

def score(y: np.ndarray, p: np.ndarray):
    n=int(y.sum()); k=len(CATS)
    ps=(n*p+ALPHA)/(n+ALPHA*k)
    ll=float(np.sum(y*np.log(ps)))
    obs=y/n
    tv=float(0.5*np.abs(obs-p).sum())
    return ll,tv,ps

def make_panel():
    raw=pd.read_csv(PANEL_PATH)
    if set(raw.community.unique())-set(CATS):
        raise RuntimeError('Unexpected class in frozen panel.')
    rows=[]
    keys=['coverage_id','block_id','block_x','block_y']
    for vals,g in raw.groupby(keys,sort=True,dropna=False):
        g=g.set_index('community').reindex(CATS)
        rows.append(dict(zip(keys,vals))|{
            'Y':g.RTS_N.fillna(0).to_numpy(dtype=int),
            'B':g.background_area_km2.fillna(0).to_numpy(dtype=float),
            'Ni':int(g.RTS_N.fillna(0).sum()),
        })
    d=pd.DataFrame(rows)
    coverages=sorted(d.coverage_id.unique()); ci={c:i for i,c in enumerate(coverages)}
    d['ci']=d.coverage_id.map(ci).astype(int)
    return d,coverages

def fold_prediction(ncov,bcov,local_y,local_b,cov_index):
    train_n=ncov.copy(); train_b=bcov.copy()
    train_n[cov_index]-=local_y
    train_b[cov_index]-=local_b
    if (train_n < 0).any() or (train_b < -1e-7).any(): raise RuntimeError('Negative training total.')
    train_b=np.maximum(train_b,0)
    # A: local area only.
    pa=local_b/local_b.sum()
    # B: pooled association across all coverage training blocks.
    rb=rate_matrix(train_n.sum(axis=0)[None,:],train_b.sum(axis=0)[None,:],0.0)[0]
    pb=probabilities(local_b,np.log(np.maximum(rb,1e-300)))
    # C: partially pooled coverage association.
    _,_,post,_,_,_,_=hier_effects(train_n,train_b)
    pc=probabilities(local_b,post[cov_index])
    return pa,pb,pc,train_n,train_b,rb,post

def two_level_bootstrap(comp,coverages,nrep=BOOT_N,seed=SEED):
    rng=np.random.default_rng(seed)
    by={c:comp[comp.coverage_id.eq(c)].copy() for c in coverages}
    out=np.zeros((nrep,4),float)
    for r in range(nrep):
        picked=rng.integers(0,len(coverages),len(coverages))
        covmeans=[]; covtvs=[]; covprop=[]; all_diff=[]; all_tv=[]; all_n=[]
        for ix in picked:
            c=coverages[ix]; g=by[c]
            sel=rng.integers(0,len(g),len(g)); z=g.iloc[sel]
            covmeans.append(float(z.delta_ll_per_rts_C_B.mean()))
            covtvs.append(float(z.TV_improvement_C_B.mean()))
            covprop.append(float(z.c_improved.mean()))
            all_diff.extend(z.delta_C_B.tolist()); all_tv.extend(z.TV_improvement_C_B.tolist()); all_n.extend(z.Ni.tolist())
        out[r]=[np.mean(covmeans),np.mean(covtvs),np.mean(covprop),np.sum(all_diff)/max(1,np.sum(all_n))]
    return pd.DataFrame(out,columns=['coverage_equal_delta_ll_per_rts','coverage_equal_tv_improvement','coverage_equal_block_improved_fraction','RTS_weighted_delta_ll_per_rts'])

def parameter_bootstrap(d,coverages,nrep=PARAM_BOOT_N,seed=SEED+1):
    rng=np.random.default_rng(seed)
    per={c:d[d.coverage_id.eq(c)] for c in coverages}
    vals=[]
    for r in range(nrep):
        ns=[]; bs=[]
        for ix in rng.integers(0,len(coverages),len(coverages)):
            g=per[coverages[ix]]; sel=rng.integers(0,len(g),len(g)); z=g.iloc[sel]
            ns.append(np.sum(np.stack(z.Y.to_numpy()),axis=0)); bs.append(np.sum(np.stack(z.B.to_numpy()),axis=0))
        ns=np.stack(ns); bs=np.stack(bs)
        beta=hier_effects(ns,bs)[0]
        tau=hier_effects(ns,bs)[3]
        for c,cat in enumerate(CATS):
            vals.append({'replicate':r+1,'parameter':'global_log_R_relative_to_GRASS','category':cat,'value':float(beta[c])})
            vals.append({'replicate':r+1,'parameter':'coverage_sd_tau','category':cat,'value':float(math.sqrt(tau[c]))})
    return pd.DataFrame(vals)

def null_simulation(d,coverages,ncov,bcov,observed_pB,nrep=NULL_N,seed=SEED+2):
    """Conditional multinomial calibration, with fixed block N/B and refitted LOBO models."""
    rng=np.random.default_rng(seed); nblock=len(d); k=len(CATS); j=len(coverages)
    yobs=np.stack(d.Y.to_numpy()); bmat=np.stack(d.B.to_numpy()); ni=d.Ni.to_numpy(int); ci=d.ci.to_numpy(int)
    ys=np.zeros((nrep,nblock,k),dtype=np.int32)
    for i in range(nblock):
        if ni[i]>0:
            ys[:,i,:]=rng.multinomial(int(ni[i]),observed_pB[i],size=nrep)
    nullstats=np.empty(nrep,float)
    scored=np.flatnonzero((ni>0)&(bmat.sum(axis=1)>0))
    for rep in range(nrep):
        sim=ys[rep]
        simcov=np.zeros((j,k),dtype=float)
        for jj in range(j): simcov[jj]=sim[ci==jj].sum(axis=0)
        diffs_by_cov=[[] for _ in coverages]; ns_by_cov=[[] for _ in coverages]
        for i in scored:
            trn=simcov.copy(); trb=bcov.copy(); trn[ci[i]]-=sim[i]; trb[ci[i]]-=bmat[i]
            trb=np.maximum(trb,0)
            rb=rate_matrix(trn.sum(axis=0)[None,:],trb.sum(axis=0)[None,:],0.0)[0]
            pb=probabilities(bmat[i],np.log(np.maximum(rb,1e-300)))
            _,_,post,_,_,_,_=hier_effects(trn,trb)
            pc=probabilities(bmat[i],post[ci[i]])
            llb,_,_=score(sim[i],pb); llc,_,_=score(sim[i],pc)
            diffs_by_cov[ci[i]].append((llc-llb)/ni[i]); ns_by_cov[ci[i]].append(ni[i])
        covmeans=[np.mean(x) for x in diffs_by_cov if x]
        nullstats[rep]=float(np.mean(covmeans))
    return pd.DataFrame({'replicate':np.arange(1,nrep+1),'null_coverage_equal_delta_ll_per_rts':nullstats})

def main():
    start=time.time(); OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'results').mkdir(exist_ok=True); (OUT/'scripts').mkdir(exist_ok=True)
    protocol_source=ROOT/'RTS_BROAD_LOCAL_TRANSFER_AND_CATEGORY_MATRIX_V1'/'B_C_MODEL_COMPARISON'/'scripts'/'run_bc_comparison.py'
    inputs=[PANEL_PATH,OLD_SCORE_PATH,SRC/'PARAMETERS.json',protocol_source,ROOT/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'TUNDRA13_COVERAGE_MANIFEST.json']
    for p in inputs:
        if not p.exists(): raise FileNotFoundError(p)
    pd.DataFrame([{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'role':'13-zone input or protocol'} for p in inputs]).to_csv(OUT/'INPUT_HASHES.csv',index=False)
    d,coverages=make_panel(); k=len(CATS)
    nblocks=[]; bblocks=[]; idxs=[]
    for cov in coverages:
        ix=np.flatnonzero(d.coverage_id.eq(cov).to_numpy()); idxs.append(ix)
        nblocks.append(np.sum(np.stack(d.iloc[ix].Y.to_numpy()),axis=0))
        bblocks.append(np.sum(np.stack(d.iloc[ix].B.to_numpy()),axis=0))
    ncov=np.stack(nblocks).astype(float); bcov=np.stack(bblocks).astype(float)
    scored=(d.Ni.to_numpy()>0)&(np.stack(d.B.to_numpy()).sum(axis=1)>0)
    ymat=np.stack(d.Y.to_numpy()); bmat=np.stack(d.B.to_numpy()); ni=d.Ni.to_numpy(int); ci=d.ci.to_numpy(int)
    result=[]; model_rows={m:[] for m in ['A','B','C']}; observed_pB=np.full((len(d),k),np.nan)
    for i in np.flatnonzero(scored):
        pa,pb,pc,tn,tb,rb,post=fold_prediction(ncov,bcov,ymat[i],bmat[i],ci[i])
        observed_pB[i]=pb
        preds={'A':pa,'B':pb,'C':pc}; scores={}; tvs={}
        for model,p in preds.items():
            ll,tv,ps=score(ymat[i],p); scores[model]=ll; tvs[model]=tv
            for c,cat in enumerate(CATS):
                model_rows[model].append({'coverage_id':d.iloc[i].coverage_id,'block_id':d.iloc[i].block_id,'block_x':int(d.iloc[i].block_x),'block_y':int(d.iloc[i].block_y),'category':cat,'RTS_N':int(ymat[i,c]),'RTS_N_total':int(ni[i]),'background_area_km2':float(bmat[i,c]),'p_raw':float(p[c]),'p_scored_alpha_0p5':float(ps[c]),'expected_RTS_N_raw':float(ni[i]*p[c]),'log_score_contribution':float(ymat[i,c]*np.log(ps[c]))})
        result.append({'coverage_id':d.iloc[i].coverage_id,'block_id':d.iloc[i].block_id,'block_x':int(d.iloc[i].block_x),'block_y':int(d.iloc[i].block_y),'Ni':int(ni[i]),'background_total_km2':float(bmat[i].sum()),'LL_A':scores['A'],'LL_B':scores['B'],'LL_C':scores['C'],'delta_B_A':scores['B']-scores['A'],'delta_C_A':scores['C']-scores['A'],'delta_C_B':scores['C']-scores['B'],'delta_ll_per_rts_C_B':(scores['C']-scores['B'])/ni[i],'TV_A':tvs['A'],'TV_B':tvs['B'],'TV_C':tvs['C'],'TV_improvement_C_B':tvs['B']-tvs['C'],'c_improved':scores['C']>scores['B'],'b_improved_over_a':scores['B']>scores['A']})
    comp=pd.DataFrame(result)
    old=pd.read_csv(OLD_SCORE_PATH); old=old[old.valid_status.eq('SCORED')]
    check=comp.merge(old[['coverage_id','block_id','LL_area_Jeffreys_0p5']],on=['coverage_id','block_id'],how='outer',indicator=True)
    check['abs_diff']=np.abs(check.LL_A-check.LL_area_Jeffreys_0p5)
    if not check._merge.eq('both').all() or check.abs_diff.max()>1e-10:
        raise RuntimeError(f'Area-only historical reproduction gate failed; rows={len(check)}, max_abs_diff={check.abs_diff.max()}')
    comp.to_csv(OUT/'results'/'prediction_comparison.csv',index=False)
    for m in ['A','B','C']:
        pd.DataFrame(model_rows[m]).to_csv(OUT/'results'/f'model_{m}.csv',index=False)
    # Cross-fitted parameter point estimates on each fold, long form.
    point=[]
    for i in np.flatnonzero(scored):
        _,_,_,tn,tb,rb,post=fold_prediction(ncov,bcov,ymat[i],bmat[i],ci[i])
        theta0,theta_raw,theta_post,tau2,shrink,estimable,var=hier_effects(tn,tb)
        for c,cat in enumerate(CATS):
            point.append({'coverage_id':d.iloc[i].coverage_id,'heldout_block_id':d.iloc[i].block_id,'category':cat,'B_global_R':float(rb[c]),'B_log_relative_effect_vs_grass':float(b_global_effect(tn,tb)[c]),'C_global_log_effect_vs_grass':float(theta0[c]),'C_tau':float(math.sqrt(tau2[c])),'C_coverage_raw_log_effect':float(theta_raw[ci[i],c]),'C_coverage_shrunken_log_effect':float(theta_post[ci[i],c]),'C_shrinkage_weight':float(shrink[ci[i],c]),'C_local_effect_estimable':bool(estimable[ci[i],c])})
    pd.DataFrame(point).to_csv(OUT/'results'/'model_parameters_crossfit.csv',index=False)
    # Paired two-stage bootstrap on cross-fitted block scores.
    boot=two_level_bootstrap(comp,coverages)
    boot.to_csv(OUT/'results'/'paired_bootstrap_draws.csv',index=False)
    boot_summary=[]
    for col in boot.columns:
        vals=boot[col].to_numpy()
        boot_summary.append({'metric':col,'estimate':float(comp.groupby('coverage_id').apply(lambda g: g.delta_ll_per_rts_C_B.mean()).mean()) if col=='coverage_equal_delta_ll_per_rts' else (float(comp.groupby('coverage_id').TV_improvement_C_B.mean().mean()) if col=='coverage_equal_tv_improvement' else (float(comp.groupby('coverage_id').c_improved.mean().mean()) if col=='coverage_equal_block_improved_fraction' else float(comp.delta_C_B.sum()/comp.Ni.sum()))),'ci95_low':float(np.nanpercentile(vals,2.5)),'ci95_high':float(np.nanpercentile(vals,97.5))})
    pd.DataFrame(boot_summary).to_csv(OUT/'results'/'paired_bootstrap_summary.csv',index=False)
    # Parameter uncertainty bootstrap; resample coverage, then blocks inside selected coverage.
    pboot=parameter_bootstrap(d,coverages)
    psum=pboot.groupby(['parameter','category']).value.agg(bootstrap_median='median',ci95_low=lambda x:np.nanpercentile(x,2.5),ci95_high=lambda x:np.nanpercentile(x,97.5)).reset_index()
    psum.to_csv(OUT/'results'/'parameter_bootstrap_summary.csv',index=False)
    # Conditional shared-association null; refit cross-fitted B and C on every simulated panel.
    null=null_simulation(d,coverages,ncov,bcov,observed_pB)
    null.to_csv(OUT/'results'/'permutation_null.csv',index=False)
    observed=float(comp.groupby('coverage_id').delta_ll_per_rts_C_B.mean().mean())
    pval=(1+int((null.null_coverage_equal_delta_ll_per_rts>=observed).sum()))/(len(null)+1)
    nsummary={'observed_coverage_equal_delta_ll_per_rts':observed,'null_mean':float(null.null_coverage_equal_delta_ll_per_rts.mean()),'null_p95':float(null.null_coverage_equal_delta_ll_per_rts.quantile(.95)),'one_sided_monte_carlo_p':pval,'n_replicates':len(null),'null_method':'conditional multinomial shared-B model calibration; not naive coverage-label permutation'}
    (OUT/'results'/'null_test_summary.json').write_text(json.dumps(nsummary,indent=2),encoding='utf-8')
    # Coverage and overall summaries.
    covsum=comp.groupby('coverage_id').agg(blocks=('block_id','size'),RTS=('Ni','sum'),mean_delta_C_B=('delta_ll_per_rts_C_B','mean'),median_delta_C_B=('delta_ll_per_rts_C_B','median'),block_fraction_C_gt_B=('c_improved','mean'),mean_TV_improvement=('TV_improvement_C_B','mean'),mean_delta_B_A=('delta_B_A','mean'),mean_delta_C_A=('delta_C_A','mean')).reset_index()
    covsum.to_csv(OUT/'results'/'coverage_summary.csv',index=False)
    bycat=[]
    for m,dfm in [(x,pd.DataFrame(model_rows[x])) for x in 'ABC']:
        agg=dfm.groupby('category').agg(RTS=('RTS_N','sum'),predicted_RTS=('expected_RTS_N_raw','sum'),scored_blocks=('block_id','nunique'),background_area_km2=('background_area_km2','sum')).reset_index(); agg.insert(0,'model',m); bycat.append(agg)
    pd.concat(bycat).to_csv(OUT/'results'/'category_prediction_summary.csv',index=False)
    # Detailed recorded parameters.
    params={'task':'RTS_BROAD_LOCAL_TRANSFER_AND_CATEGORY_MATRIX_V1 B-vs-C comparison','primary_scale_km':25,'coverage_ids':coverages,'categories':CATS,'reference_category_for_C':'GRASS_HERBACEOUS','scored_blocks':int(scored.sum()),'all_blocks':int(len(d)),'fixed_test_total':True,'alpha':ALPHA,'bootstrap_replicates':BOOT_N,'parameter_bootstrap_replicates':PARAM_BOOT_N,'null_replicates':NULL_N,'random_seed':SEED,'null_method':nsummary['null_method'],'C_method':'normal-normal empirical-Bayes shrinkage on log background-corrected category odds; method-of-moments tau^2, alpha=0.5 continuity correction, not full Bayesian GLMM','scoring':'conditional multinomial log score (common multinomial coefficient omitted), alpha=0.5; TV unsmoothed','no_fallback':True,'historical_A_gate_max_abs_logscore_diff':float(check.abs_diff.max())}
    (OUT/'PARAMETERS.json').write_text(json.dumps(params,indent=2),encoding='utf-8')
    lines=['# B/C模型比较运行日志','',f'- Status: COMPLETE','- Scored matched LOBO blocks: {len(comp)}','- Coverage: {len(coverages)}','- A historical score gate: PASS; maximum absolute log-score difference {check.abs_diff.max():.3g}','- Null calibration replicates: {len(null)}','- Elapsed seconds: {time.time()-start:.1f}','- Upstream files modified: NO','- Failures: none; all scored folds produced finite A/B/C probabilities and scores.']
    (OUT/'RUN_LOG.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__': main()

