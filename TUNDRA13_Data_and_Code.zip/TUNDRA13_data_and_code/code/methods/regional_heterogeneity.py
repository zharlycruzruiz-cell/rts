from __future__ import annotations
import json, hashlib, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.optimize import minimize
from scipy.special import gammaln
from scipy.stats import chi2
warnings.filterwarnings('ignore')

ROOT=Path(r'E:\zuom\gu'); ROUND=ROOT/'RUNS'/'ROUND_20260828_01'; OUT=ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'results'/'CATEGORY_SPECTRUM'
V1=ROUND/'RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V1'; V2=ROUND/'RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V2'; PREF=ROUND/'RTS_PANARCTIC_CONTINUOUS_STATE_PREFLIGHT_V1'/'regenerated_background'
TARGET=json.loads((ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'TUNDRA13_COVERAGE_MANIFEST.json').read_text(encoding='utf-8'))['coverage_ids']
SCALES=[10,25,50]; CATS=['FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE']; BASE_CAT='GRASS_HERBACEOUS'; SEED=20260922; NBOOT=1000
TR=Transformer.from_crs(4326,6933,always_xy=True)

def sha256(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def input_paths(uid):
 rp=V1/'checkpoints'/f'{uid}_RTS_ASSIGNMENTS.csv'; rp=rp if rp.exists() else V2/'unit_cache'/f'{uid}_RTS_ASSIGNMENTS.csv'
 bp=PREF/f'{uid}_BACKGROUND_GRID.csv'; bp=bp if bp.exists() else V2/'unit_cache'/f'{uid}_BACKGROUND_GRID.csv'
 return rp,bp

def prep_tables():
 rows={s:[] for s in SCALES}; inputs=[]; failures=[]
 for uid in TARGET:
  rp,bp=input_paths(uid)
  if not rp.exists() or not bp.exists():
   failures.append({'stage':'input_check','coverage_id':uid,'error':'missing frozen assignment or background grid','rts_path':str(rp),'background_path':str(bp)}); continue
  inputs += [{'role':'RTS_ASSIGNMENTS','coverage_id':uid,'path':str(rp),'sha256':sha256(rp),'bytes':rp.stat().st_size},{'role':'BACKGROUND_GRID','coverage_id':uid,'path':str(bp),'sha256':sha256(bp),'bytes':bp.stat().st_size}]
  rts=pd.read_csv(rp,usecols=['centroid_lon','centroid_lat','community','rts_id']); bg=pd.read_csv(bp,usecols=['center_lon','center_lat','community','coverage_intersection_area_m2','grid_id'])
  rts=rts[rts.community.isin(CATS)].copy(); bg['coverage_intersection_area_m2']=pd.to_numeric(bg.coverage_intersection_area_m2,errors='coerce').fillna(0.0); bg=bg[bg.coverage_intersection_area_m2>0].copy()
  rts['_x'],rts['_y']=TR.transform(rts.centroid_lon.to_numpy(float),rts.centroid_lat.to_numpy(float)); bg['_x'],bg['_y']=TR.transform(bg.center_lon.to_numpy(float),bg.center_lat.to_numpy(float))
  for s in SCALES:
   div=float(s*1000); rts['_bx']=np.floor(rts['_x']/div).astype('int64'); rts['_by']=np.floor(rts['_y']/div).astype('int64'); bg['_bx']=np.floor(bg['_x']/div).astype('int64'); bg['_by']=np.floor(bg['_y']/div).astype('int64')
   rg=rts.groupby(['_bx','_by','community'],as_index=False).size().rename(columns={'size':'RTS_N'}); rtst=rts.groupby(['_bx','_by'],as_index=False).size().rename(columns={'size':'effective_RTS_total_in_block'})
   bgcat=bg[bg.community.isin(CATS)].groupby(['_bx','_by','community'],as_index=False).agg(background_area_m2=('coverage_intersection_area_m2','sum'),background_grid_n=('grid_id','nunique'))
   bgt=bg.groupby(['_bx','_by'],as_index=False).agg(block_area_inside_coverage_km2=('coverage_intersection_area_m2','sum'),background_grid_n_total=('grid_id','nunique'))
   keys=set(map(tuple,bgt[['_bx','_by']].to_numpy().tolist()))|set(map(tuple,rtst[['_bx','_by']].to_numpy().tolist()))
   rgm={(int(a),int(b),c):int(n) for a,b,c,n in rg.itertuples(index=False)}; bgm={(int(a),int(b),c):(float(ar),int(ng)) for a,b,c,ar,ng in bgcat.itertuples(index=False)}; btm={(int(a),int(b)):(float(ar),int(ng)) for a,b,ar,ng in bgt.itertuples(index=False)}; rtm={(int(a),int(b)):int(n) for a,b,n in rtst.itertuples(index=False)}
   for bx,by in sorted(keys):
    ar,ng=btm.get((bx,by),(0.0,0)); total=rtm.get((bx,by),0)
    for cat in CATS:
     if (bx,by,cat) in bgm:
      ba,bgn=bgm[(bx,by,cat)]; rows[s].append({'coverage_id':uid,'block_id':f'{s}_{bx}_{by}','block_x':bx,'block_y':by,'scale_km':s,'community':cat,'RTS_N':rgm.get((bx,by,cat),0),'background_area_km2':ba/1e6,'background_grid_n':bgn,'effective_RTS_total_in_block':total,'block_area_inside_coverage_km2':ar/1e6,'background_grid_n_total':ng})
 for s in SCALES:
  d=pd.DataFrame(rows[s]); d.to_csv(OUT/f'BLOCK_TABLE_{s}KM.csv',index=False); z=d[['coverage_id','block_id','effective_RTS_total_in_block']].drop_duplicates(); z=z[z.effective_RTS_total_in_block.eq(0)]; pd.DataFrame([{'scale_km':s,'all_zero_block_n':int(len(z)),'all_blocks_n':int(d[['coverage_id','block_id']].drop_duplicates().shape[0])}]).to_csv(OUT/f'ALL_ZERO_BLOCKS_{s}KM.csv',index=False)
 pd.DataFrame(inputs).to_csv(OUT/'INPUT_HASHES.csv',index=False); pd.DataFrame(failures).to_csv(OUT/'FAILURE_LOG.csv',index=False); return failures

def category_eligibility(d):
 out=[]
 for cat in CATS:
  g=d[d.community.eq(cat)].groupby('coverage_id',as_index=False).agg(bg=('background_area_km2','sum'),rts=('RTS_N','sum')); nbg=int((g.bg>0).sum()); nrts=int((g.rts>0).sum()); total=int(g.rts.sum()); out.append({'community':cat,'coverage_with_background_n':nbg,'coverage_with_RTS_n':nrts,'total_RTS_n':total,'eligible_for_interaction':bool(nbg>=3 and nrts>=3 and total>=30),'rule':'background>0 in >=3 coverage; RTS>0 in >=3 coverage; total RTS>=30'})
 x=pd.DataFrame(out); x.to_csv(OUT/'CATEGORY_ELIGIBILITY.csv',index=False); return x

def make_design(d,cats):
 cats=list(cats); base=BASE_CAT if BASE_CAT in cats else cats[0]; v=[c for c in cats if c!=base]; covs=sorted(d.coverage_id.unique()); bc=covs[0]; others=covs[1:]
 X0=np.column_stack([(d.community.to_numpy()==c).astype(float) for c in v]) if v else np.zeros((len(d),0)); t0=[f'vegetation[{c}]' for c in v]; arr=[X0]; terms=list(t0)
 for co in others:
  for c in v: arr.append(((d.coverage_id.to_numpy()==co)&(d.community.to_numpy()==c)).astype(float)); terms.append(f'coverage[{co}]:vegetation[{c}]')
 X1=np.column_stack(arr) if arr else np.zeros((len(d),0)); return X0,X1,t0,terms,base,bc

def independent_columns(X):
 keep=[]; rank=0
 for j in range(X.shape[1]):
  r=np.linalg.matrix_rank(X[:,keep+[j]],tol=1e-9)
  if r>rank: keep.append(j); rank=r
 return np.asarray(keep,dtype=int)

def fit_model(d,X,terms,weights=None,start=None):
 if len(d)==0:return {'ok':False,'reason':'empty'}
 w=np.ones(len(d),float) if weights is None else np.asarray(weights,float)
 if weights is not None:
  valid=w>0
  d=d.iloc[valid].reset_index(drop=True); X=X[valid]; w=w[valid]
 counts=d.RTS_N.to_numpy(float)*w; bg=d.background_area_km2.to_numpy(float)*w
 bcodes=pd.factorize(d.block_id,sort=True)[0]; nb=int(bcodes.max()+1); nblock=np.bincount(bcodes,weights=counts,minlength=nb); logbg=np.log(bg); keep=independent_columns(X); dropped=[terms[j] for j in range(len(terms)) if j not in set(keep)]; Xr=X[:,keep] if len(keep) else np.zeros((len(d),0)); termsr=[terms[j] for j in keep]
 def fg(theta,grad=True):
  eta=Xr@theta+logbg; gmax=np.full(nb,-np.inf); np.maximum.at(gmax,bcodes,eta); ex=np.exp(eta-gmax[bcodes]); sm=np.bincount(bcodes,weights=ex,minlength=nb); ls=gmax+np.log(sm); p=ex/sm[bcodes]; ll=float(np.sum(counts*eta)-np.sum(nblock*ls)-np.sum(gammaln(counts+1)))
  if grad and len(theta): return -ll,-(Xr.T@(counts-nblock[bcodes]*p))
  return ll
 if len(termsr):
  x0=np.zeros(len(termsr)) if start is None else np.asarray(start,float)[keep]; res=minimize(lambda t:fg(t,True),x0,jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-12,'gtol':1e-7}); theta=res.x; ok=bool(res.success or np.linalg.norm(np.asarray(res.jac))<1e-4)
 else: theta=np.zeros(0); res=type('R',(),{'success':True,'message':'intercept-only','nit':0,'jac':np.zeros(0)})(); ok=True
 ll=fg(theta,False); eta=Xr@theta+logbg; gm=np.full(nb,-np.inf); np.maximum.at(gm,bcodes,eta); ex=np.exp(eta-gm[bcodes]); sm=np.bincount(bcodes,weights=ex,minlength=nb); mu=nblock[bcodes]*ex/sm[bcodes]; dev=2*float(np.sum(np.where(counts>0,counts*np.log(np.where(mu>0,counts/mu,1))-counts+mu,mu))); full=np.zeros(len(terms)); full[keep]=theta; return {'ok':ok,'success':bool(res.success),'message':str(res.message),'nit':int(getattr(res,'nit',0)),'theta':full,'terms':terms,'dropped_terms':dropped,'ll':ll,'deviance':dev,'aic':2*len(theta)-2*ll,'kcoef':len(theta),'n_rows':len(d),'n_blocks':nb}

def model_data(b,cats):
 base=BASE_CAT if BASE_CAT in cats else cats[0]; m=b[b.community.isin(cats)&b.background_area_km2.gt(0)&b.effective_RTS_total_in_block.gt(0)].copy(); X0,X1,t0,t1,bcov,basecov=make_design(m,cats); return m,X0,X1,t0,t1,bcov,basecov

def fit_scale(s,b,elig):
 cats=elig.loc[elig.eligible_for_interaction,'community'].tolist(); m,X0,X1,t0,t1,base,bcov=model_data(b,cats); f0=fit_model(m,X0,t0); f1=fit_model(m,X1,t1); imp=2*(f1['ll']-f0['ll']); df=max(0,f1['kcoef']-f0['kcoef']); p=float(chi2.sf(imp,df)) if df else np.nan; comp={'scale_km':s,'n_model_rows':len(m),'n_model_blocks':int(m[['coverage_id','block_id']].drop_duplicates().shape[0]),'eligible_categories':';'.join(cats),'baseline_vegetation':base,'baseline_coverage':bcov,'M0_loglik':f0['ll'],'M1_loglik':f1['ll'],'M0_deviance':f0['deviance'],'M1_deviance':f1['deviance'],'delta_deviance_M0_minus_M1':imp,'delta_AIC_M0_minus_M1':f0['aic']-f1['aic'],'LRT_df':df,'LRT_p':p,'M0_converged':f0['ok'],'M1_converged':f1['ok'],'M0_message':f0['message'],'M1_message':f1['message'],'all_zero_block_n':int(b[['coverage_id','block_id','effective_RTS_total_in_block']].drop_duplicates().query('effective_RTS_total_in_block==0').shape[0])}; pd.DataFrame([comp]).to_csv(OUT/f'MODEL_{s}KM_COMPARISON.csv',index=False)
 for tag,f in [('M0',f0),('M1',f1)]: pd.DataFrame([{'scale_km':s,'model':tag,'term':term,'coefficient':float(val),'converged':f['ok'],'dropped_due_collinearity':term in f['dropped_terms'],'n_model_rows':f['n_rows'],'n_model_blocks':f['n_blocks']} for term,val in zip(f['terms'],f['theta'])]).to_csv(OUT/f'MODEL_{s}KM_{tag}.csv',index=False)
 return m,X0,X1,t0,t1,f0,f1,comp

def rcount_grass(d,w=None):
 w=np.ones(len(d)) if w is None else np.asarray(w,float); denr=float(np.sum(d.RTS_N.to_numpy(float)*w)); denb=float(np.sum(d.background_area_km2.to_numpy(float)*w)); g=d.community.eq('GRASS_HERBACEOUS').to_numpy(); rg=float(np.sum(d.loc[g,'RTS_N'].to_numpy(float)*w[g])); bg=float(np.sum(d.loc[g,'background_area_km2'].to_numpy(float)*w[g])); return (rg/denr)/(bg/denb) if denr>0 and denb>0 and bg>0 else np.nan

def bootstrap_scale(s,b,elig,f0,f1):
 cats=elig.loc[elig.eligible_for_interaction,'community'].tolist(); m,X0,X1,t0,t1,_,_=model_data(b,cats); m=m.reset_index(drop=True); allb=b[['coverage_id','block_id']].drop_duplicates().sort_values(['coverage_id','block_id']).reset_index(drop=True); lookup={(r.coverage_id,r.block_id):i for i,r in allb.iterrows()}; mids=np.array([lookup[(a,c)] for a,c in zip(m.coverage_id,m.block_id)]); rng=np.random.default_rng(SEED+s); out=[]; grass=[]; fa=fb=0
 for rep in range(1,NBOOT+1):
  draw=np.zeros(len(allb),dtype=int)
  for cov,g in allb.groupby('coverage_id',sort=True): draw+=np.bincount(rng.choice(g.index.to_numpy(),size=len(g),replace=True),minlength=len(allb))
  w=draw[mids].astype(float)
  if np.sum(m.RTS_N.to_numpy(float)*w)<=0: out.append({'scale_km':s,'bootstrap_rep':rep,'delta_deviance':np.nan,'delta_AIC':np.nan,'interaction_direction_summary':'NONFINITE','M0_converged':False,'M1_converged':False}); fa+=1; fb+=1; grass.append(np.nan); continue
  z0=fit_model(m,X0,t0,w,start=f0['theta']); z1=fit_model(m,X1,t1,w,start=f1['theta']); fa+=int(not z0['ok']); fb+=int(not z1['ok']); imp=2*(z1['ll']-z0['ll']) if z0['ok'] and z1['ok'] else np.nan; da=z0['aic']-z1['aic'] if z0['ok'] and z1['ok'] else np.nan; inter=[v for term,v in zip(z1['terms'],z1['theta']) if term.startswith('coverage[')]; pos=sum(v>1e-8 for v in inter); neg=sum(v<-1e-8 for v in inter); zero=len(inter)-pos-neg; sign='POSITIVE' if pos and not neg else 'NEGATIVE' if neg and not pos else 'MIXED' if pos and neg else 'ZERO'; out.append({'scale_km':s,'bootstrap_rep':rep,'delta_deviance':imp,'delta_AIC':da,'interaction_direction_summary':sign,'interaction_positive_n':pos,'interaction_negative_n':neg,'interaction_zero_n':zero,'M0_converged':z0['ok'],'M1_converged':z1['ok']}); grass.append(rcount_grass(m,w))
 return pd.DataFrame(out),np.asarray(grass),fa,fb

def grass_stability(b,elig):
 cats=elig.loc[elig.eligible_for_interaction,'community'].tolist(); m=b[b.community.isin(cats)&b.background_area_km2.gt(0)].copy(); allb=b[['coverage_id','block_id']].drop_duplicates().sort_values(['coverage_id','block_id']).reset_index(drop=True); lookup={(r.coverage_id,r.block_id):i for i,r in allb.iterrows()}; mids=np.array([lookup[(a,c)] for a,c in zip(m.coverage_id,m.block_id)]); rng=np.random.default_rng(SEED+2500); reps={c:[] for c in TARGET}
 for _ in range(NBOOT):
  draw=np.zeros(len(allb),dtype=int)
  for cov,g in allb.groupby('coverage_id',sort=True): draw+=np.bincount(rng.choice(g.index.to_numpy(),size=len(g),replace=True),minlength=len(allb))
  w=draw[mids]
  for cov in TARGET:
   mm=m[m.coverage_id.eq(cov)].copy(); reps[cov].append(rcount_grass(mm,w[m.coverage_id.eq(cov).to_numpy()]))
 out=[]
 for cov in TARGET:
  full=m[m.coverage_id.eq(cov)]; a=np.asarray(reps[cov]); q=a[np.isfinite(a)]; out.append({'coverage_id':cov,'RTS_n_GRASS':int(full.RTS_N.sum()),'R_count_GRASS_observed':rcount_grass(full),'bootstrap_n':NBOOT,'bootstrap_finite_n':len(q),'R_count_GRASS_CI025':float(np.percentile(q,2.5)) if len(q) else np.nan,'R_count_GRASS_CI975':float(np.percentile(q,97.5)) if len(q) else np.nan,'bootstrap_fraction_R_count_gt_1':float(np.mean(q>1)) if len(q) else np.nan,'bootstrap_interval_entirely_gt_1':bool(len(q) and np.percentile(q,2.5)>1),'status':'PASS' if len(q)==NBOOT else 'NONFINITE'})
 return pd.DataFrame(out)

def main():
 OUT.mkdir(parents=True,exist_ok=True); (OUT/'code').mkdir(exist_ok=True); failures=prep_tables(); b25=pd.read_csv(OUT/'BLOCK_TABLE_25KM.csv'); elig=category_eligibility(b25); ms=[]; bs=[]; grass25=None
 for s in SCALES:
  try:
   b=pd.read_csv(OUT/f'BLOCK_TABLE_{s}KM.csv'); m,X0,X1,t0,t1,f0,f1,c=fit_scale(s,b,elig); ms.append(c); rep,g,fa,fb=bootstrap_scale(s,b,elig,f0,f1); rep.to_csv(OUT/f'BLOCK_BOOTSTRAP_{s}KM.csv',index=False); q=rep.delta_deviance.dropna(); a=rep.delta_AIC.dropna(); bs.append({'scale_km':s,'bootstrap_n':NBOOT,'M0_fail_n':fa,'M1_fail_n':fb,'M0_fail_fraction':fa/NBOOT,'M1_fail_fraction':fb/NBOOT,'M1_better_than_M0_fraction':float(np.mean(q>0)) if len(q) else np.nan,'delta_deviance_CI025':float(np.percentile(q,2.5)) if len(q) else np.nan,'delta_deviance_CI975':float(np.percentile(q,97.5)) if len(q) else np.nan,'delta_AIC_CI025':float(np.percentile(a,2.5)) if len(a) else np.nan,'delta_AIC_CI975':float(np.percentile(a,97.5)) if len(a) else np.nan,'positive_direction_fraction':float(np.mean(rep.interaction_direction_summary.eq('POSITIVE'))),'negative_direction_fraction':float(np.mean(rep.interaction_direction_summary.eq('NEGATIVE'))),'mixed_direction_fraction':float(np.mean(rep.interaction_direction_summary.eq('MIXED'))),'zero_direction_fraction':float(np.mean(rep.interaction_direction_summary.eq('ZERO')))}); grass25=grass_stability(b,elig) if s==25 else grass25
  except Exception as e: failures.append({'stage':'model','scale_km':s,'error':repr(e)})
 if grass25 is not None: grass25.to_csv(OUT/'GRASS_COVERAGE_STABILITY.csv',index=False)
 pd.DataFrame(ms).to_csv(OUT/'INTERACTION_RESULTS_SUMMARY.csv',index=False); pd.DataFrame(bs).to_csv(OUT/'BOOTSTRAP_SUMMARY.csv',index=False); primary=pd.DataFrame(ms); verdict='NO_STABLE_STRUCTURE'
 if len(primary):
  p=primary.loc[primary.scale_km.eq(25)].iloc[0]; b=pd.DataFrame(bs); inter=bool(p.LRT_p<0.05 and p.delta_deviance_M0_minus_M1>0 and float(b.loc[b.scale_km.eq(25),'M1_better_than_M0_fraction'].iloc[0])>=.95); cross=bool(len(b)>=3 and np.all(b.loc[b.scale_km.isin([10,50]),'M1_better_than_M0_fraction'].to_numpy()>=.5)); g=pd.read_csv(OUT/'GRASS_COVERAGE_STABILITY.csv') if (OUT/'GRASS_COVERAGE_STABILITY.csv').exists() else pd.DataFrame(); common=bool(len(g) and int((g.R_count_GRASS_observed>1).sum())>=10 and int(g.bootstrap_interval_entirely_gt_1.sum())>=5); verdict='COVERAGE_HETEROGENEITY_SUPPORTED' if inter and cross else 'GRASS_COMMON_PATTERN_WITH_DEVIATIONS' if common else 'NO_STABLE_STRUCTURE'
 report=['# TUNDRA13 category-spectrum model','', 'ARTIFACT_STATUS: COMPLETE','ANALYSIS_STATUS: REBUILT_13_COVERAGE_BLOCK_INTERACTION','',f'最终裁决：**{verdict}**','', f'主分析：{len(TARGET)}个预先冻结DARTS 2023 coverage；25 km主尺度，10/50 km敏感性；每coverage内按block有放回bootstrap，1000次。','',f'跨coverage可比较类别：{", ".join(elig.loc[elig.eligible_for_interaction,"community"].tolist())}.','', '已有paired-block结果仅为50 km R_count重算，没有coverage×vegetation M0/M1交互检验，本轮为NEW_ANALYSIS。','本轮未加入NWT、APTC、D128、Yamal或其他独立热点；未修改上游。','所有零RTS块被审计计数，并从条件于RTS存在的模型中排除。']
 (OUT/'FINAL_DARTS_INTERACTION_VERDICT.md').write_text('\n'.join(report)+'\n',encoding='utf-8'); pd.DataFrame(failures).to_csv(OUT/'FAILURE_LOG.csv',index=False)
 params={'target_coverages':TARGET,'scales_km':SCALES,'grid_origin_epsg6933_m':[0,0],'rts_input':'V2 frozen 2023 RTS assignments','background_input':'V2 frozen 500m background grids','eligible_category_rule':{'coverage_with_background_min':3,'coverage_with_RTS_min':3,'total_RTS_min':30},'bootstrap_n':NBOOT,'seed':SEED,'model':'profiled Poisson log-link with block fixed effects; M0 vegetation; M1 coverage:vegetation; offset log(background_area_km2)','zero_block_rule':'counted and excluded from conditional-on-RTS model'}; (OUT/'PARAMETERS.json').write_text(json.dumps(params,indent=2),encoding='utf-8')
 hs=[]
 for pth in sorted(OUT.rglob('*')):
  if pth.is_file() and pth.name!='OUTPUT_HASHES.csv': hs.append({'path':str(pth),'sha256':sha256(pth),'bytes':pth.stat().st_size})
 pd.DataFrame(hs).to_csv(OUT/'OUTPUT_HASHES.csv',index=False); (OUT/'RUN_STATE.md').write_text('ARTIFACT_STATUS: COMPLETE\nANALYSIS_STATUS: FORMAL_BLOCK_LEVEL_INTERACTION\nUPSTREAM_MODIFIED: NO\nR_count_DEFINITION_MODIFIED: NO\nVEGETATION_PRODUCT_MODIFIED: NO\n',encoding='utf-8'); print(json.dumps({'verdict':verdict,'models':ms,'bootstrap':bs},ensure_ascii=False,default=str))
if __name__=='__main__': main()
