from pathlib import Path
import hashlib, importlib.util, json, time
import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.optimize import minimize
from scipy.special import logsumexp

ROOT = Path(r"E:\zuom\gu")
ROUND = ROOT / "RUNS" / "ROUND_20260828_01"
BASE = ROUND / "RTS_TUNDRA13_FULL_REANALYSIS_V1"
OUT = BASE / "results" / "CLASS_DEPENDENCE"
OUT.mkdir(parents=True, exist_ok=True)
MANIFEST_PATH = BASE / "TUNDRA13_COVERAGE_MANIFEST.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
IDS = MANIFEST["coverage_ids"]
CATS = ["GRASS_HERBACEOUS", "SHRUB", "MOSS_LICHEN", "FOREST", "WETLAND", "SPARSE_BARE"]
DROP = ["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE"]
NBOOT = 1000
SEED_BASE = 20260907
BOOT_SEED = SEED_BASE + 500  # same frozen 25-km spatial-bootstrap seed as the 13-zone main analysis
BLOCK_M = 25000
TR = Transformer.from_crs(4326, 6933, always_xy=True)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_manifest_and_raw():
    if len(IDS) != 13 or len(set(IDS)) != 13 or "DARTS2023_COV_024" in IDS:
        raise RuntimeError("Frozen 13-coverage manifest failed validation")
    spec = importlib.util.spec_from_file_location("transfer13", BASE / "scripts" / "run_transfer_13.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _, _, hashes = mod.verify_inputs()
    if len(hashes) != 2 * len(IDS) or set(hashes.coverage_id) != set(IDS):
        raise RuntimeError("Expected exactly two verified per-coverage inputs for each manifest coverage")
    return hashes


def build_inputs(hashes):
    qfile = ROUND / "RTS_SHARED_RULE_BLIND_RECONSTRUCTION_FINAL_AUDIT_V1" / "Q_BACKGROUND_GRID_INDEPENDENT.csv.gz"
    bg = pd.read_csv(qfile, compression="gzip", usecols=["coverage_id", "center_lon", "center_lat", "coverage_intersection_area_m2", "community"])
    bg = bg[bg.coverage_id.isin(IDS) & bg.community.isin(CATS)].copy()
    bg["area"] = pd.to_numeric(bg.coverage_intersection_area_m2, errors="coerce").fillna(0.0)
    bx, by = TR.transform(bg.center_lon.to_numpy(float), bg.center_lat.to_numpy(float))
    bg["ix"] = np.floor(np.asarray(bx) / BLOCK_M).astype(np.int64)
    bg["iy"] = np.floor(np.asarray(by) / BLOCK_M).astype(np.int64)
    bg["block"] = bg.ix.astype(str) + "_" + bg.iy.astype(str)

    ymat, qmat, bg_by, y_by, block_counts = [], [], [], [], []
    raw_hash_rows = []
    for cid in IDS:
        ir = hashes[(hashes.role == "RTS_ASSIGNMENTS") & (hashes.coverage_id == cid)].iloc[0]
        rpath = Path(ir.path)
        r = pd.read_csv(rpath, usecols=["rts_id", "centroid_lon", "centroid_lat", "community"])
        if r.rts_id.astype(str).duplicated().any():
            raise RuntimeError(f"Duplicate RTS IDs in {cid}")
        r = r[r.community.isin(CATS)].copy()
        rx, ry = TR.transform(r.centroid_lon.to_numpy(float), r.centroid_lat.to_numpy(float))
        r["ix"] = np.floor(np.asarray(rx) / BLOCK_M).astype(np.int64)
        r["iy"] = np.floor(np.asarray(ry) / BLOCK_M).astype(np.int64)
        r["block"] = r.ix.astype(str) + "_" + r.iy.astype(str)
        y = r.community.value_counts().reindex(CATS, fill_value=0).to_numpy(dtype=int)
        ymat.append(y)

        b = bg[bg.coverage_id.eq(cid)]
        areas = b.groupby(["block", "community"]).area.sum().unstack(fill_value=0).reindex(columns=CATS, fill_value=0)
        cnt = r.groupby(["block", "community"]).size().unstack(fill_value=0).reindex(index=areas.index, columns=CATS, fill_value=0)
        ba, yn = areas.to_numpy(float), cnt.to_numpy(int)
        if set(r.block) - set(areas.index):
            raise RuntimeError(f"RTS centroid outside independent background block support: {cid}")
        if (ba.sum(axis=1) <= 0).any():
            raise RuntimeError(f"Zero-area retained background block in {cid}")
        if not np.array_equal(yn.sum(axis=0), y):
            raise RuntimeError(f"RTS block counts do not close to per-coverage class totals: {cid}")
        bg_by.append(ba)
        y_by.append(yn)
        block_counts.append(len(ba))
        qmat.append(ba.sum(axis=0) / ba.sum())
        raw_hash_rows.append({"coverage_id": cid, "role": "RTS_ASSIGNMENTS", "path": str(rpath), "sha256": ir.sha256, "bytes": ir.bytes})
        ib = hashes[(hashes.role == "BACKGROUND_GRID") & (hashes.coverage_id == cid)].iloc[0]
        raw_hash_rows.append({"coverage_id": cid, "role": "BACKGROUND_GRID", "path": ib.path, "sha256": ib.sha256, "bytes": ib.bytes})
    return np.asarray(qmat), np.asarray(ymat), bg_by, y_by, block_counts, qfile, raw_hash_rows


def fit_beta(q, y, ref_idx, class_names=None):
    q, y = np.asarray(q, float), np.asarray(y, float)
    class_names = list(class_names) if class_names is not None else CATS
    if len(class_names) != q.shape[1]:
        raise RuntimeError("Reference-label category list must match the fitted composition dimension")
    n = y.sum(axis=1)
    active = (n > 0) & (q.sum(axis=1) > 0)
    q, y, n = q[active], y[active], n[active]
    if len(n) < 2:
        raise RuntimeError("Insufficient training coverages")
    if np.any((q == 0) & (y > 0)):
        raise RuntimeError("q=0 with positive RTS count; no pseudocount is permitted")
    obs = y / n[:, None]
    logq = np.full_like(q, -np.inf)
    np.log(q, out=logq, where=q > 0)
    weights = np.full(len(n), 1.0 / len(n))
    free = np.array([k for k in range(q.shape[1]) if k != ref_idx], dtype=int)

    def fg(x):
        beta = np.zeros(q.shape[1])
        beta[free] = x
        z = logq + beta[None, :]
        lp = z - logsumexp(z, axis=1, keepdims=True)
        p = np.exp(lp)
        loss = -np.sum(weights[:, None] * obs * np.where(obs > 0, lp, 0.0))
        grad = np.sum(weights[:, None] * (p - obs), axis=0)[free]
        return float(loss), grad

    res = minimize(fg, np.zeros(len(free)), jac=True, method="BFGS", options={"gtol": 1e-10, "maxiter": 1000})
    beta = np.zeros(q.shape[1])
    beta[free] = res.x
    loss, grad = fg(res.x)
    if not np.isfinite(beta).all() or np.max(np.abs(grad)) > 2e-6:
        raise RuntimeError(f"Shared-fit convergence failure: {res.message}; max_grad={np.max(np.abs(grad))}")
    return beta, {"objective": float(loss), "max_abs_gradient": float(np.max(np.abs(grad))), "n_training_coverages": int(len(n)), "n_training_RTS": int(n.sum()), "reference_class": class_names[ref_idx]}


def predict(q, beta):
    q = np.asarray(q, float)
    z = np.full(len(q), -np.inf)
    np.log(q, out=z, where=q > 0)
    z += beta
    return np.exp(z - logsumexp(z))


def tv(a, b):
    return float(0.5 * np.abs(np.asarray(a, float) - np.asarray(b, float)).sum())


def choose_refs(retained):
    primary = "MOSS_LICHEN" if "GRASS_HERBACEOUS" not in retained else "GRASS_HERBACEOUS"
    # A different retained class is used as a numerical parameterization check.
    alt = next(c for c in retained if c != primary)
    return retained.index(primary), retained.index(alt)


def point_loco(qbase, ybase, dropped, retained):
    loc = {c: i for i, c in enumerate(CATS)}
    ix = [loc[c] for c in retained]
    q = qbase[:, ix].copy()
    y = ybase[:, ix].copy()
    q /= q.sum(axis=1, keepdims=True)
    n = y.sum(axis=1)
    if (n <= 0).any():
        raise RuntimeError(f"A coverage has no retained RTS after dropping {dropped}")
    obs = y / n[:, None]
    ref, alt_ref = choose_refs(retained)
    folds = []
    max_ref_prediction_diff = 0.0
    for t, cid in enumerate(IDS):
        tr = np.arange(len(IDS)) != t
        beta, fit_info = fit_beta(q[tr], y[tr], ref, retained)
        p = predict(q[t], beta)
        beta_alt, _ = fit_beta(q[tr], y[tr], alt_ref, retained)
        p_alt = predict(q[t], beta_alt)
        max_ref_prediction_diff = max(max_ref_prediction_diff, float(np.max(np.abs(p - p_alt))))
        if max_ref_prediction_diff > 2e-7:
            raise RuntimeError(f"Prediction changed under reference-class reparameterization ({dropped})")
        ta, tb = tv(obs[t], q[t]), tv(obs[t], p)
        g = (ta - tb) / ta if ta > 0 else np.nan
        folds.append({
            "drop_class": dropped,
            "coverage_id": cid,
            "retained_RTS_n": int(n[t]),
            "retained_background_classes": "|".join(retained),
            "reference_class": retained[ref],
            "TV_area_baseline": ta,
            "TV_shared": tb,
            "delta_TV": ta - tb,
            "G": g,
            "improved": bool(g > 0) if np.isfinite(g) else False,
            "training_coverage_n": int(fit_info["n_training_coverages"]),
            "training_RTS_n": int(fit_info["n_training_RTS"]),
            "max_ref_prediction_diff": max_ref_prediction_diff,
        })
    return folds, max_ref_prediction_diff


def full_model_contributions():
    preds = pd.read_csv(BASE / "results" / "TUNDRA13_LOCO_PREDICTIONS.csv")
    preds = preds[preds.branch.eq("coverage_equal")]
    folds = []
    tvrows, llrows = [], []
    anomalies = []
    for cid in IDS:
        d = preds[preds.coverage_id.eq(cid)].set_index("vegetation_class").reindex(CATS)
        q, s, p = d.q_background.to_numpy(float), d.observed_share.to_numpy(float), d.predicted_share.to_numpy(float)
        if not np.isclose(q.sum(), 1, atol=1e-10) or not np.isclose(s.sum(), 1, atol=1e-10) or not np.isclose(p.sum(), 1, atol=1e-10):
            raise RuntimeError(f"Full model prediction/observed/background composition does not sum to 1 in {cid}")
        invalid = (s > 0) & ((q <= 0) | (p <= 0))
        if invalid.any():
            anomalies.extend({"coverage_id": cid, "vegetation_class": CATS[k], "observed_share": s[k], "q_background": q[k], "predicted_share": p[k]} for k in np.where(invalid)[0])
            raise RuntimeError(f"Positive observed share with zero q/p, no pseudocount allowed: {cid}")
        d_tv = 0.5 * (np.abs(s - q) - np.abs(s - p))
        d_ll = np.zeros(len(CATS), dtype=float)
        positive = s > 0
        d_ll[positive] = s[positive] * np.log(p[positive] / q[positive])
        ta, tb = tv(s, q), tv(s, p)
        ll_total = float(d_ll.sum())
        if abs(float(d_tv.sum()) - (ta - tb)) > 1e-10:
            raise RuntimeError(f"ΔTV class contributions do not close for {cid}")
        if abs(ll_total - float(np.log(p[positive] / q[positive]) @ s[positive])) > 1e-12:
            raise RuntimeError(f"ΔLL class contributions do not close for {cid}")
        folds.append({"coverage_id": cid, "TV_area": ta, "TV_shared": tb, "TV_improvement": ta - tb, "delta_LL_per_RTS": ll_total, "delta_TV_class_sum": float(d_tv.sum()), "delta_LL_class_sum": ll_total})
        for k, c in enumerate(CATS):
            tvrows.append({"coverage_id": cid, "vegetation_class": c, "observed_share": s[k], "area_baseline_share": q[k], "shared_prediction_share": p[k], "delta_TV_contribution": d_tv[k]})
            llrows.append({"coverage_id": cid, "vegetation_class": c, "observed_share": s[k], "area_baseline_share": q[k], "shared_prediction_share": p[k], "delta_LL_contribution_per_RTS": d_ll[k]})
    tvdf, lldf, fdf = pd.DataFrame(tvrows), pd.DataFrame(llrows), pd.DataFrame(folds)
    tvdf.to_csv(OUT / "FULL_MODEL_CLASS_TV_CONTRIBUTION.csv", index=False)
    lldf.to_csv(OUT / "FULL_MODEL_CLASS_LOGSCORE_CONTRIBUTION.csv", index=False)
    fdf.to_csv(OUT / "FULL_MODEL_CLASS_CONTRIBUTION_CLOSURE.csv", index=False)
    summary = []
    for c in CATS:
        a = tvdf[tvdf.vegetation_class.eq(c)].delta_TV_contribution
        b = lldf[lldf.vegetation_class.eq(c)].delta_LL_contribution_per_RTS
        summary.append({
            "vegetation_class": c,
            "coverage_equal_mean_delta_TV": float(a.mean()),
            "median_delta_TV": float(a.median()),
            "positive_delta_TV_coverage_n": int((a > 0).sum()),
            "negative_delta_TV_coverage_n": int((a < 0).sum()),
            "total_signed_delta_TV_across_13": float(a.sum()),
            "positive_delta_TV_sum": float(a[a > 0].sum()),
            "fraction_of_all_positive_delta_TV": float(a[a > 0].sum() / tvdf.groupby("vegetation_class").delta_TV_contribution.apply(lambda z: z[z > 0].sum()).sum()),
            "coverage_equal_mean_delta_LL_per_RTS": float(b.mean()),
            "median_delta_LL_per_RTS": float(b.median()),
            "positive_delta_LL_coverage_n": int((b > 0).sum()),
            "negative_delta_LL_coverage_n": int((b < 0).sum()),
            "total_signed_delta_LL_across_13": float(b.sum()),
            "positive_delta_LL_sum": float(b[b > 0].sum()),
            "fraction_of_all_positive_delta_LL": float(b[b > 0].sum() / lldf.groupby("vegetation_class").delta_LL_contribution_per_RTS.apply(lambda z: z[z > 0].sum()).sum()),
        })
    summary = pd.DataFrame(summary)
    summary.to_csv(OUT / "CLASS_CONTRIBUTION_SUMMARY.csv", index=False)
    return summary, fdf


def main():
    t0 = time.time()
    hashes = verify_manifest_and_raw()
    qbase, ybase, bg_by, y_by, block_counts, qfile, unit_hashes = build_inputs(hashes)
    rcount = pd.read_csv(BASE / "results" / "TUNDRA13_RCOUNT_ALL_CLASSES.csv")
    sample = pd.read_csv(BASE / "results" / "TUNDRA13_FORMAL_SAMPLE.csv")
    formal_folds = pd.read_csv(BASE / "results" / "TUNDRA13_LOCO_FOLDS.csv")
    full_boot = pd.read_csv(BASE / "results" / "TUNDRA13_SPATIAL_BOOTSTRAP_REPLICATES.csv")
    bootstrap_gate = json.loads((OUT / "FULL_BOOTSTRAP_REPLAY_GATE.json").read_text(encoding="utf-8"))
    if bootstrap_gate.get("status") != "PASS" or bootstrap_gate.get("replicates") != NBOOT or bootstrap_gate.get("max_abs_G_vector_difference", 1.0) > 2e-8:
        raise RuntimeError("Full six-class bootstrap random-stream reproduction gate is absent or failed")
    blindq = pd.read_csv(BASE / "results" / "TUNDRA13_BACKGROUND_BLIND_Q.csv").set_index("coverage_id")
    if int(rcount.RTS_n.sum()) != 11189 or int(sample.effective_six_class_RTS_n.sum()) != 11189:
        raise RuntimeError("Formal 13-zone six-class sample does not close at 11,189")
    if not np.array_equal(ybase.sum(axis=1), sample.set_index("coverage_id").loc[IDS].effective_six_class_RTS_n.to_numpy(dtype=int)):
        raise RuntimeError("Class dependence raw RTS counts differ from formal sample table")
    # Confirm reconstructed independent q agrees with the current 13-zone q table.
    max_q_diff = 0.0
    for i, cid in enumerate(IDS):
        q_saved = np.array([blindq.loc[cid, f"q_{c}"] for c in CATS], dtype=float)
        max_q_diff = max(max_q_diff, float(np.max(np.abs(qbase[i] - q_saved))))
    if max_q_diff > 1e-12:
        raise RuntimeError(f"Recomputed background proportions differ from formal 13-zone source: {max_q_diff}")

    # Full-model point-fold reproduction gate before class deletion.
    full_ref_idx = CATS.index("GRASS_HERBACEOUS")
    point_check = []
    for t, cid in enumerate(IDS):
        tr = np.arange(len(IDS)) != t
        beta, _ = fit_beta(qbase[tr], ybase[tr], full_ref_idx)
        p = predict(qbase[t], beta)
        s = ybase[t] / ybase[t].sum()
        ta, tb = tv(s, qbase[t]), tv(s, p)
        g = (ta - tb) / ta
        old = formal_folds[formal_folds.coverage_id.eq(cid)].iloc[0]
        point_check.append({"coverage_id": cid, "G_rebuilt": g, "G_formal": float(old.G_shared_reconstruction), "abs_diff": abs(g - float(old.G_shared_reconstruction)), "training_n": int(tr.sum())})
    point_check_df = pd.DataFrame(point_check)
    point_max_diff = float(point_check_df.abs_diff.max())
    if point_max_diff > 2e-8 or not (point_check_df.training_n == 12).all():
        raise RuntimeError(f"Full 6-class LOCO reproduction gate failed; max G difference={point_max_diff}")

    # Paired spatial resampling indices: same RNG, 25-km blocks, and seed as main analysis.
    # First verify the complete six-class bootstrap against the already frozen output.
    rng = np.random.default_rng(BOOT_SEED)
    drop_boot_rows = {d: [] for d in DROP}
    drop_counts_by_rep = {d: [] for d in DROP}
    fails = {d: [] for d in DROP}
    started = time.time()
    for rep in range(1, NBOOT + 1):
        idx_by_cov = [rng.integers(0, len(b), size=len(b)) for b in bg_by]
        qboot_full, yboot_full = [], []
        for ba, ya, ix in zip(bg_by, y_by, idx_by_cov):
            bsum = ba[ix].sum(axis=0)
            nsum = ya[ix].sum(axis=0)
            qboot_full.append(bsum / bsum.sum())
            yboot_full.append(nsum)
        qboot_full, yboot_full = np.asarray(qboot_full), np.asarray(yboot_full)
        for dropped in DROP:
            retained = [c for c in CATS if c != dropped]
            idx = [CATS.index(c) for c in retained]
            qboot, yboot = qboot_full[:, idx].copy(), yboot_full[:, idx].copy()
            qboot /= qboot.sum(axis=1, keepdims=True)
            retained_n = yboot.sum(axis=1)
            if (retained_n <= 0).any():
                fails[dropped].append({"replicate": rep, "reason": "zero_retained_RTS_in_coverage"})
                continue
            ref_idx, _ = choose_refs(retained)
            gvals = []
            try:
                for t in range(len(IDS)):
                    tr = np.arange(len(IDS)) != t
                    beta, _ = fit_beta(qboot[tr], yboot[tr], ref_idx, retained)
                    pr = predict(qboot[t], beta)
                    obs = yboot[t] / retained_n[t]
                    ta, tb = tv(obs, qboot[t]), tv(obs, pr)
                    gvals.append((ta - tb) / ta if ta > 0 else np.nan)
                med = float(np.nanmedian(gvals))
                drop_boot_rows[dropped].append({"drop_class": dropped, "replicate": rep, "median_G": med, "mean_G": float(np.nanmean(gvals)), "positive_coverage_n": int(np.sum(np.asarray(gvals) > 0)), "G_by_coverage": "|".join(f"{v:.10g}" for v in gvals), "retained_RTS_n_total": int(retained_n.sum()), "failed_fold_n": 0, "reference_class": retained[ref_idx]})
                drop_counts_by_rep[dropped].append(int(retained_n.sum()))
            except Exception as exc:
                fails[dropped].append({"replicate": rep, "reason": str(exc)})
        # The frozen main bootstrap uses the same RNG for a two-level object
        # bootstrap immediately after each spatial replicate. Consume those
        # same draws so subsequent spatial block draws stay on the exact stream.
        sampled_targets = rng.integers(0, len(IDS), size=len(IDS))
        for target in np.unique(sampled_targets):
            training_draw = rng.choice([j for j in range(len(IDS)) if j != target], size=len(IDS) - 1, replace=True)
            for j in training_draw:
                nj = int(ybase[j].sum())
                rng.multinomial(nj, ybase[j] / nj)
            nt = int(ybase[target].sum())
            rng.multinomial(nt, ybase[target] / nt)
        if rep % 25 == 0:
            print(f"completed spatial bootstrap replicate {rep}/{NBOOT}; elapsed={time.time()-started:.1f}s", flush=True)

    # The RNG stream was independently replayed against all saved full-model
    # G vectors before this run. The saved full-model coefficients/scores are
    # not used to fit any class-dropped branch.
    bootstrap_full_max_diff = float(bootstrap_gate["max_abs_G_vector_difference"])

    # Point LOCO results for each class-deletion scenario.
    all_folds, summaries, refcheck = [], [], []
    for dropped in DROP:
        retained = [c for c in CATS if c != dropped]
        folds, refdiff = point_loco(qbase, ybase, dropped, retained)
        all_folds.extend(folds)
        refcheck.append({"drop_class": dropped, "primary_reference": folds[0]["reference_class"], "max_prediction_difference_alternative_reference": refdiff})
        f = pd.DataFrame(folds)
        summaries.append({
            "drop_class": dropped,
            "retained_classes": "|".join(retained),
            "retained_RTS_n_total": int(f.retained_RTS_n.sum()),
            "positive_coverage_n": int(f.improved.sum()),
            "coverage_n": len(IDS),
            "median_G": float(f.G.median()),
            "mean_G": float(f.G.mean()),
            "median_TV_A": float(f.TV_area_baseline.median()),
            "median_TV_B": float(f.TV_shared.median()),
            "median_absolute_delta_TV": float(f.delta_TV.abs().median()),
            "G_min": float(f.G.min()),
            "G_max": float(f.G.max()),
            "reference_class": folds[0]["reference_class"],
            "max_ref_prediction_diff": refdiff,
        })
    folds_df = pd.DataFrame(all_folds)
    summaries_df = pd.DataFrame(summaries)
    folds_df.to_csv(OUT / "LOCO_DROP_ONE_CLASS_FOLDS.csv", index=False)
    summaries_df.to_csv(OUT / "LOCO_DROP_ONE_CLASS_SUMMARY.csv", index=False)
    pd.DataFrame(refcheck).to_csv(OUT / "REFERENCE_CLASS_INVARIANCE.csv", index=False)

    # Bootstrap summaries for all six dropped-class scenarios.
    boot_all = pd.concat([pd.DataFrame(drop_boot_rows[d]) for d in DROP if drop_boot_rows[d]], ignore_index=True)
    boot_all.to_csv(OUT / "BOOTSTRAP_DROP_ONE_CLASS_REPLICATES.csv", index=False)
    fail_rows = [{"drop_class": d, **x} for d in DROP for x in fails[d]]
    pd.DataFrame(fail_rows, columns=["drop_class", "replicate", "reason"]).to_csv(OUT / "BOOTSTRAP_FAILURES.csv", index=False)
    boot_summaries = []
    for dropped in DROP:
        d = boot_all[boot_all.drop_class.eq(dropped)]
        vals = d.median_G.dropna().to_numpy(float)
        boot_summaries.append({
            "drop_class": dropped,
            "replicates_requested": NBOOT,
            "replicates_valid": int(len(vals)),
            "replicates_failed": int(NBOOT - len(vals)),
            "point_median_G": float(summaries_df.loc[summaries_df.drop_class.eq(dropped), "median_G"].iloc[0]),
            "spatial_bootstrap_median_G": float(np.median(vals)) if len(vals) else np.nan,
            "ci025": float(np.quantile(vals, .025)) if len(vals) else np.nan,
            "ci975": float(np.quantile(vals, .975)) if len(vals) else np.nan,
            "P_G_gt_0": float(np.mean(vals > 0)) if len(vals) else np.nan,
            "positive_coverage_n_median": float(d.positive_coverage_n.median()) if len(d) else np.nan,
            "seed": BOOT_SEED,
        })
    boot_summary_df = pd.DataFrame(boot_summaries)
    boot_summary_df.to_csv(OUT / "BOOTSTRAP_DROP_ONE_CLASS_SUMMARY.csv", index=False)

    contribution_summary, closure = full_model_contributions()

    # Full six-class source-closure and zero-support checks.
    expected_drop_counts = {c: int(rcount.loc[rcount.vegetation.eq(c), "RTS_n"].sum()) for c in CATS}
    count_closure = []
    for row in summaries_df.itertuples(index=False):
        expected = 11189 - expected_drop_counts[row.drop_class]
        count_closure.append({"drop_class": row.drop_class, "expected_retained_RTS_n": expected, "observed_retained_RTS_n": row.retained_RTS_n_total, "closed": expected == row.retained_RTS_n_total})
    count_closure_df = pd.DataFrame(count_closure)
    if not count_closure_df.closed.all():
        raise RuntimeError("Drop-one-class retained RTS totals do not close")
    if not (folds_df.training_coverage_n == 12).all():
        raise RuntimeError("A drop-class fold did not use 12 training coverages")
    if not (boot_summary_df.replicates_valid == NBOOT).all():
        raise RuntimeError("At least one class-drop bootstrap replicate failed; inspect failures before release")
    if not np.allclose(closure.delta_TV_class_sum, closure.TV_improvement, rtol=0, atol=1e-10).all():
        raise RuntimeError("Full-model ΔTV decomposition closure failure")
    if not np.allclose(closure.delta_LL_class_sum, closure.delta_LL_per_RTS, rtol=0, atol=1e-10).all():
        raise RuntimeError("Full-model ΔLL decomposition closure failure")

    # Audit/protocol artifacts.
    pd.DataFrame(count_closure).to_csv(OUT / "DROP_SAMPLE_CLOSURE.csv", index=False)
    input_files = [
        (MANIFEST_PATH, "frozen 13-coverage manifest"),
        (ROUND / "RTS_SHARED_RULE_BLIND_RECONSTRUCTION_FINAL_AUDIT_V1" / "Q_BACKGROUND_GRID_INDEPENDENT.csv.gz", "independent per-anchor background labels and areas"),
        (BASE / "results" / "TUNDRA13_BACKGROUND_BLIND_Q.csv", "current 13-zone recomputed background composition closure"),
        (BASE / "results" / "TUNDRA13_RCOUNT_ALL_CLASSES.csv", "current 13-zone category object totals"),
        (BASE / "results" / "TUNDRA13_FORMAL_SAMPLE.csv", "current 13-zone sample closure"),
        (BASE / "results" / "TUNDRA13_LOCO_FOLDS.csv", "current six-class point LOCO benchmark"),
        (BASE / "results" / "TUNDRA13_LOCO_PREDICTIONS.csv", "current six-class observed/background/predicted shares for contribution decomposition"),
        (BASE / "results" / "TUNDRA13_SPATIAL_BOOTSTRAP_REPLICATES.csv", "existing six-class seed-replay validation only"),
    ]
    hashrows = []
    for p, role in input_files:
        hashrows.append({"role": role, "path": str(p), "sha256": sha(p), "bytes": p.stat().st_size})
    hashrows.extend({"role": f"verified_{r.role}", "coverage_id": r.coverage_id, "path": r.path, "sha256": r.sha256, "bytes": r.bytes} for r in hashes.itertuples(index=False))
    pd.DataFrame(hashrows).to_csv(OUT / "INPUT_HASHES.csv", index=False)
    params = {
        "experiment": "TUNDRA13_SHARED_VEGETATION_CLASS_DEPENDENCE_AUDIT_V1",
        "coverage_ids": IDS,
        "excluded_coverage": "DARTS2023_COV_024",
        "input_valid_six_class_RTS_n": 11189,
        "model_class_order": CATS,
        "drop_one_class_order": DROP,
        "block_size_m": BLOCK_M,
        "block_grid_crs_epsg": 6933,
        "fit": "same coverage-equal multinomial composition likelihood, BFGS, gtol=1e-10, maxiter=1000, convergence max_abs_gradient<=2e-6",
        "zero_support": "no pseudocount; zero q with positive RTS count is a hard failure; zero observed share contributes zero log score",
        "metric": "TV=0.5*sum(abs(observed-predicted)); G=(TV_area-TV_shared)/TV_area",
        "bootstrap": {"type": "25-km within-coverage spatial block bootstrap with replacement; all background blocks retained in sampling frame, including zero-RTS blocks; block RTS counts and background areas resampled together", "replicates": NBOOT, "seed": BOOT_SEED, "paired_draws_across_drop_scenarios": True, "each_replicate_refits_all_13_LOCO_folds": True},
        "reference_class": "GRASS_HERBACEOUS when retained; MOSS_LICHEN for DROP_GRASS; alternate-reference prediction invariance tested on all point LOCO folds",
        "main_canonical_results_modified": False,
    }
    (OUT / "PARAMETERS.json").write_text(json.dumps(params, indent=2), encoding="utf-8")
    audit_lines = [
        "# Class-dependence audit",
        "",
        "**ARTIFACT_STATUS: COMPLETE**",
        "",
        "- Frozen manifest: 13/13 coverages; COV_024 absent.",
        "- Raw unit RTS and background assignment hashes: all verified PASS before loading.",
        "- Per-coverage six-class RTS totals sum to 11,189; drop-sample closure is recorded in `DROP_SAMPLE_CLOSURE.csv`.",
        "- Independent per-anchor q was recomputed from the current 13-zone background rows; max difference from the formal 13-zone q table: " + f"{max_q_diff:.3g}.",
        "- Full six-class 13-fold 12→1 point LOCO was independently reproduced before class deletion; max absolute G difference from the formal fold table: " + f"{point_max_diff:.3g}.",
        "- The 1,000 full-six-class spatial-bootstrap G vectors were exactly regenerated from the frozen 25-km block draw seed before running drop-class scenarios; maximum absolute difference: " + f"{bootstrap_full_max_diff:.3g}.",
        "- Each drop-class version retained 12 training coverages in every one of the 13 held-out folds; retained samples close to 11,189 minus the removed class count.",
        "- Bootstrap draws are paired across drop-class scenarios by reusing the same sampled 25-km blocks, while every scenario refits all 13 LOCO folds in each replicate.",
        "- All 6,000 class-category bootstrap LOCO evaluations are complete and valid; no pseudocount or class reassignment was used.",
        "- Point predictions under alternate reference-class parameterizations were invariant within the recorded tolerance; see `REFERENCE_CLASS_INVARIANCE.csv`.",
        "- Full-model signed class contributions close to overall TV and log-score improvements within 1e-10 in every coverage; no positive observed share had zero q or p.",
        "- Old 14-coverage model coefficients or aggregates were not used. The only existing six-class bootstrap table was used as a deterministic seed/method reproduction gate, not as a dropped-class fit input.",
        "- Existing canonical main results and figure files were not modified.",
    ]
    (OUT / "CLASS_DEPENDENCE_AUDIT.md").write_text("\n".join(audit_lines) + "\n", encoding="utf-8")

    # A compact progress/final log and result digest.
    status = {
        "coverage_n": len(IDS), "valid_RTS_n": 11189, "full_LOCO_max_abs_G_diff": point_max_diff,
        "full_bootstrap_max_abs_G_vector_diff": bootstrap_full_max_diff,
        "drop_scenarios": summaries_df.to_dict(orient="records"),
        "bootstrap_scenarios": boot_summary_df.to_dict(orient="records"),
        "contributions": contribution_summary.to_dict(orient="records"),
        "runtime_seconds": time.time() - t0,
    }
    (OUT / "RUN_SUMMARY.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    (OUT / "RUN_LOG.md").write_text(
        "# Run log\n\nARTIFACT_STATUS: COMPLETE\n\n"
        f"Completed 6 drop-one-class point LOCO suites and {NBOOT} paired 25-km spatial-bootstrap replicates per scenario. "
        f"All 6,000 bootstrap scenario replicates valid. Full six-class point LOCO reproduction max |ΔG|={point_max_diff:.3g}; "
        f"full bootstrap seed replay max |ΔG|={bootstrap_full_max_diff:.3g}. Runtime={time.time()-t0:.1f}s.\n",
        encoding="utf-8",
    )
    # Hash every result artifact except its own hash index.
    hashout = []
    for f in sorted(OUT.rglob("*")):
        if f.is_file() and f.name != "OUTPUT_HASHES.csv" and "__pycache__" not in f.parts:
            hashout.append({"path": str(f.relative_to(OUT)), "sha256": sha(f), "bytes": f.stat().st_size})
    pd.DataFrame(hashout).to_csv(OUT / "OUTPUT_HASHES.csv", index=False)
    print("CLASS_DEPENDENCE_COMPLETE")
    print(summaries_df.to_string(index=False))
    print(boot_summary_df.to_string(index=False))
    print(contribution_summary[["vegetation_class", "coverage_equal_mean_delta_TV", "fraction_of_all_positive_delta_TV", "coverage_equal_mean_delta_LL_per_RTS", "fraction_of_all_positive_delta_LL"]].to_string(index=False))
    print(f"full point LOCO max diff={point_max_diff:.3g}; bootstrap replay max diff={bootstrap_full_max_diff:.3g}; total runtime={time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
