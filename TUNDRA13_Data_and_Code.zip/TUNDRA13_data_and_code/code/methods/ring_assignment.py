from __future__ import annotations
import csv, hashlib, importlib.util, json, math, sqlite3, sys, time
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window
from rasterio.features import rasterize
from rasterio.transform import from_origin
from shapely import from_wkb, contains_xy, intersects_xy
from shapely.geometry import Point
from shapely.ops import unary_union, transform as shp_transform
from pyproj import Transformer

ROOT=Path(r'E:\zuom\gu'); ROUND=ROOT/'RUNS'/'ROUND_20260828_01'
OUT=ROUND/'RTS_RING_500_900_SENSITIVITY_20261026_V1'; OUT.mkdir(exist_ok=True)
RES=OUT/'results'; RES.mkdir(exist_ok=True)
BASE=ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'
MAN=json.loads((BASE/'TUNDRA13_COVERAGE_MANIFEST.json').read_text(encoding='utf-8'))
IDS=MAN['coverage_ids']; CATS=['GRASS_HERBACEOUS','SHRUB','MOSS_LICHEN','FOREST','WETLAND','SPARSE_BARE']
REF='GRASS_HERBACEOUS'; FREE=[i for i,c in enumerate(CATS) if c!=REF]
CACHE=ROUND/'DARTS16_WORLDCOVER_PRODUCT_SENSITIVITY_V1'/'worldcover_unit_cache'
SOURCE_INDEX=pd.read_csv(ROUND/'DARTS_BLOCK_VEGETATION_INTERACTION_V1'/'INPUT_HASHES.csv').set_index(['coverage_id','role'])
DATA=ROUND/'RTS_VEGETATION_COUPLING_BRIDGE_PUBLIC_RECHECK'/'public_sources'/'DARTS_v1_2'
TIF=ROUND/'CHERRYSTUDIO_PAPER_MIGRATION_V1'/'RTS_BRIDGE_SCREEN_V1'/'_veg'/'raw'/'PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif'
CW=ROUND/'RTS_VEGETATION_RESULTS_AND_CODE'/'FORMAL_RTS_COMMUNITY_ANALYSIS_V0_2'/'VEGETATION_CROSSWALK_V1.csv'
QFILE=ROUND/'RTS_SHARED_RULE_BLIND_RECONSTRUCTION_FINAL_AUDIT_V1'/'Q_BACKGROUND_GRID_INDEPENDENT.csv.gz'
SCALE=0.0009920634920634888; N_COLS=362880; N_ROWS=141120
RING_OLD=(100.,500.); RING_NEW=(500.,900.)
BLOCK=25000.; NBOOT=1000; BOOT_SEED=20261407

sys.path.insert(0,str(ROUND/'RTS_SAME_PLACE_LIFECYCLE_BRIDGE'/'_vendor'))
spec=importlib.util.spec_from_file_location('loader',ROUND/'RTS_VEGETATION_RESULTS_AND_CODE'/'FORMAL_RTS_COMMUNITY_ANALYSIS_V0_1'/'01_inventory_loader.py')
loader=importlib.util.module_from_spec(spec); spec.loader.exec_module(loader)
spec=importlib.util.spec_from_file_location('full',ROUND/'PEEL_FORMAL_FULL_2023_V1'/'run_full.py')
full=importlib.util.module_from_spec(spec); spec.loader.exec_module(full)

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def source_file(cid,role): return Path(SOURCE_INDEX.loc[(cid,role),'path'])

def assert_inputs():
    if sha(TIF)!='b2203d6dd8b6918e27cd1413e7dfec4a9e4ce03dbf50f209d7f04c550c23cf53': raise RuntimeError('CGLS hash mismatch')
    if len(IDS)!=13 or 'DARTS2023_COV_024' in IDS: raise RuntimeError('manifest mismatch')
    rows=[]
    paths=[TIF,CW,DATA/'features_level2.gpkg',DATA/'coverage_level2.gpkg',BASE/'TUNDRA13_COVERAGE_MANIFEST.json',BASE/'results'/'TUNDRA13_BACKGROUND_BLIND_Q.csv',BASE/'results'/'TUNDRA13_LOCO_FOLDS.csv',BASE/'results'/'TUNDRA13_RCOUNT_ALL_CLASSES.csv',OUT/'FROZEN_PROTOCOL.md',QFILE,Path(__file__),OUT/'full_analysis.py',OUT/'postprocess_report.py']
    for cid in IDS:
        paths += [source_file(cid,'RTS_ASSIGNMENTS'),source_file(cid,'BACKGROUND_GRID')]
        for role in ['RTS_ASSIGNMENTS','BACKGROUND_GRID']:
            actual=sha(source_file(cid,role)); expected=str(SOURCE_INDEX.loc[(cid,role),'sha256'])
            if actual.lower()!=expected.lower(): raise RuntimeError(f'upstream hash mismatch {cid}/{role}')
    for p in paths: rows.append({'path':str(p),'size_bytes':p.stat().st_size,'sha256':sha(p)})
    pd.DataFrame(rows).to_csv(OUT/'INPUT_HASHES.csv',index=False)
    return rows

def coverage_geometries():
    rows=loader.read_gpkg(DATA/'coverage_level2.gpkg')
    rows=[r for r in rows if int(r.get('year'))==2023]
    tr=Transformer.from_crs(4326,6933,always_xy=True)
    for r in rows:
        c=shp_transform(tr.transform,r['geometry']).centroid; r['_cx']=c.x; r['_cy']=c.y
    rows=sorted(rows,key=lambda r:(int(r['year']),r['_cx'],r['_cy'],float(r.get('area_km2',0))))
    # Manifest IDs encode canonical feature row indices, including excluded COV_024.
    id_by_index={int(x.rsplit('_',1)[1]):x for x in [*IDS,'DARTS2023_COV_024']}
    out={}
    for i,r in enumerate(rows,1):
        cid=id_by_index.get(i)
        if cid in IDS: out[cid]=r['geometry']
    if set(out)!=set(IDS): raise RuntimeError(f'coverage geometry key mismatch: {set(IDS)-set(out)}')
    return out

def frame_data(cid,coverage,features):
    f=[r for r in features if r['geometry'].centroid.within(coverage)]
    ex=[r['geometry'] for r in features if not r['geometry'].intersection(coverage).is_empty]
    return f,ex

def crop(cov,ex,src,margin=40):
    minx,miny,maxx,maxy=cov.bounds
    c0=max(0,int(math.floor((minx+180)/SCALE))-margin); c1=min(N_COLS-1,int(math.ceil((maxx+180)/SCALE))+margin)
    r0=max(0,int(math.floor((80-maxy)/SCALE))-margin); r1=min(N_ROWS-1,int(math.ceil((80-miny)/SCALE))+margin)
    w=c1-c0+1; h=r1-r0+1; data=src.read(1,window=Window(c0,r0,w,h),boundless=True,fill_value=255)
    trf=from_origin(-180+c0*SCALE,80-r0*SCALE,SCALE,SCALE)
    cm=rasterize([(cov,1)],out_shape=(h,w),transform=trf,all_touched=False).astype(bool)
    em=rasterize([(g,1) for g in ex],out_shape=(h,w),transform=trf,all_touched=False).astype(bool) if ex else np.zeros((h,w),bool)
    return data,cm,em,(r0,r1,c0,c1)

def extract_grid(grid,data,covmask,exmask,window,inner,outer,block_rows=2):
    """Vectorized exact pixel-center/UTM annulus extraction; only the batch size differs from upstream."""
    r0,r1,c0,c1=window; out=[]; groups=grid.groupby('grid_iy',sort=True)
    for _,rg in groups:
      zones=((rg.center_lon.astype(float)+180)//6+1).astype(int)+32600
      for zone,sub0 in rg.groupby(zones):
       # Split long rows to bound temporary arrays while preserving exact geometry.
       for start in range(0,len(sub0),100):
        sub=sub0.iloc[start:start+100].copy(); latmin=float(sub.center_lat.min())
        dlat=111320.*SCALE; dlon=dlat*max(math.cos(math.radians(latmin)),.01)
        dr=np.arange(-int(math.ceil(outer/dlat))-3,int(math.ceil(outer/dlat))+4)
        dc=np.arange(-int(math.ceil(outer/dlon))-3,int(math.ceil(outer/dlon))+4)
        drr,dcc=np.meshgrid(dr,dc,indexing='ij'); odr=drr.ravel(); odc=dcc.ravel()
        cg=np.floor((sub.center_lon.to_numpy(float)+180)/SCALE).astype(int)-c0
        rr0=np.floor((80-sub.center_lat.to_numpy(float))/SCALE).astype(int)-r0
        rr=rr0[:,None]+odr[None,:]; cc=cg[:,None]+odc[None,:]
        inside=(rr>=0)&(rr<data.shape[0])&(cc>=0)&(cc<data.shape[1]); rs=np.clip(rr,0,data.shape[0]-1); cs=np.clip(cc,0,data.shape[1]-1)
        vals=data[rs,cs]; tr=Transformer.from_crs(4326,int(zone),always_xy=True)
        cx,cy=tr.transform(sub.center_lon.to_numpy(float),sub.center_lat.to_numpy(float))
        plon=-180+(cs+c0+.5)*SCALE; plat=80-(rs+r0+.5)*SCALE
        px,py=tr.transform(plon.ravel(),plat.ravel()); px=np.asarray(px).reshape(plon.shape); py=np.asarray(py).reshape(plat.shape)
        d2=(px-np.asarray(cx)[:,None])**2+(py-np.asarray(cy)[:,None])**2
        geo=inside&(d2<=outer**2)&(d2>inner**2)&covmask[rs,cs]
        # For q, exmask is all False; for B it is the frozen RTS exclusion mask.
        if exmask is not None: geo &= ~exmask[rs,cs]
        valid=geo&(vals!=0)&(vals!=255); nvalid=valid.sum(axis=1).astype(int)
        nonveg=(valid&((vals==50)|(vals==70)|(vals==80)|(vals==200))).sum(axis=1).astype(int)
        counts=np.column_stack([(valid&(vals>=111)&(vals<=126)).sum(1),(valid&(vals==20)).sum(1),(valid&(vals==30)).sum(1),(valid&(vals==90)).sum(1),(valid&(vals==100)).sum(1),(valid&(vals==60)).sum(1)])
        other=nvalid-nonveg-counts.sum(1); allc=np.column_stack([counts,other]); win=allc.argmax(axis=1); comm=np.array(['FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE','OTHER'],object)[win]
        comm[nvalid==0]='NO_DATA_SUPPORT'; comm[(nvalid>0)&(nonveg/nvalid>.5)]='EXCLUDED_NON_VEGETATION'
        d=sub[['grid_id','grid_ix','grid_iy','center_lon','center_lat','coverage_intersection_area_m2']].copy()
        d['community']=comm; d['ring_pixel_n']=geo.sum(1).astype(int); d['raw_valid_pixel_n']=nvalid; d['nodata_pixel_n']=(geo&~valid).sum(1).astype(int); d['nonvegetation_pixel_n']=nonveg; d['other_pixel_n']=other
        out.append(d)
    return pd.concat(out,ignore_index=True)

def read_geometry_sources():
    return loader.read_gpkg(DATA/'features_level2.gpkg')

def object_pixels(g,coverage,ex,inner,outer):
    zone=32600+int((float(g.centroid.x)+180)//6)+1; fw=Transformer.from_crs(4326,zone,always_xy=True).transform; bw=Transformer.from_crs(zone,4326,always_xy=True).transform
    gm=shp_transform(fw,g); ring=shp_transform(bw,gm.buffer(outer).difference(gm.buffer(inner)))
    minx,miny,maxx,maxy=ring.bounds; c0=max(0,int((minx+180)/SCALE)-2); c1=min(N_COLS-1,int((maxx+180)/SCALE)+2); r0=max(0,int((80-maxy)/SCALE)-2); r1=min(N_ROWS-1,int((80-miny)/SCALE)+2)
    rows=np.arange(r0,r1+1); cols=np.arange(c0,c1+1); rr,cc=np.meshgrid(rows,cols,indexing='ij'); lon=-180+(cc+.5)*SCALE; lat=80-(rr+.5)*SCALE
    keep=intersects_xy(ring,lon,lat)&intersects_xy(coverage,lon,lat)
    if ex:
      # Exact point exclusion against union of mapped footprints intersecting coverage.
      exgeom=ex if hasattr(ex,'geom_type') else unary_union(ex)
      keep &= ~intersects_xy(exgeom,lon,lat)
    return rr[keep],cc[keep]

def modal(raw):
    # Fixed crosswalk/collapsed class rule and category tie order, with legacy water/ice majority gate.
    v=raw[(raw!=0)&(raw!=255)]; n=len(v)
    if n==0:return 'NO_DATA_SUPPORT',0,0,0
    nv=int(np.isin(v,[50,70,80,200]).sum())
    if nv/n>.5:return 'EXCLUDED_NON_VEGETATION',n,nv,int((v==255).sum())
    x=np.array([(v>=111)&(v<=126),v==20,v==30,v==90,v==100,v==60,~(((v>=111)&(v<=126))|(v==20)|(v==30)|(v==90)|(v==100)|(v==60)|np.isin(v,[50,70,80,200]))]).sum(axis=1)
    names=['FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE','OTHER']
    return names[int(np.argmax(x))],n,nv,int(np.isin(raw,[0,255]).sum())

def run_validation():
    # Exact deterministic 20-row sample per coverage, chosen from grid IDs before outer-ring results.
    samples={}; rows=[]
    covs=coverage_geometries(); feats=read_geometry_sources();
    with rasterio.open(TIF) as src:
      for cid in IDS:
        old=pd.read_csv(source_file(cid,'BACKGROUND_GRID')); old=old.sort_values('grid_id').reset_index(drop=True)
        ix=np.linspace(0,len(old)-1,min(20,len(old))).round().astype(int); sm=old.iloc[ix].drop_duplicates('grid_id'); samples[cid]=sm
        f,ex=frame_data(cid,covs[cid],feats); data,cm,em,win=crop(covs[cid],ex,src)
        # q uses same anchors and masks but no RTS exclusion.
        b=extract_grid(sm,data,cm,em,win,*RING_OLD); q=extract_grid(sm,data,cm,None,win,*RING_OLD)
        frame={'coverage':[covs[cid]],'exclusion':ex}
        ref_b=full.extract_grid_fast_raw(sm,frame,data,cm,em,win,full.crosswalk())
        ref_q=full.extract_grid_fast_raw(sm,frame,data,cm,np.zeros_like(em),win,full.crosswalk())
        refs={'B':ref_b,'q':ref_q}
        for label,actual,source in [('B',b,old),('q',q,None)]:
          ref=refs[label].set_index('grid_id').reindex(actual.grid_id)
          expected=source.set_index('grid_id').reindex(actual.grid_id) if source is not None else None
          for j,r in actual.iterrows():
            exp=expected.loc[r.grid_id] if expected is not None else None
            rr=ref.loc[r.grid_id]
            rows.append({'coverage_id':cid,'grid_id':r.grid_id,'branch':label,'community_new_impl':r.community,'community_old':exp.community if exp is not None else '', 'ring_pixel_n_new_impl':int(r.ring_pixel_n),'ring_pixel_n_old':int(exp.ring_pixel_n) if exp is not None else np.nan,'reference_legacy_impl_community':rr.community,'reference_legacy_impl_pixel_n':int(rr.ring_pixel_n),'label_match':bool(r.community==exp.community) if exp is not None else np.nan,'pixel_n_match':bool(r.ring_pixel_n==exp.ring_pixel_n) if exp is not None else np.nan,'reference_pixel_n_match':bool(rr.ring_pixel_n==exp.ring_pixel_n) if exp is not None else np.nan})
        print('validation_extract',cid,flush=True)
    print('validation_q_reproduction_start',flush=True)
    df=pd.DataFrame(rows); df.to_csv(RES/'OLD_RING_REPRODUCTION_SAMPLE.csv',index=False)
    # q old classes are checked from authoritative independent grid in a second, targeted streaming pass.
    qids=set(x.grid_id for s in samples.values() for x in s.itertuples())
    qold={}
    for ch in pd.read_csv(QFILE,compression='gzip',usecols=['coverage_id','grid_id','community'],chunksize=500000):
      m=ch.grid_id.isin(qids)&ch.coverage_id.isin(IDS)
      for x in ch.loc[m].itertuples(index=False): qold[(x.coverage_id,x.grid_id)]=x.community
      print('validation_q_chunk',len(qold),flush=True)
    m=df.branch.eq('q')
    for i,r in df[m].iterrows():
      old=qold.get((r.coverage_id,r.grid_id)); df.loc[i,'community_old']=old if old else ''
      df.loc[i,'label_match']=bool(old and r.community_new_impl==old); df.loc[i,'pixel_n_match']=np.nan
    df.to_csv(RES/'OLD_RING_REPRODUCTION_SAMPLE.csv',index=False)
    label_fail=int(df.label_match.ne(True).sum()); pixel_fail=int(df.loc[df.branch.eq('B'),'pixel_n_match'].ne(True).sum()); ref_pixel_fail=int(df.loc[df.branch.eq('B'),'reference_pixel_n_match'].ne(True).sum())
    nfail=label_fail
    (RES/'OLD_RING_REPRODUCTION_GATE.json').write_text(json.dumps({'sample_grid_n':int(df.grid_id.nunique()),'comparisons_n':len(df),'label_mismatch_n':label_fail,'B_pixel_count_mismatch_n_custom_vs_cache':pixel_fail,'B_pixel_count_mismatch_n_legacy_impl_vs_cache':ref_pixel_fail,'B_pixel_support_mismatch_rows':df.loc[df.branch.eq('B')&df.pixel_n_match.ne(True),['coverage_id','grid_id','ring_pixel_n_new_impl','ring_pixel_n_old']].to_dict('records'),'q_pixel_count_comparison':'NOT_AVAILABLE_IN_FROZEN_Q_SOURCE','status':'PASS_LABELS' if nfail==0 else 'FAIL'},indent=2),encoding='utf-8')
    if nfail: raise RuntimeError(f'old ring reproduction gate failed ({nfail}); outer-ring analysis prohibited')

def run_object_validation():
    covs=coverage_geometries(); feats=read_geometry_sources(); rows=[]
    with rasterio.open(TIF) as src:
      for cid in IDS:
        assignments=pd.read_csv(source_file(cid,'RTS_ASSIGNMENTS'))
        records=[r for r in feats if int(r.get('year',0))==2023 and covs[cid].contains(r['geometry'].centroid)]
        byid={str(r.get('id')):r for r in records}
        if set(assignments.rts_id.astype(str))!=set(byid): raise RuntimeError(f'object ID geometry mismatch: {cid}')
        ordered=sorted(assignments.rts_id.astype(str)); ix=np.linspace(0,len(ordered)-1,min(6,len(ordered))).round().astype(int); selected=list(dict.fromkeys(ordered[i] for i in ix)); sample=assignments[assignments.rts_id.astype(str).isin(selected)].copy(); sample['_id_sort']=sample.rts_id.astype(str); sample=sample.sort_values('_id_sort').drop(columns='_id_sort')
        ex=unary_union([r['geometry'] for r in feats if not r['geometry'].intersection(covs[cid]).is_empty])
        for _,a in sample.iterrows():
          g=byid[str(a.rts_id)]['geometry']; rr,cc=object_pixels(g,covs[cid],ex,*RING_OLD)
          if len(rr):
            r0,r1=int(rr.min()),int(rr.max()); c0,c1=int(cc.min()),int(cc.max()); arr=src.read(1,window=Window(c0,r0,c1-c0+1,r1-r0+1),boundless=True,fill_value=255); raw=arr[rr-r0,cc-c0]
          else: raw=np.array([],dtype=np.uint8)
          comm,nv,nnon,ninvalid=modal(raw)
          rows.append({'coverage_id':cid,'rts_id':str(a.rts_id),'old_community':a.community,'new_community':comm,'old_ring_pixel_n':int(a.ring_pixel_n),'new_ring_pixel_n':int(len(rr)),'community_match':comm==a.community,'pixel_n_match':int(a.ring_pixel_n)==len(rr),'old_valid_pixel_n':int(a.raw_valid_pixel_n),'new_valid_pixel_n':nv})
        print('object_validation_extract',cid,flush=True)
    df=pd.DataFrame(rows); df.to_csv(RES/'OLD_OBJECT_RING_REPRODUCTION_SAMPLE.csv',index=False)
    status='PASS_LABELS' if df.community_match.all() else 'FAIL'
    (RES/'OLD_OBJECT_RING_REPRODUCTION_GATE.json').write_text(json.dumps({'sample_object_n':len(df),'community_mismatch_n':int((~df.community_match).sum()),'pixel_count_mismatch_n':int((~df.pixel_n_match).sum()),'pixel_count_mismatch_rows':df.loc[~df.pixel_n_match,['coverage_id','rts_id','old_ring_pixel_n','new_ring_pixel_n']].to_dict('records'),'status':status},indent=2),encoding='utf-8')
    if status!='PASS_LABELS': raise RuntimeError('object old-ring label reproduction gate failed')

def main():
    t0=time.time(); assert_inputs()
    if '--object-only' in sys.argv: run_object_validation(); print('OBJECT_VALIDATION_PASS',time.time()-t0,flush=True); return
    run_validation()
    if '--background-only' in sys.argv: print('BACKGROUND_VALIDATION_PASS',time.time()-t0,flush=True); return
    run_object_validation(); print('VALIDATION_PASS',time.time()-t0,flush=True)
    # Full analysis is intentionally a separate explicit mode after successful frozen reproduction gate.
    if '--full' not in sys.argv: return
    raise NotImplementedError('full extraction driver is under construction; reproduction gate is complete')

if __name__=='__main__': main()
