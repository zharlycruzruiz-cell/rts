import sys, json, math, traceback, subprocess, importlib.util
from pathlib import Path
import numpy as np, pandas as pd

ROOT=Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01")
OUT=ROOT/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"physical"
spec=importlib.util.spec_from_file_location("phys",OUT/"scripts"/"run_physical_confounding_analysis.py")
P=importlib.util.module_from_spec(spec); sys.modules[spec.name]=P; spec.loader.exec_module(P)
LOG=[]
def say(s): print(s,flush=True); LOG.append(str(s))
def draws(blocks,rng):
 n=len(blocks); w=np.zeros((P.NBOOT_RCOUNT,n))
 if n:
  ix=rng.integers(0,n,size=(P.NBOOT_RCOUNT,n)); rr=np.broadcast_to(np.arange(P.NBOOT_RCOUNT)[:,None],ix.shape); np.add.at(w,(rr,ix),1)
 return w
def main():
 cp=subprocess.run([sys.executable,str(OUT/"scripts"/"verify_input_hashes.py")],capture_output=True,text=True)
 (OUT/"HASH_CHECK_STDOUT.txt").write_text(cp.stdout+cp.stderr,encoding="utf-8")
 if cp.returncode: raise RuntimeError("Input hash check failed")
 say("Input hashes PASS (13-zone selected raw and per-ID physical assets)")
 rcounts=[]; ret=[]; audit=[]; thresholds=[]; strata=[]; hetero=[]; transfer=[]; saved={}
 wrng=np.random.Generator(np.random.PCG64(P.RCOUNT_SEED))
 for ix,uid in enumerate(P.TARGET,1):
  say(f"Coverage {ix}/{len(P.TARGET)}: {uid}")
  r,b,_,_=P.read_cov(uid); r["coverage_id"]=uid; b["coverage_id"]=uid
  nr=len(r); nb=b.grid_id.nunique(); area=float(b.coverage_intersection_area_m2.sum())
  rg,bg,_,_=P.add_glo(uid,r.copy(),b.copy()); rg["coverage_id"]=uid; bg["coverage_id"]=uid
  vr=P.valid_slope_r(rg); vb=P.valid_slope_b(bg)
  excl=P.RTS_EXCLUDED.get(uid,set())
  if uid.endswith("028") and (not excl.issubset(set(rg.rts_id.astype(str))) or (rg.rts_id.astype(str).isin(excl)&vr).any()):
   raise RuntimeError("COV_028 named RTS slope-support audit failed")
  valid_area=float(bg.loc[vb,"coverage_intersection_area_m2"].sum()); frac=valid_area/area
  row=dict(coverage_id=uid,RAW_RTS_N=nr,RAW_BG_N=nb,RAW_BG_area_m2=area,slope_RTS_valid_N=int(vr.sum()),
   slope_RTS_valid_fraction=float(vr.mean()),slope_BG_valid_N=int(vb.sum()),slope_BG_valid_area_m2=valid_area,
   slope_BG_valid_area_fraction=frac,coverage_BG_gate="PASS" if frac>=.95 else "HOLD",
   named_NO_SLOPE_SUPPORT_N=len(excl),matched_A0_A1_RTS_N=int(vr.sum()),matched_A0_A1_BG_N=int(vb.sum()))
  row["GLO30_physical_extra_RTS_attribute_ids_n"]=rg.attrs.get("physical_attribute_extra_id_n",np.nan)
  row["GLO30_physical_extra_BG_attribute_ids_n"]=bg.attrs.get("physical_attribute_extra_id_n",np.nan)
  rphys=rg.copy(); bphys=bg.copy(); ice={}
  for branch in ["GAM","GBM"]:
   ri,bi,_,_=P.add_ice(uid,rg.copy(),bg.copy(),branch); ri["coverage_id"]=uid; bi["coverage_id"]=uid
   row[f"{branch}_extra_RTS_attribute_ids_n"]=ri.attrs.get("physical_attribute_extra_id_n",np.nan)
   row[f"{branch}_extra_BG_attribute_ids_n"]=bi.attrs.get("physical_attribute_extra_id_n",np.nan)
   ir=P.valid_ice(ri); ib=P.valid_ice(bi)
   rr=ri.loc[vr&ir].copy(); bb=bi.loc[vb&ib].copy(); rr["physical_stratum"]="ALL"; bb["physical_stratum"]="ALL"
   names=[f"B0_{branch}_COMMON_SUPPORT_RAW",f"B1_{branch}_SLOPE_ADJUSTED",f"B2_{branch}_SLOPE_GROUNDICE_ADJUSTED"]
   ice[branch]=(ri,bi,ir,ib,rr,bb,names)
   for t,source,key in [(rphys,ri,"rts_id"),(bphys,bi,"grid_id")]:
    cols=[key,"vic_mean","vic_valid_area_m2","vic_valid_fraction","vic_eligible_area_m2"]
    m=t.merge(source[cols].rename(columns={c:f"{branch}_{c}" for c in cols if c!=key}),on=key,validate="one_to_one")
    if key=="rts_id": rphys=m
    else: bphys=m
   row[f"{branch}_common_RTS_N"]=len(rr); row[f"{branch}_common_BG_N"]=len(bb)
   row[f"{branch}_common_RTS_fraction"]=len(rr)/nr
   row[f"{branch}_common_BG_area_fraction"]=float(bb.coverage_intersection_area_m2.sum())/area
  rphys.to_csv(OUT/f"{uid}_RTS_PHYSICAL_ATTRIBUTES.csv.gz",index=False,compression="gzip")
  bphys.to_csv(OUT/f"{uid}_BACKGROUND_PHYSICAL_ATTRIBUTES.csv.gz",index=False,compression="gzip")
  saved[uid]=(r,b,rg,bg,rphys,bphys)
  stages=[]
  # RAW
  x=r.copy(); y=b.copy(); x["physical_stratum"]="ALL"; y["physical_stratum"]="ALL"; stages.append(("RAW","NA",x,y,False))
  # matched RAW and slope adjustment
  x=rg.loc[vr].copy(); y=bg.loc[vb].copy(); x["physical_stratum"]="ALL"; y["physical_stratum"]="ALL"
  stages.append(("A0_MATCHED_RAW","NA",x.copy(),y.copy(),False))
  xa,ya,sa=P.attach_strata(x.copy(),y.copy(),"SLOPE",uid,thresholds)
  if xa is None: raise RuntimeError(f"A1 strata failed {uid}: {sa}")
  row["A1_strata_status"]=sa if frac>=.95 else "COVERAGE_BG_SUPPORT_BELOW_95"
  stages.append(("A1_SLOPE_ADJUSTED","NA",xa,ya,True))
  # common support branches
  for branch,(ri,bi,ir,ib,cr,cb,names) in ice.items():
   stages.append((names[0],branch,cr.copy(),cb.copy(),False))
   xb,yb,sb=P.attach_strata(cr.copy(),cb.copy(),"SLOPE",uid,thresholds,branch)
   xj,yj,sj=P.attach_strata(cr.copy(),cb.copy(),"SLOPE_VIC",uid,thresholds,branch)
   if xb is None or xj is None: raise RuntimeError(f"B strata failed {uid}/{branch}: {sb},{sj}")
   stages.extend([(names[1],branch,xb,yb,True),(names[2],branch,xj,yj,True)])
  audit.append(row)
  allblocks=sorted(set().union(*[set(s[2].block_25.astype(str))|set(s[3].block_25.astype(str)) for s in stages]))
  W=draws(allblocks,wrng)
  for name,branch,x,y,adjusted in stages:
   x=x.copy(); y=y.copy(); x["coverage_id"]=uid; y["coverage_id"]=uid
   boot=P.bootstrap_rcount(x,y,allblocks,W,adjusted)
   rcounts.extend(P.scenario_rcount_rows(uid,name,branch,x,y,adjusted,boot,nr,nb,area))
   ret.append(dict(coverage_id=uid,scenario=name,groundice_branch=branch,RTS_N=len(x),BG_N=y.grid_id.nunique(),
    BG_area_m2=float(y.coverage_intersection_area_m2.sum()),retained_RTS_fraction=len(x)/nr,
    retained_BG_grid_fraction=y.grid_id.nunique()/nb,retained_BG_area_fraction=float(y.coverage_intersection_area_m2.sum())/area))
   if adjusted: strata.extend(P.stratum_table(uid,name,branch,x,y,True))
   cells=P.aggregate_cells(x,y,25); hetero.append(P.heterogeneity_test(name,cells,adjusted)|{"groundice_branch":branch})
   for scale in P.SCALES:
    z=P.transfer_for_coverage(uid,name,x,y,scale); z["groundice_branch"]=branch; transfer.append(z)
  say(f"  raw RTS {nr}; slope matched {int(vr.sum())}; slope BG area support {frac:.3%}; GAM common {row['GAM_common_RTS_N']}/{row['GAM_common_BG_N']}; GBM {row['GBM_common_RTS_N']}/{row['GBM_common_BG_N']}")
 rc=pd.DataFrame(rcounts); ret=pd.DataFrame(ret); aud=pd.DataFrame(audit); th=pd.DataFrame(thresholds); st=pd.DataFrame(strata); het=pd.DataFrame(hetero); blocks=pd.concat(transfer,ignore_index=True)
 say("Writing core R_count, support, heterogeneity, and block-transfer tables")
 rc.to_csv(OUT/"RCOUNT_ALL_SCENARIOS.csv",index=False); ret.to_csv(OUT/"SAMPLE_RETENTION_BY_SCENARIO.csv",index=False)
 aud.to_csv(OUT/"COVERAGE_SUPPORT_AND_ID_AUDIT.csv",index=False); th.to_csv(OUT/"STRATIFICATION_THRESHOLDS.csv",index=False)
 st.to_csv(OUT/"STRATUM_RCOUNT_SUPPORT.csv",index=False); het.to_csv(OUT/"COVERAGE_VEGETATION_HETEROGENEITY.csv",index=False)
 blocks.to_csv(OUT/"TRANSFER_BLOCK_RESULTS_10_25_50KM.csv",index=False)
 say("Hierarchical transfer bootstrap")
 tc,to=P.transfer_summaries(blocks); tc.to_csv(OUT/"TRANSFER_COVERAGE_SUMMARY.csv",index=False); to.to_csv(OUT/"TRANSFER_OVERALL_SUMMARY.csv",index=False)
 # Matched paired effect estimates per coverage; the underlying R_count rows include block-bootstrap CIs.
 pairs=[("RAW","A0_MATCHED_RAW","NA"),("A0_MATCHED_RAW","A1_SLOPE_ADJUSTED","NA")]
 for branch in ["GAM","GBM"]:
  pairs += [(f"B0_{branch}_COMMON_SUPPORT_RAW",f"B1_{branch}_SLOPE_ADJUSTED",branch),
   (f"B1_{branch}_SLOPE_ADJUSTED",f"B2_{branch}_SLOPE_GROUNDICE_ADJUSTED",branch)]
 effects=[]
 for before,after,branch in pairs:
  left=rc[(rc.scenario==before)&(rc.groundice_branch==branch)]; right=rc[(rc.scenario==after)&(rc.groundice_branch==branch)]
  z=left.merge(right,on=["coverage_id","vegetation_class"],suffixes=("_before","_after"),validate="one_to_one")
  for q in z.itertuples():
   a=q.R_count_before; b=q.R_count_after
   d=math.log(b)-math.log(a) if np.isfinite(a) and np.isfinite(b) and a>0 and b>0 else np.nan
   effects.append(dict(comparison=f"{before}_TO_{after}",groundice_branch=branch,coverage_id=q.coverage_id,
    vegetation_class=q.vegetation_class,R_count_before=a,R_count_after=b,delta_log_R_count=d,
    percent_change=math.exp(d)-1 if np.isfinite(d) else np.nan))
 pd.DataFrame(effects).to_csv(OUT/"COVERAGE_EFFECT_CHANGE.csv",index=False)
 # Predeclared A1 coverage exclusions, no refitting of bin definitions.
 sens=[]
 for label,excl in [("A1_MAIN",[]),("A1_NO_COV028",["DARTS2023_COV_028"]),
  ("A1_EXCLUDE_OLDER_GLO30_SET",["DARTS2023_COV_019","DARTS2023_COV_021","DARTS2023_COV_022","DARTS2023_COV_028"]),
  ("A1_EXCLUDE_V3_MISSING_COG_SET",["DARTS2023_COV_019","DARTS2023_COV_022","DARTS2023_COV_028","DARTS2023_COV_033"])]:
  z=rc[(rc.scenario=="A1_SLOPE_ADJUSTED")&(rc.vegetation_class==P.GRASS)&(~rc.coverage_id.isin(excl))]
  v=pd.to_numeric(z.R_count,errors="coerce")
  sens.append(dict(sensitivity=label,excluded_coverages=";".join(excl) if excl else "NONE",coverage_n=z.coverage_id.nunique(),
   grass_R_count_gt1_n=int((v>1).sum()),estimable_n=int(v.notna().sum()),mean=v.mean(),median=v.median(),min=v.min(),max=v.max()))
 pd.DataFrame(sens).to_csv(OUT/"SENSITIVITY_A1_SUMMARY.csv",index=False)
 say("ArcticDEM independent seven-coverage A0/A1 replication")
 ar=[]; ars=[]; arh=[]; art=[]
 for uid in P.ARCTIC_PASS:
  r,b,_,_=P.read_cov(uid); r["coverage_id"]=uid; b["coverage_id"]=uid
  rp=P.ARCTIC/uid/f"{uid}_RTS_SLOPE_RING_ATTRIBUTES_V2.csv.gz"; bp=P.ARCTIC/uid/f"{uid}_BACKGROUND_SLOPE_RING_ATTRIBUTES_V2.csv.gz"
  sr=pd.read_csv(rp,compression="gzip",low_memory=False); sb=pd.read_csv(bp,compression="gzip",low_memory=False)
  sr.rts_id=sr.rts_id.astype(str); sb.grid_id=sb.grid_id.astype(str)
  missing_r=set(r.rts_id)-set(sr.rts_id); missing_b=set(b.grid_id)-set(sb.grid_id)
  if missing_r or missing_b: raise RuntimeError(f"Arctic attributes missing analysis IDs {uid}: RTS={len(missing_r)}, BG={len(missing_b)}")
  extra_r=len(set(sr.rts_id)-set(r.rts_id)); extra_b=len(set(sb.grid_id)-set(b.grid_id))
  r=r.merge(sr[["rts_id","slope_valid_fraction","slope_median_deg","slope_mean_deg"]],on="rts_id",how="left",validate="one_to_one")
  b=b.merge(sb[["grid_id","slope_valid_pixel_n","slope_median_deg","slope_mean_deg"]],on="grid_id",how="left",validate="one_to_one")
  vr=P.valid_slope_r(r); vb=P.valid_slope_b(b); area=float(b.coverage_intersection_area_m2.sum()); va=float(b.loc[vb,"coverage_intersection_area_m2"].sum())
  ars.append(dict(coverage_id=uid,product="ArcticDEM_v4.1_32m",RTS_N=len(r),RTS_valid_n=int(vr.sum()),RTS_valid_fraction=float(vr.mean()),
    BG_N=len(b),BG_valid_n=int(vb.sum()),BG_valid_area_fraction=va/area,coverage_gate="PASS" if va/area>=.95 else "HOLD",
    physical_attribute_extra_RTS_ids_n=extra_r,physical_attribute_extra_BG_ids_n=extra_b))
  r=r.loc[vr].copy(); b=b.loc[vb].copy(); r["physical_stratum"]="ALL"; b["physical_stratum"]="ALL"
  xa,ya,ss=P.attach_strata(r.copy(),b.copy(),"SLOPE",uid,[],branch="ARCTICDEM")
  for name,x,y,adj in [("ARCTICDEM_A0_MATCHED_RAW",r.copy(),b.copy(),False),("ARCTICDEM_A1_SLOPE_ADJUSTED",xa,ya,True)]:
   x["coverage_id"]=uid; y["coverage_id"]=uid
   blist=sorted(set(x.block_25.astype(str))|set(y.block_25.astype(str))); W=draws(blist,wrng); boot=P.bootstrap_rcount(x,y,blist,W,adj)
   ar.extend(P.scenario_rcount_rows(uid,name,"NA",x,y,adj,boot,len(P.read_cov(uid)[0]),len(P.read_cov(uid)[1]),area))
   cells=P.aggregate_cells(x,y,25); arh.append(P.heterogeneity_test(name,cells,adj)|{"groundice_branch":"NA"})
   for scale in P.SCALES:
    z=P.transfer_for_coverage(uid,name,x,y,scale); z["groundice_branch"]="NA"; art.append(z)
  say(f"  {uid}: RTS {vr.mean():.3%}; BG area {va/area:.3%}; A1 {ss}")
 ar=pd.DataFrame(ar); ars=pd.DataFrame(ars); arh=pd.DataFrame(arh); art=pd.concat(art,ignore_index=True)
 ar.to_csv(OUT/"ARCTICDEM_RCOUNT_A0_A1.csv",index=False); ars.to_csv(OUT/"ARCTICDEM_SUPPORT_AUDIT.csv",index=False)
 arh.to_csv(OUT/"ARCTICDEM_HETEROGENEITY.csv",index=False); art.to_csv(OUT/"ARCTICDEM_TRANSFER_BLOCK_RESULTS.csv",index=False)
 atc,ato=P.transfer_summaries(art); atc.to_csv(OUT/"ARCTICDEM_TRANSFER_COVERAGE_SUMMARY.csv",index=False); ato.to_csv(OUT/"ARCTICDEM_TRANSFER_OVERALL_SUMMARY.csv",index=False)
 # Grass summaries and transparent first-page report.
 scenarios=[("RAW","NA"),("A0_MATCHED_RAW","NA"),("A1_SLOPE_ADJUSTED","NA")]
 for br in ["GAM","GBM"]: scenarios += [(f"B0_{br}_COMMON_SUPPORT_RAW",br),(f"B1_{br}_SLOPE_ADJUSTED",br),(f"B2_{br}_SLOPE_GROUNDICE_ADJUSTED",br)]
 grass=[]
 for name,branch in scenarios:
  z=rc[(rc.scenario==name)&(rc.groundice_branch==branch)&(rc.vegetation_class==P.GRASS)]; v=pd.to_numeric(z.R_count,errors="coerce")
  grass.append(dict(scenario=name,groundice_branch=branch,coverage_n=z.coverage_id.nunique(),grass_R_count_gt1_n=int((v>1).sum()),grass_R_count_mean=v.mean(),grass_R_count_median=v.median()))
 gs=pd.DataFrame(grass); gs.to_csv(OUT/"GRASS_PATTERN_SUMMARY.csv",index=False)
 artgrass=[]
 for name in ["ARCTICDEM_A0_MATCHED_RAW","ARCTICDEM_A1_SLOPE_ADJUSTED"]:
  z=ar[(ar.scenario==name)&(ar.vegetation_class==P.GRASS)]; artgrass.append(dict(scenario=name,coverage_n=z.coverage_id.nunique(),grass_R_count_gt1_n=int((z.R_count>1).sum()),grass_R_count_mean=z.R_count.mean(),grass_R_count_median=z.R_count.median()))
 pd.DataFrame(artgrass).to_csv(OUT/"ARCTICDEM_GRASS_SUMMARY.csv",index=False)
 lines=["# Physical confounding sensitivity analysis","",
  "## Page 1 — requested answers","",
  "1. Common-sample restriction: RAW to A0 isolates slope support; RAW to B0 is the ground-ice common-support restriction. Coverage-level changes are in COVERAGE_EFFECT_CHANGE.csv.",
  "2. Slope contribution is A0 to A1. Incremental ice contribution is B1 to B2, reported separately for GAM and GBM. Do not attribute RAW-to-B2 wholesale to physical adjustment.",
  "3. Grass R_count above 1 by scenario:"]
 for q in gs.itertuples(): lines.append(f"- {q.scenario} ({q.groundice_branch}): {q.grass_R_count_gt1_n}/{q.coverage_n}; mean={q.grass_R_count_mean:.4g}, median={q.grass_R_count_median:.4g}.")
 lines += ["","4. Coverage-by-vegetation heterogeneity is in COVERAGE_VEGETATION_HETEROGENEITY.csv. This is a conditional-composition test, not a causal test.",
  "5. Parent-local predictive gain, CI, positive coverage/block proportion and TV at 10/25/50 km are in TRANSFER_OVERALL_SUMMARY.csv and TRANSFER_COVERAGE_SUMMARY.csv.",
  "6. Largest coverage changes are ranked in COVERAGE_EFFECT_CHANGE.csv.",
  "7. Separate ArcticDEM replication is in ARCTICDEM_GRASS_SUMMARY.csv and ARCTICDEM_TRANSFER_OVERALL_SUMMARY.csv.",
  "8. COV_028 and two provenance-defined DEM missing-coverage exclusions are in SENSITIVITY_A1_SUMMARY.csv.",
  "9. A/B/C/D judgment: interpret effect attenuation together with heterogeneity and transfer; no causal inference is made.",
  "","All 13 tundra coverage units are retained in RAW. The named COV_028 RTS remain in RAW and do not enter matched slope comparisons. GAM and GBM are parallel ground-ice branches, not pooled or selected after outcomes.",
  "","## Scope","",
  "This sensitivity tests whether the frozen RTS–vegetation association persists under slope and ground-ice common support and stratification. It does not establish vegetation causality, RTS occurrence probability, or susceptibility."]
 (OUT/"FINAL_PHYSICAL_CONFOUNDING_REPORT.md").write_text("\\n".join(lines)+"\\n",encoding="utf-8")
 if set(rc.coverage_id.unique())!=set(P.TARGET) or len(aud)!=len(P.TARGET) or rc[rc.scenario=="RAW"].groupby("coverage_id").size().ne(7).any():
  raise RuntimeError("Final row closure QC failed")
 pd.DataFrame([dict(input_hash_status="PASS_13_ZONE_SELECTED_INPUTS",coverage_n=len(P.TARGET),RAW_rows=int((rc.scenario=="RAW").sum()),
  total_Rcount_rows=len(rc),all_13_retained_RAW=True,named_COV028_RTS_retained_RAW=True,ArcticDEM_regions=len(ars),
  groundice_branches="GAM;GBM",status="COMPLETE")]).to_csv(OUT/"QC_SUMMARY.csv",index=False)
 (OUT/"RUN_LOG.md").write_text("# Run log\\n\\n"+"\\n".join("- "+x for x in LOG)+"\\n",encoding="utf-8")
 files=[p for p in OUT.rglob("*") if p.is_file() and p.name not in {"OUTPUT_HASHES.csv","RUN_STATE.md"} and "__pycache__" not in str(p)]
 pd.DataFrame([dict(path=str(p.relative_to(OUT)),size_bytes=p.stat().st_size,sha256=P.sha256(p)) for p in sorted(files)]).to_csv(OUT/"OUTPUT_HASHES.csv",index=False)
 (OUT/"RUN_STATE.md").write_text("ARTIFACT_STATUS：COMPLETE\\n\\nCompleted 2026-10-08. Selected 13-zone input hashes verified. All manifest-listed RAW coverages retained; GAM and GBM common-support results reported separately. See FINAL_PHYSICAL_CONFOUNDING_REPORT.md and OUTPUT_HASHES.csv.\\n",encoding="utf-8")
 say("COMPLETE")
if __name__=="__main__":
 try: main()
 except Exception as e:
  (OUT/"FAILURE_LOG.md").write_text("# Failure log\\n\\n"+repr(e)+"\\n\\n"+traceback.format_exc(),encoding="utf-8")
  print("FAILED: "+repr(e),flush=True); raise


