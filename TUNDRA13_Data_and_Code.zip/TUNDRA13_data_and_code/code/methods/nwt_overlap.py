from pathlib import Path
import struct,sqlite3,csv,json,hashlib,math
from collections import Counter
import numpy as np
from shapely import from_wkb,make_valid,STRtree,union_all
from shapely.geometry import Polygon
from shapely.ops import transform
from pyproj import CRS,Transformer

work=Path(__file__).parent
root=Path(r'E:\zuom\gu\RUNS\ROUND_20260828_01')
src=root/'RTS_NWT_2015_022_FORMALIZATION_V1'/'source_extracted'/'OR 2015-022_Appendix A'/'Shapefiles'
out=work/'checks'; out.mkdir(exist_ok=True)

def read_dbf(path):
    data=path.read_bytes(); n=struct.unpack_from('<I',data,4)[0]; hlen,rlen=struct.unpack_from('<HH',data,8)
    fields=[]; pos=32
    while data[pos]!=13:
        desc=data[pos:pos+32]; fields.append((desc[:11].split(b'\0')[0].decode('ascii'),desc[16])); pos+=32
    rows=[]
    for i in range(n):
        raw=data[hlen+i*rlen:hlen+(i+1)*rlen]; vals={}; k=1
        for name,size in fields:
            vals[name]=raw[k:k+size].decode('cp1252').strip(); k+=size
        vals['_deleted']=raw[0:1]==b'*'; rows.append(vals)
    return rows

def read_shp(path):
    data=path.read_bytes(); pos=100; geometries=[]
    while pos<len(data):
        rec,nwords=struct.unpack_from('>ii',data,pos); pos+=8; raw=data[pos:pos+2*nwords];pos+=2*nwords
        typ=struct.unpack_from('<i',raw)[0]
        if typ==0: geometries.append(None); continue
        assert typ in [5,15,25],typ
        nparts,npoints=struct.unpack_from('<ii',raw,36)
        parts=list(struct.unpack_from('<'+'i'*nparts,raw,44))+[npoints]
        points=np.frombuffer(raw,dtype='<f8',count=npoints*2,offset=44+4*nparts).reshape(-1,2)
        geom=None
        # ESRI rings can contain disjoint shells and holes. Even-odd ring composition
        # retains both; invalid source rings are repaired only in this audit's memory.
        for a,b in zip(parts[:-1],parts[1:]):
            ring=make_valid(Polygon(points[a:b])); geom=ring if geom is None else geom.symmetric_difference(ring)
        geometries.append(make_valid(geom))
    return geometries

def read_gpkg(path):
    con=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
    tables=con.execute("select table_name from gpkg_contents where data_type='features'").fetchall(); allrows=[]
    for (table,) in tables:
        geomcol,srs=con.execute('select column_name,srs_id from gpkg_geometry_columns where table_name=?',(table,)).fetchone()
        wkt=con.execute('select definition from gpkg_spatial_ref_sys where srs_id=?',(srs,)).fetchone()[0]
        crs=CRS.from_wkt(wkt); tr=Transformer.from_crs(crs,6933,always_xy=True)
        cols=[r[0] for r in con.execute('select name from pragma_table_info(?)',(table,))]
        sql='select '+','.join('"'+c+'"' for c in cols)+' from "'+table+'"'
        for row in con.execute(sql):
            attrs=dict(zip(cols,row)); blob=attrs.pop(geomcol)
            if not blob: continue
            env=(blob[3]>>1)&7; offset=8+[0,32,48,48,64][env]
            g=make_valid(from_wkb(blob[offset:])); g=transform(tr.transform,g)
            allrows.append({'source':path.name,'attrs':attrs,'geom':g})
    con.close(); return allrows

attrs=read_dbf(src/'TukCoast_Slumps.dbf'); geoms=read_shp(src/'TukCoast_Slumps.shp')
assert len(attrs)==len(geoms)==2037
native=CRS.from_wkt((src/'TukCoast_Slumps.prj').read_text())
project=Transformer.from_crs(native,6933,always_xy=True)
allgeom=[transform(project.transform,g) for g in geoms]
aoi_native=read_shp(src/'TukCoast_Study_Boundary.shp')
aoi=union_all([transform(project.transform,g) for g in aoi_native])
active=[i for i,a in enumerate(attrs) if a['Active_Y_N'].upper()=='Y']; assert len(active)==704
assign=root/'RTS_NWT2015_022_EXTERNAL_BLIND_VALIDATION_V1'/'NWT2015_022_ACTIVE_RTS_ASSIGNMENT_V1.csv'
classes={'FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE'}
rows=list(csv.DictReader(assign.open(encoding='utf-8-sig')))
scored={int(r['source_feature_index']) for r in rows if r['community'] in classes}; assert len(scored)==393
records=[]; footprint_records=[]
for p in sorted((work/'github_v1.0.1').glob('*.gpkg')):
    r=read_gpkg(p)
    if p.name.startswith('TrainingLabel'):records.extend(r)
    else:footprint_records.extend(r)
assert len(records)==3749
labels=[r['geom'] for r in records]; tree=STRtree(labels)
footprints=[r['geom'] for r in footprint_records]; ftree=STRtree(footprints)
detail=[]; pairs=[]
for i in active:
    g=allgeom[i]; hits=tree.query(g,predicate='intersects'); pairs_here=[]
    for h in hits:
        h=int(h);area=g.intersection(labels[h]).area
        if area>0:
            r=records[h]; pairs_here.append((h,area))
            pairs.append({'nwt_source_feature_index':i,'in_scored_393':i in scored,'source_training_file':r['source'],'training_row_id':r['attrs'].get('fid'),'positive_overlap_m2':area,'fraction_of_NWT_polygon':area/g.area,'image_id':r['attrs'].get('image_id'),'region':r['attrs'].get('region'),'site':r['attrs'].get('site')})
    fh=[int(h) for h in ftree.query(g,predicate='intersects') if g.intersection(footprints[int(h)]).area>0]
    nearest=int(tree.nearest(g))
    detail.append({'nwt_source_feature_index':i,'in_scored_393':i in scored,'centroid_in_official_AOI':aoi.covers(g.centroid),'training_label_positive_overlap_n':len(pairs_here),'pairwise_overlap_m2':sum(a for h,a in pairs_here),'training_image_positive_overlap_n':len(fh),'nearest_training_label_distance_m':g.distance(labels[nearest])})
for name,data in [('NWT_ACTIVE_TRAINING_OVERLAP.csv',detail),('NWT_TRAINING_INTERSECTION_PAIRS.csv',pairs)]:
    with (out/name).open('w',newline='',encoding='utf-8-sig') as f:
        if data:
            w=csv.DictWriter(f,fieldnames=list(data[0])); w.writeheader();w.writerows(data)
        else:f.write('No positive-area intersections\n')
positive=[r for r in detail if r['training_label_positive_overlap_n']]
scored_positive=[r for r in positive if r['in_scored_393']]
result={'release':'ML_training_labels v1.0.1; GitHub tree 0b678403848523a4cfbc007cb2a17a75a6abf409; every file verified against Git blob SHA','training_labels_n':len(labels),'training_scene_footprint_rows_n':len(footprints),'labels_positive_area_intersecting_NWT_AOI_n':sum(g.intersection(aoi).area>0 for g in labels),'active_NWT_n':704,'active_centroids_in_AOI_n':sum(r['centroid_in_official_AOI'] for r in detail),'main_scored_NWT_n':393,'active_NWT_with_positive_label_overlap_n':len(positive),'scored_NWT_with_positive_label_overlap_n':len(scored_positive),'active_NWT_with_training_image_footprint_overlap_n':sum(r['training_image_positive_overlap_n']>0 for r in detail),'scored_NWT_with_training_image_footprint_overlap_n':sum(r['training_image_positive_overlap_n']>0 and r['in_scored_393'] for r in detail),'scored_minimum_training_label_distance_m':min(r['nearest_training_label_distance_m'] for r in detail if r['in_scored_393']),'training_metadata_sources':dict(Counter(str(r['attrs'].get('datasource')) for r in records)),'training_metadata_targets':dict(Counter(str(r['attrs'].get('target')) for r in records)),'interpretation':'Positive overlap indicates spatial source dependence, not proof that the 2004 file was directly copied into labels. Zero overlap alone does not establish independent detector performance. Geographic separation of shared-vegetation-weight training is a separate claim.','projection_for_intersection_areas':'EPSG:6933','source_files_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [src/'TukCoast_Slumps.shp',src/'TukCoast_Slumps.dbf',src/'TukCoast_Slumps.prj',src/'TukCoast_Study_Boundary.shp',assign]}}
(out/'TRAINING_LABEL_OVERLAP_SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
