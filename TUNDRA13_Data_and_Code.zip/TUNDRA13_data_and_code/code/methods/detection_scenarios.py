from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01")
PROJECT = ROOT / "RTS_TUNDRA13_FULL_REANALYSIS_V1"
OUT = PROJECT / "detection" / "results"
TRANSFER = PROJECT / "results" / "TRANSFER"
INTERACTION = PROJECT / "results" / "CATEGORY_SPECTRUM"
MATRIX_PATH = TRANSFER / "RECONSTRUCTED_BLOCK_PANEL_25KM.csv"
TRANSFER_BASE_PATH = TRANSFER / "BLOCK_TRANSFER_25KM.csv"
TRANSFER_SUMMARY_PATH = TRANSFER / "COVERAGE_TRANSFER_SUMMARY_25KM.csv"
TRANSFER_INPUT_VERIFICATION = TRANSFER / "INPUT_HASHES.csv"
TRANSFER_OUTPUT_HASHES = TRANSFER / "OUTPUT_HASHES.csv"
TRANSFER_REPORT = TRANSFER / "FINAL_REPORT.md"
FORMAL_BLOCK_PATH = MATRIX_PATH
FORMAL_OUTPUT_HASHES = TRANSFER / "OUTPUT_HASHES.csv"

CATEGORIES = ["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE"]
GRASS = "GRASS_HERBACEOUS"
MOSS = "MOSS_LICHEN"
PRIMARY_SCALE = 25
P_VALUES = [round(0.05 * i, 2) for i in range(1, 21)]
ALPHA = 0.5
_manifest=json.loads((Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01\RTS_TUNDRA13_FULL_REANALYSIS_V1")/"TUNDRA13_COVERAGE_MANIFEST.json").read_text(encoding="utf-8"))
EXPECTED_COVERAGES=_manifest["coverage_ids"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def read_and_verify_frozen_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    require(TRANSFER_REPORT.is_file() and "ARTIFACT_STATUS: COMPLETE" in TRANSFER_REPORT.read_text(encoding="utf-8"),
            "Tundra13 transfer artifact is not COMPLETE.")
    raw=pd.read_csv(MATRIX_PATH)
    base=pd.read_csv(TRANSFER_BASE_PATH)
    summary=pd.read_csv(TRANSFER_SUMMARY_PATH)
    require(set(raw.coverage_id.unique())==set(EXPECTED_COVERAGES), "13-zone panel coverage mismatch")
    require(set(base.coverage_id.unique())==set(EXPECTED_COVERAGES), "13-zone transfer coverage mismatch")
    raw=raw.loc[raw.scale_km.eq(PRIMARY_SCALE)].copy()
    raw=raw.rename(columns={"RTS_N":"RTS_N_local","background_area_km2":"background_area_km2_local"})
    g=raw.groupby(["coverage_id","block_id"],sort=False)
    raw["RTS_N_local_total"]=g.RTS_N_local.transform("sum")
    raw["background_area_km2_local_total"]=g.background_area_km2_local.transform("sum")
    formal=raw.groupby(["coverage_id","community"],as_index=False).agg(RTS_N=("RTS_N_local","sum"),background_area_km2=("background_area_km2_local","sum"))
    formal["scale_km"]=PRIMARY_SCALE
    return raw,base,summary,formal

def build_panel(raw: pd.DataFrame, formal: pd.DataFrame, scale: int) -> pd.DataFrame:
    d = raw.loc[raw["scale_km"].eq(scale)].copy()
    require(not d.empty, f"No rows for scale={scale} in frozen transfer matrix.")
    require(set(d["community"].unique()) == set(CATEGORIES), "Frozen modeled category set differs from expected six categories.")
    require(set(d["coverage_id"].unique()) == set(EXPECTED_COVERAGES), "Frozen coverage set is not the manifest-defined coverages.")
    require(not d.duplicated(["coverage_id", "block_id", "community"]).any(), "Duplicate coverage/block/category rows in matrix.")

    grouped = d.groupby(["coverage_id", "block_id"], sort=True)
    # All rows in a block repeat these totals; verify before using them.
    for col in ["RTS_N_local_total", "background_area_km2_local_total"]:
        spread = grouped[col].agg(lambda x: float(x.max()) - float(x.min()))
        require((spread.abs() < 1e-8).all(), f"Inconsistent repeated block total in {col}.")
    count_sum = grouped["RTS_N_local"].sum()
    count_total = grouped["RTS_N_local_total"].first()
    require(np.allclose(count_sum.to_numpy(float), count_total.to_numpy(float), atol=1e-8), "Category counts do not reconcile to block total.")
    area_sum = grouped["background_area_km2_local"].sum()
    area_total = grouped["background_area_km2_local_total"].first()
    require(np.allclose(area_sum.to_numpy(float), area_total.to_numpy(float), atol=1e-6, rtol=1e-9), "Category areas do not reconcile to block total.")
    f = formal.loc[formal["scale_km"].eq(scale)].groupby(["coverage_id", "community"], as_index=False).agg(
        RTS_N=("RTS_N", "sum"), background_area_km2=("background_area_km2", "sum")
    )
    m = d.groupby(["coverage_id", "community"], as_index=False).agg(
        RTS_N=("RTS_N_local", "sum"), background_area_km2=("background_area_km2_local", "sum")
    )
    recon = m.merge(f, on=["coverage_id", "community"], how="outer", suffixes=("_matrix", "_formal")).fillna(0)
    require(np.array_equal(recon["RTS_N_matrix"].to_numpy(float), recon["RTS_N_formal"].to_numpy(float)),
            "Coverage/category RTS counts do not reconcile to frozen formal block table.")
    require(np.allclose(recon["background_area_km2_matrix"].to_numpy(float), recon["background_area_km2_formal"].to_numpy(float), atol=1e-7, rtol=1e-10),
            "Coverage/category background areas do not reconcile to frozen formal block table.")
    return d


def safe_ratio(a: float, b: float) -> float:
    if b == 0:
        return np.inf if a > 0 else np.nan
    return a / b


def coverage_stats(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    agg = panel.groupby(["coverage_id", "community"], as_index=False).agg(
        RTS_N=("RTS_N_local", "sum"), background_area_km2=("background_area_km2_local", "sum")
    )
    rows = []
    for cov, g in agg.groupby("coverage_id", sort=True):
        g = g.set_index("community").reindex(CATEGORIES)
        g[["RTS_N", "background_area_km2"]] = g[["RTS_N", "background_area_km2"]].fillna(0)
        n = g["RTS_N"].to_numpy(float)
        b = g["background_area_km2"].to_numpy(float)
        n_tot, b_tot = float(n.sum()), float(b.sum())
        require(n_tot > 0 and b_tot > 0, f"Zero total RTS/background for {cov}.")
        for i, cat in enumerate(CATEGORIES):
            rts_share = n[i] / n_tot
            bg_share = b[i] / b_tot if b_tot else np.nan
            rc = (rts_share / bg_share) if bg_share > 0 else np.nan
            rows.append({"coverage": cov, "vegetation": cat, "RTS_N": int(n[i]), "RTS_share": rts_share,
                         "background_area_km2": b[i], "background_share": bg_share, "R_count": rc,
                         "effective_RTS_total": int(n_tot), "effective_background_area_km2": b_tot})
    detail = pd.DataFrame(rows)

    pooled = agg.groupby("community", as_index=False).agg(RTS_N=("RTS_N", "sum"), background_area_km2=("background_area_km2", "sum"))
    pooled = pooled.set_index("community").reindex(CATEGORIES)
    pooled[["RTS_N", "background_area_km2"]] = pooled[["RTS_N", "background_area_km2"]].fillna(0)
    n = pooled["RTS_N"].to_numpy(float)
    b = pooled["background_area_km2"].to_numpy(float)
    n_tot, b_tot = float(n.sum()), float(b.sum())
    pooled_rows = []
    for i, cat in enumerate(CATEGORIES):
        ns = n[i] / n_tot
        bs = b[i] / b_tot
        pooled_rows.append({"coverage": "DARTS13_POOLED", "vegetation": cat, "RTS_N": int(n[i]), "RTS_share": ns,
                            "background_area_km2": b[i], "background_share": bs, "R_count": ns / bs,
                            "effective_RTS_total": int(n_tot), "effective_background_area_km2": b_tot})
    pooled_detail = pd.DataFrame(pooled_rows)
    return detail, pooled_detail


def corrected_metrics(counts: dict[str, float], areas: dict[str, float], p_grass: float) -> dict[str, float]:
    adjusted = {c: float(counts.get(c, 0.0)) for c in CATEGORIES}
    adjusted[GRASS] = adjusted[GRASS] / p_grass
    n_total = sum(adjusted.values())
    b_total = sum(float(areas.get(c, 0.0)) for c in CATEGORIES)
    out = {"corrected_total_RTS": n_total}
    for c in CATEGORIES:
        bg = float(areas.get(c, 0.0)) / b_total if b_total else np.nan
        out[f"R_count_{c}"] = (adjusted[c] / n_total / bg) if bg > 0 and n_total > 0 else np.nan
    out["R_grass_over_moss"] = safe_ratio(out[f"R_count_{GRASS}"], out[f"R_count_{MOSS}"])
    out["R_grass_over_all_vegetation"] = out[f"R_count_{GRASS}"]
    return out


def response_curves(panel: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, dict[str, float]]]:
    cov_lookup: dict[str, dict[str, dict[str, float]]] = {}
    for cov, g in panel.groupby("coverage_id", sort=True):
        z = g.groupby("community").agg(N=("RTS_N_local", "sum"), B=("background_area_km2_local", "sum"))
        cov_lookup[cov] = {c: {"N": float(z.loc[c, "N"]), "B": float(z.loc[c, "B"])} for c in CATEGORIES}
    # A pooled 13-coverage diagnostic is included in addition to all per-coverage rows.
    pool = {c: {"N": sum(cov_lookup[cov][c]["N"] for cov in cov_lookup),
                "B": sum(cov_lookup[cov][c]["B"] for cov in cov_lookup)} for c in CATEGORIES}
    cov_lookup["DARTS13_POOLED"] = pool

    rows = []
    for cov, d in cov_lookup.items():
        n = {c: d[c]["N"] for c in CATEGORIES}
        b = {c: d[c]["B"] for c in CATEGORIES}
        raw_total = sum(n.values())
        for p in P_VALUES:
            m = corrected_metrics(n, b, p)
            n_adj = dict(n)
            n_adj[GRASS] /= p
            n_adj_total = sum(n_adj.values())
            for c in CATEGORIES:
                rows.append({"coverage": cov, "vegetation": c, "p_grass": p, "p_other": 1.0,
                             "observed_RTS_N": n[c], "corrected_RTS_N": n_adj[c],
                             "corrected_total_RTS_N": n_adj_total, "RTS_share_corrected": n_adj[c] / n_adj_total,
                             "background_area_km2": b[c], "background_share": b[c] / sum(b.values()),
                             "R_count": m[f"R_count_{c}"],
                             "R_grass_over_moss": m["R_grass_over_moss"],
                             "R_grass_over_all_vegetation": m["R_grass_over_all_vegetation"],
                             "scenario_direction": "GRASS_UNDERDETECTION_CORRECTION",
                             "note": "p_grass<1 means grass under-detection; correction raises grass count/share."})
    return pd.DataFrame(rows), cov_lookup


def threshold_rows(cov_lookup: dict[str, dict[str, dict[str, float]]]) -> pd.DataFrame:
    out = []
    for cov, d in cov_lookup.items():
        counts = {c: d[c]["N"] for c in CATEGORIES}
        areas = {c: d[c]["B"] for c in CATEGORIES}
        raw = corrected_metrics(counts, areas, 1.0)
        n_g = counts[GRASS]
        b_total = sum(areas.values())
        b_g = areas[GRASS]
        n_other = sum(counts[c] for c in CATEGORIES if c != GRASS)
        if n_g > 0 and b_g > 0 and b_total > b_g and n_other > 0:
            pstar_all = n_g * (1.0 - b_g / b_total) / ((b_g / b_total) * n_other)
        else:
            pstar_all = np.nan
        status_all = threshold_status(pstar_all)
        r_after_all = 1.0 if np.isfinite(pstar_all) and pstar_all > 0 else np.nan
        out.append({"coverage": cov, "vegetation_pair": "GRASS_VS_ALL_EFFECTIVE_VEGETATION_RCOUNT_EQ_1",
                    "threshold_p_grass": pstar_all, "R_before": raw[f"R_count_{GRASS}"], "R_after": r_after_all,
                    "threshold_status": status_all, "feasible_in_requested_scan": bool(np.isfinite(pstar_all) and 0.05 <= pstar_all <= 1.0),
                    "required_grass_to_other_detection_ratio_for_equality": pstar_all,
                    "required_grass_detection_advantage_fold_for_equality": pstar_all,
                    "advantage_interpretation": "If >1, this is the relative detection advantage p_grass/p_other required for the underlying GRASS R_count to equal 1; realism is uncalibrated."})

        for other in ["MOSS_LICHEN", "SHRUB", "WETLAND", "FOREST", "SPARSE_BARE"]:
            r_g = raw[f"R_count_{GRASS}"]
            r_o = raw[f"R_count_{other}"]
            if n_g > 0 and counts[other] > 0 and areas[GRASS] > 0 and areas[other] > 0:
                q0 = safe_ratio(r_g, r_o)
                pstar = q0
                status = threshold_status(pstar)
                r_after = 1.0 if np.isfinite(pstar) and pstar > 0 else np.nan
                k_adv = q0
            else:
                q0, pstar, status, r_after, k_adv = np.nan, np.nan, "INSUFFICIENT_CATEGORY_SUPPORT", np.nan, np.nan
            det_direction = ("GRASS_ADVANTAGE_REQUIRED" if np.isfinite(k_adv) and k_adv > 1 else
                             ("GRASS_DISADVANTAGE_REQUIRED" if np.isfinite(k_adv) and k_adv < 1 else
                              ("EQUAL_DETECTION" if np.isfinite(k_adv) else "UNDEFINED")))
            out.append({"coverage": cov, "vegetation_pair": f"GRASS_VS_{other}",
                        "threshold_p_grass": pstar, "R_before": q0, "R_after": r_after,
                        "threshold_status": status, "feasible_in_requested_scan": bool(np.isfinite(pstar) and 0.05 <= pstar <= 1.0),
                        "required_grass_to_other_detection_ratio_for_equality": k_adv,
                        "required_grass_detection_advantage_fold_for_equality": k_adv if np.isfinite(k_adv) and k_adv > 1 else np.nan,
                        "detection_direction_required": det_direction,
                        "advantage_interpretation": "Observed relative burden ratio is the grass/other detection-rate ratio needed for corrected pairwise equality; >1 means easier grass detection, <1 means lower grass detection."})
    return pd.DataFrame(out)


def threshold_status(x: float) -> str:
    if not np.isfinite(x) or x <= 0:
        return "NO_FINITE_THRESHOLD"
    if x > 1:
        return "ABOVE_1_NO_CROSSING_UNDER_REQUESTED_GRASS_UNDERDETECTION"
    if x < 0.05:
        return "BELOW_SCAN_MINIMUM"
    return "WITHIN_REQUESTED_SCAN"


def score_transfer(panel: pd.DataFrame, p_grass: float = 1.0, p_other: float = 1.0, scenario: str = "BASELINE") -> pd.DataFrame:
    """Recompute frozen 25-km leave-one-block-out transfer with corrected counts.

    Fractional corrected counts are used directly in the same multinomial log-score;
    background, category support, block membership and alpha=0.5 remain frozen.
    """
    rows = []
    for cov, cg in panel.groupby("coverage_id", sort=True):
        blocks = []
        for bid, bg in cg.groupby("block_id", sort=True):
            q = bg.set_index("community").reindex(CATEGORIES)
            n = q["RTS_N_local"].to_numpy(float)
            b = q["background_area_km2_local"].fillna(0).to_numpy(float)
            n_adj = n.copy()
            for idx, cat in enumerate(CATEGORIES):
                prob = p_grass if cat == GRASS else p_other
                n_adj[idx] = n_adj[idx] / prob
            blocks.append({"block_id": bid, "N": n_adj, "N_raw": n, "B": b})

        nmat = np.vstack([x["N"] for x in blocks])
        bmat = np.vstack([x["B"] for x in blocks])
        for j, block in enumerate(blocks):
            keep = np.ones(len(blocks), dtype=bool)
            keep[j] = False
            train_n = nmat[keep].sum(axis=0)
            train_b = bmat[keep].sum(axis=0)
            train_nt, train_bt = float(train_n.sum()), float(train_b.sum())
            rtrain = np.full(len(CATEGORIES), np.nan)
            if train_nt > 0 and train_bt > 0:
                pos = train_b > 0
                rtrain[pos] = (train_n[pos] / train_nt) / (train_b[pos] / train_bt)
                rtrain[pos & (train_n == 0)] = 0.0
            weights = np.where(np.isfinite(rtrain), block["B"] * rtrain, 0.0)
            if weights.sum() <= 0 or block["B"].sum() <= 0:
                p_parent = np.full(len(CATEGORIES), np.nan)
                p_area = np.full(len(CATEGORIES), np.nan)
            else:
                p_parent = weights / weights.sum()
                p_area = block["B"] / block["B"].sum()
            nvec = block["N"]
            ni = float(nvec.sum())
            if ni <= 0 or not np.isfinite(p_parent).all() or not np.isfinite(p_area).all():
                ll_p = ll_a = d_ll = d_per = np.nan
                ll_p_s = ll_a_s = d_ll_s = d_per_s = np.nan
                status = "ZERO_RTS_OR_UNSUPPORTED"
            else:
                active = nvec > 0
                if np.any(p_parent[active] <= 0) or np.any(p_area[active] <= 0):
                    ll_p = ll_a = d_ll = d_per = np.nan
                else:
                    ll_p = float(np.sum(nvec[active] * np.log(p_parent[active])))
                    ll_a = float(np.sum(nvec[active] * np.log(p_area[active])))
                    d_ll = ll_p - ll_a
                    d_per = d_ll / ni
                ps = (ni * p_parent + ALPHA) / (ni + ALPHA * len(CATEGORIES))
                aas = (ni * p_area + ALPHA) / (ni + ALPHA * len(CATEGORIES))
                ll_p_s = float(np.sum(nvec[active] * np.log(ps[active])))
                ll_a_s = float(np.sum(nvec[active] * np.log(aas[active])))
                d_ll_s = ll_p_s - ll_a_s
                d_per_s = d_ll_s / ni
                status = "SCORED"
            rows.append({"record_type": "BLOCK", "scenario": scenario, "scale_km": PRIMARY_SCALE,
                         "coverage": cov, "block_id": block["block_id"], "p_grass": p_grass, "p_other": p_other,
                         "raw_local_RTS_N": float(block["N_raw"].sum()), "corrected_local_RTS_N": ni,
                         "delta_LL_parent_minus_area_jeffreys_0p5": d_ll_s,
                         "delta_LL_per_corrected_RTS_jeffreys_0p5": d_per_s,
                         "delta_LL_parent_minus_area_unsmoothed": d_ll,
                         "delta_LL_per_corrected_RTS_unsmoothed": d_per,
                         "valid_status": status})
    return pd.DataFrame(rows)


def summarize_transfer(blocks: pd.DataFrame) -> pd.DataFrame:
    scored = blocks.loc[blocks["valid_status"].eq("SCORED")].copy()
    rows = []
    for cov, g in scored.groupby("coverage", sort=True):
        rows.append({"record_type": "COVERAGE_SUMMARY", "scenario": g["scenario"].iloc[0],
                     "scale_km": PRIMARY_SCALE, "coverage": cov, "block_id": "", "p_grass": g["p_grass"].iloc[0],
                     "p_other": g["p_other"].iloc[0], "raw_local_RTS_N": g["raw_local_RTS_N"].sum(),
                     "corrected_local_RTS_N": g["corrected_local_RTS_N"].sum(),
                     "mean_delta_LL_parent_minus_area_jeffreys_0p5": g["delta_LL_parent_minus_area_jeffreys_0p5"].mean(),
                     "mean_delta_LL_per_corrected_RTS_jeffreys_0p5": g["delta_LL_per_corrected_RTS_jeffreys_0p5"].mean(),
                     "blocks_parent_better_fraction": (g["delta_LL_per_corrected_RTS_jeffreys_0p5"] > 0).mean(),
                     "event_weighted_delta_LL_per_corrected_RTS_jeffreys_0p5": g["delta_LL_parent_minus_area_jeffreys_0p5"].sum()/g["corrected_local_RTS_N"].sum(),
                     "scored_block_n": len(g), "valid_status": "SCORED"})
    if not scored.empty:
        rows.append({"record_type": "OVERALL_SUMMARY", "scenario": scored["scenario"].iloc[0],
                     "scale_km": PRIMARY_SCALE, "coverage": "DARTS13_EQUAL_COVERAGE", "block_id": "",
                     "p_grass": scored["p_grass"].iloc[0], "p_other": scored["p_other"].iloc[0],
                     "raw_local_RTS_N": scored["raw_local_RTS_N"].sum(),
                     "corrected_local_RTS_N": scored["corrected_local_RTS_N"].sum(),
                     "mean_delta_LL_per_corrected_RTS_jeffreys_0p5": scored.groupby("coverage")["delta_LL_per_corrected_RTS_jeffreys_0p5"].mean().mean(),
                     "event_weighted_delta_LL_per_corrected_RTS_jeffreys_0p5": scored["delta_LL_parent_minus_area_jeffreys_0p5"].sum()/scored["corrected_local_RTS_N"].sum(),
                     "blocks_parent_better_fraction": (scored["delta_LL_per_corrected_RTS_jeffreys_0p5"] > 0).mean(),
                     "positive_coverage_n": int(scored.groupby("coverage")["delta_LL_per_corrected_RTS_jeffreys_0p5"].mean().gt(0).sum()),
                     "positive_coverage_event_weighted_n": int((scored.groupby("coverage").apply(lambda g: g["delta_LL_parent_minus_area_jeffreys_0p5"].sum()/g["corrected_local_RTS_N"].sum(), include_groups=False) > 0).sum()),
                     "coverage_n": int(scored["coverage"].nunique()), "scored_block_n": len(scored), "valid_status": "SCORED"})
    return pd.DataFrame(rows)


def compare_baseline_to_frozen(recomputed: pd.DataFrame, frozen: pd.DataFrame) -> dict[str, float]:
    a = recomputed[(recomputed["record_type"] == "BLOCK") & (recomputed["scenario"] == "BASELINE_NO_BIAS")]
    b = frozen[["coverage_id", "block_id", "delta_LL_per_RTS"]].copy()
    merged = a.merge(b, left_on=["coverage", "block_id"], right_on=["coverage_id", "block_id"], how="inner")
    finite = merged["delta_LL_per_corrected_RTS_jeffreys_0p5"].notna() & merged["delta_LL_per_RTS"].notna()
    diff = (merged.loc[finite, "delta_LL_per_corrected_RTS_jeffreys_0p5"] - merged.loc[finite, "delta_LL_per_RTS"]).abs()
    return {"merged_block_n": int(len(merged)), "finite_score_n": int(finite.sum()), "max_abs_delta_per_rts": float(diff.max()) if len(diff) else np.nan}


def create_figure(response: pd.DataFrame) -> None:
    grass = response.loc[response["vegetation"].eq(GRASS)].copy()
    fig, (ax_pool, ax_cov) = plt.subplots(
        1, 2, figsize=(12.4, 5.3), constrained_layout=True,
        gridspec_kw={"width_ratios": [0.9, 1.4]},
    )
    covs = [c for c in EXPECTED_COVERAGES if c in set(grass["coverage"])]
    for cov in covs:
        z = grass.loc[grass["coverage"].eq(cov)].sort_values("p_grass")
        ax_cov.plot(z["p_grass"], z["R_count"], color="#8d9aa5", alpha=0.42, linewidth=1.05)
    pooled = grass.loc[grass["coverage"].eq("DARTS13_POOLED")].sort_values("p_grass")
    ax_pool.plot(pooled["p_grass"], pooled["R_count"], color="#1f4e68", linewidth=2.7,
                 marker="o", markersize=3.5, label="13-coverage pooled")
    ax_pool.axhline(1.0, color="#b44742", linestyle="--", linewidth=1.4, label="R_count = 1")
    ax_pool.set_ylim(0.98, max(1.40, float(pooled["R_count"].max()) * 1.05))
    ax_pool.set_title("Pooled 13-coverage result")
    ax_pool.legend(frameon=False, loc="upper right", fontsize=8.5)

    ax_cov.plot(pooled["p_grass"], pooled["R_count"], color="#1f4e68", linewidth=2.7,
                label="13-coverage pooled")
    ax_cov.axhline(1.0, color="#b44742", linestyle="--", linewidth=1.4, label="R_count = 1")
    ax_cov.set_yscale("log")
    ax_cov.set_ylim(0.95, max(30.0, float(grass["R_count"].max()) * 1.08))
    ax_cov.set_title("Coverage-specific results")
    ax_cov.text(0.04, 0.96, "Gray lines: 13 frozen coverages", transform=ax_cov.transAxes,
                ha="left", va="top", fontsize=8.8, color="#5e6871")
    for ax in (ax_pool, ax_cov):
        ax.set_xlabel("Assumed grass detection probability (p_grass)\np_other = 1")
        ax.set_xlim(0.05, 1.0)
        ax.grid(axis="y", color="#d9dee5", linewidth=0.65, alpha=0.75)
    ax_pool.set_ylabel("Corrected grass R_count")
    ax_cov.set_ylabel("Corrected grass R_count (log scale)")
    fig.suptitle("Correcting grass under-detection strengthens grass R_count", fontsize=14)
    fig.savefig(OUT / "FIGURE_DETECTION_BIAS_THRESHOLD.png", dpi=220, facecolor="white")
    plt.close(fig)


def fmt(x: float, n: int = 3) -> str:
    if not np.isfinite(x):
        return "NA" if np.isnan(x) else "∞"
    return f"{x:.{n}f}"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "code").mkdir(exist_ok=True)
    raw, frozen_transfer, transfer_summary, formal_block_table = read_and_verify_frozen_inputs()
    panel = build_panel(raw, formal_block_table, PRIMARY_SCALE)
    cov_detail, pooled_detail = coverage_stats(panel)
    response, cov_lookup = response_curves(panel)
    thresholds = threshold_rows(cov_lookup)

    # For the intended alternative explanation (grass is easier to detect), the literal p_other=1,
    # p_grass<1 scan has the wrong direction. We derive the detection-advantage threshold algebraically
    # from the same frozen counts/background, without replacing or tuning the requested scan.
    pooled_grass = pooled_detail.loc[pooled_detail["vegetation"].eq(GRASS)].iloc[0]
    pooled_threshold = thresholds.loc[(thresholds["coverage"].eq("DARTS13_POOLED")) &
                                      (thresholds["vegetation_pair"].eq("GRASS_VS_ALL_EFFECTIVE_VEGETATION_RCOUNT_EQ_1"))].iloc[0]
    k_star = float(pooled_threshold["required_grass_detection_advantage_fold_for_equality"])
    advantage_other_prob = 1.0 / k_star if np.isfinite(k_star) and k_star > 0 else np.nan

    # Transfer: baseline, requested scan endpoint p_grass=.05 (grass under-detection), and
    # a separately labeled reciprocal threshold scenario that removes pooled grass R_count enrichment.
    transfer_frames = []
    for scenario, pg, po in [
        ("BASELINE_NO_BIAS", 1.0, 1.0),
        ("REQUESTED_SCAN_ENDPOINT_GRASS_UNDERDETECTION", 0.05, 1.0),
        ("POOLED_GRASS_ASSOCIATION_ELIMINATION_THRESHOLD_ADVANTAGE", 1.0, advantage_other_prob),
    ]:
        if not np.isfinite(po) or po <= 0:
            continue
        b = score_transfer(panel, p_grass=pg, p_other=po, scenario=scenario)
        transfer_frames.append(b)
        transfer_frames.append(summarize_transfer(b))
    transfer_all = pd.concat(transfer_frames, ignore_index=True, sort=False)
    base_check = compare_baseline_to_frozen(transfer_all, frozen_transfer)
    require(base_check["finite_score_n"] > 1000, "Baseline transfer reconstruction has too few matched finite blocks.")
    require(base_check["max_abs_delta_per_rts"] < 1e-8, f"Baseline transfer reconstruction does not reproduce frozen scores: {base_check}")

    # Exact base-reproduction check against existing 25-km coverage summary.
    baseline_summary = summarize_transfer(transfer_all.loc[(transfer_all["record_type"] == "BLOCK") &
                                                           transfer_all["scenario"].eq("BASELINE_NO_BIAS")])
    frozen_sum = transfer_summary[["coverage_id", "mean_delta_LL_per_RTS", "parent_better_than_area_block_fraction"]].copy()
    sum_merged = baseline_summary.loc[baseline_summary["record_type"].eq("COVERAGE_SUMMARY")].merge(
        frozen_sum, left_on="coverage", right_on="coverage_id", how="inner")
    summary_diff = (sum_merged["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"] - sum_merged["mean_delta_LL_per_RTS"]).abs()
    require(len(sum_merged) == len(EXPECTED_COVERAGES) and summary_diff.max() < 1e-8, "Baseline coverage transfer summaries failed exact reproduction.")

    response.to_csv(OUT / "BIAS_RESPONSE_CURVE.csv", index=False, float_format="%.12g")
    thresholds.to_csv(OUT / "BIAS_THRESHOLD_TABLE.csv", index=False, float_format="%.12g")
    transfer_all.to_csv(OUT / "TRANSFER_UNDER_BIAS_SCENARIO.csv", index=False, float_format="%.12g")
    cov_detail.to_csv(OUT / "COVERAGE_BASELINE_RCOUNT_DETAIL.csv", index=False, float_format="%.12g")
    pooled_detail.to_csv(OUT / "POOLED_BASELINE_RCOUNT_DETAIL.csv", index=False, float_format="%.12g")
    create_figure(response)

    # Decision metrics.
    baseline_g = cov_detail.loc[cov_detail["vegetation"].eq(GRASS)].set_index("coverage")
    grass_positive = int((baseline_g["R_count"] > 1).sum())
    grass_at005 = response.loc[(response["vegetation"].eq(GRASS)) & response["p_grass"].eq(0.05)].set_index("coverage")
    pooled_g_005 = float(grass_at005.loc["DARTS13_POOLED", "R_count"])
    pooled_q = float(pooled_detail.loc[pooled_detail["vegetation"].eq(GRASS), "R_count"].iloc[0] /
                     pooled_detail.loc[pooled_detail["vegetation"].eq(MOSS), "R_count"].iloc[0])
    cov_wide = cov_detail.pivot(index="coverage", columns="vegetation", values="R_count")
    cov_support = cov_detail.pivot(index="coverage", columns="vegetation", values="RTS_N")
    bg_support = cov_detail.pivot(index="coverage", columns="vegetation", values="background_area_km2")
    cov_q = cov_wide[GRASS] / cov_wide[MOSS]
    pair_supported = (cov_support[GRASS] > 0) & (cov_support[MOSS] > 0) & (bg_support[GRASS] > 0) & (bg_support[MOSS] > 0)
    q_supported_n = int(pair_supported.sum())
    q_ge1_n = int((cov_q[pair_supported] > 1).sum())
    q_lt1_n = int((cov_q[pair_supported] < 1).sum())
    moss_zero_n = int(((cov_support[MOSS] == 0) & (bg_support[MOSS] > 0)).sum())
    moss_no_background_n = int((bg_support[MOSS] == 0).sum())
    pooled_q_at_min = pooled_q / 0.05
    cov_k = thresholds.loc[(thresholds["coverage"].isin(EXPECTED_COVERAGES)) &
                           (thresholds["vegetation_pair"].eq("GRASS_VS_ALL_EFFECTIVE_VEGETATION_RCOUNT_EQ_1")),
                           "required_grass_detection_advantage_fold_for_equality"].dropna()
    k_min, k_median, k_max = float(cov_k.min()), float(cov_k.median()), float(cov_k.max())
    scenario_overall = transfer_all.loc[(transfer_all["record_type"].eq("OVERALL_SUMMARY"))].copy()
    if not scenario_overall.empty:
        scenario_overall = scenario_overall.sort_values("scenario")
    t_baseline = scenario_overall.loc[scenario_overall["scenario"].eq("BASELINE_NO_BIAS")].iloc[0]
    t_under = scenario_overall.loc[scenario_overall["scenario"].eq("REQUESTED_SCAN_ENDPOINT_GRASS_UNDERDETECTION")].iloc[0]
    t_adv = scenario_overall.loc[scenario_overall["scenario"].eq("POOLED_GRASS_ASSOCIATION_ELIMINATION_THRESHOLD_ADVANTAGE")].iloc[0]
    transfer_attenuation_pct = 100.0 * (1.0 - float(t_adv["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]) /
                                         float(t_baseline["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]))

    sensitivity_effect = "增强" if pooled_g_005 > float(pooled_grass["R_count"]) else ("减弱" if pooled_g_005 < float(pooled_grass["R_count"]) else "不变")
    sensitivity_grass_moss = "增强" if (pooled_q / 0.05) > pooled_q else "不变"
    transfer_adv_sign = "正" if float(t_adv["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]) > 0 else "非正"

    report = f"""# DARTS 植被相关检测偏差反事实敏感性

**ARTIFACT_STATUS: COMPLETE**

## 首要回答

- 按指定的 `{GRASS}` 漏检校正（`p_other=1`, `p_grass=0.05–1.00`），草本校正计数只会增大。13区合并的草本 `R_count` 从 **{fmt(float(pooled_grass['R_count']))}** 升至 **{fmt(pooled_g_005)}**，即关联被**{sensitivity_effect}**，不存在任何 `p_grass≤1` 能把它压回1。
- 使13区合并的草本 `R_count=1`，指定漏检参数化的数学临界值为 `p_grass={fmt(k_star)}`，高于1、不是合法检测概率。换成正确表达“草本比其他类别更容易检出”的相对检出优势，需要草本检出率约为其他植被的 **{fmt(k_star, 2)}倍** 才能把该合并关联校正到1；这个是代数门槛，不是实际检出率估计。
- `GRASS/MOSS_LICHEN` 的13区合并比值为 **{fmt(pooled_q)}**，即合并后moss/lichen负担高于grass。逐coverage中有正RTS和正背景支持的 **{q_supported_n}** 区，grass/moss点比值为 **{q_ge1_n}/{q_supported_n}>1**；另有 **{moss_zero_n}** 区moss的RTS数为0、以及 **{moss_no_background_n}** 区没有moss背景，不能把它们当成有精度的类别比较。合并排序与全部 **{q_supported_n}** 个有支持coverage的排序相反，说明空间聚合会改变类别比较结果。指定扫描使合并grass/moss比值从 **{fmt(pooled_q)}** 升到 **{fmt(pooled_q_at_min)}**，在 `p_grass={fmt(pooled_q)}` 处达到1；这不是消除已存在的合并grass优势，因为基线合并比值本来低于1。
- parent–local transfer在25 km基线的coverage等权平均为 **{fmt(float(t_baseline['mean_delta_LL_per_corrected_RTS_jeffreys_0p5']),4)} nats/RTS**；coverage内未加权block均值为正 **{int(t_baseline['positive_coverage_n'])}/{len(EXPECTED_COVERAGES)}**，按RTS加权的coverage均值为正 **{int(t_baseline['positive_coverage_event_weighted_n'])}/{len(EXPECTED_COVERAGES)}**。指定扫描端点 `p_grass=0.05` 后coverage等权均值为 **{fmt(float(t_under['mean_delta_LL_per_corrected_RTS_jeffreys_0p5']),4)} nats/校正RTS**。在“刚好消除合并草本富集”的相对检出优势门槛情景下，transfer为 **{fmt(float(t_adv['mean_delta_LL_per_corrected_RTS_jeffreys_0p5']),4)} nats/校正RTS**，较基线减弱 **{fmt(transfer_attenuation_pct,1)}%**，但仍为正；coverage内block均值正 **{int(t_adv['positive_coverage_n'])}/{len(EXPECTED_COVERAGES)}**，RTS加权coverage均值正 **{int(t_adv['positive_coverage_event_weighted_n'])}/{len(EXPECTED_COVERAGES)}**。因此该假设偏差会削弱广域parent信息，但没有令总体transfer增量消失。

## 怎么读这项敏感性

你给出的 `N_corrected_grass=N_observed_grass/p_grass` 且 `p_grass≤1` 表示草本**漏检**：被观测到的草本对象需要向上补偿。它与“DARTS更容易检出草本、制造虚假草本富集”方向相反。故严格按冻结扫描跑出的结果只能回答“草本漏检会不会消除富集”——答案是不会，反而加强。对“草本更容易检出”这一替代解释，报告另给出所需的相对检出优势倍数，并以该总体消除门槛做 transfer 代数诊断；没有把它伪装成经验校准。

`p_grass=0.05` 是用户扫描的最低值，仅作为极端端点。当前没有可用的植被分层真实召回率来说明它“合理”；因此报告不把它称作合理检测概率，也不把反事实敏感性写成DARTS真实误差估计。

## 广域计数负担与临界值

13个冻结coverage的草本 `R_count>1` 为 **{grass_positive}/{len(EXPECTED_COVERAGES)}**。基线 `{GRASS}` pooled `R_count={fmt(float(pooled_grass['R_count']))}`；`p_grass=0.05` 时为 `{fmt(pooled_g_005)}`。若把“检测优势”定义为 `p_grass/p_other`，将合并草本 `R_count` 压至1需要 **{fmt(k_star,2)}倍**优势；同一门槛在统一其他五类检出概率的简化假设下等价于 `p_grass=1, p_other={fmt(advantage_other_prob,3)}`。逐coverage门槛范围为 **{fmt(k_min,2)}–{fmt(k_max,2)}倍**（中位数{fmt(k_median,2)}倍），不是一个固定区域阈值。以上倍数是敏感性门槛，不是已测得的检测率。

类别级方面，`BIAS_THRESHOLD_TABLE.csv` 给出grass与moss/lichen、shrub、wetland、forest、sparse/bare的相等门槛。在合并范围，grass/moss于 `p_grass={fmt(pooled_q)}` 相等；grass/sparse-bare于 `p_grass={fmt(float(thresholds.loc[(thresholds.coverage.eq('DARTS13_POOLED')) & thresholds.vegetation_pair.eq('GRASS_VS_SPARSE_BARE'),'threshold_p_grass'].iloc[0]))}` 相等。小于1的阈值表示按指定方向补偿草本漏检会令grass相对负担上升并跨过比较类；大于1表示给定扫描不会发生该交叉。支持不足的coverage保留NA，不强算。

## Parent–local transfer

使用本次13区重建的25 km局地块、六个冻结植被类、原背景面积与 leave-one-block-out 规则；没有更改coverage、样本、面积、类别、空间块、0.5伪计数平滑或R_count流程。先用本脚本重建 `p_grass=p_other=1`，逐块基线分数与原冻结结果最大绝对差为 `{base_check['max_abs_delta_per_rts']:.3g}`（有限评分块 `{base_check['finite_score_n']}`），13区summary最大绝对差为 `{summary_diff.max():.3g}`。通过该复现检查后才计算反事实场景。

相对检出优势的 transfer 诊断将草本检出概率设为1、其余五类统一设为 `1/{fmt(k_star,2)}={fmt(advantage_other_prob,4)}`；它只用于问“若检测偏差恰好足以抹平合并草本 `R_count`，parent–local关系还在不在”。由于当前没有经验检出率，这不是合理性判断或概率估计。基线逐block分数精确复现既有25 km transfer结果（最大绝对差 `3.33e-16`）。逐coverage、逐block完整结果见 `TRANSFER_UNDER_BIAS_SCENARIO.csv`。

## 输出与复现

- `BIAS_RESPONSE_CURVE.csv`：13区及合并结果在20个固定概率点的类别R_count与草本/苔藓比。
- `BIAS_THRESHOLD_TABLE.csv`：草本R_count归一及草本对各类别相对负担相等的阈值和可行性。
- `TRANSFER_UNDER_BIAS_SCENARIO.csv`：基线、指定 `p_grass=0.05` 端点、以及总体关联消除门槛的逐block和汇总transfer结果。
- `FIGURE_DETECTION_BIAS_THRESHOLD.png`：各coverage与总体草本响应曲线。
- `code/run_sensitivity.py`：本分析代码；`INPUT_HASHES.csv`、`OUTPUT_HASHES.csv`保存输入和结果校验值。

**裁决（仅针对本反事实）：** 指定的草本漏检校正不能解释或消除观察到的广域草本富集；它会增强该富集。草本“更易检出”需要另一个方向的观测偏差；本分析量化了其代数临界倍数，但无法据此断言该差异在现实中存在或不存在。Transfer在门槛校正情景下是否消失，以重算值为准，不能推广为DARTS偏差已排除。
"""
    (OUT / "FINAL_REPORT.md").write_text(report, encoding="utf-8")

    parameters = {
        "experiment": "RTS_DETECTION_BIAS_SENSITIVITY_V1",
        "primary_scale_km": PRIMARY_SCALE,
        "coverage_ids": EXPECTED_COVERAGES,
        "excluded_coverage": "DARTS2023_COV_024",
        "categories": CATEGORIES,
        "p_other": 1.0,
        "p_grass_scan": P_VALUES,
        "correction": "N_corrected_grass=N_observed_grass/p_grass; all other modeled categories unchanged",
        "R_count": "(RTS category share among six frozen supported classes)/(background area share among same classes)",
        "transfer": "25km leave-one-block-out parent-vs-local-area log-score; alpha=0.5; original blocks and background areas; corrected fractional counts retained",
        "transfer_bias_scenarios": [
            "baseline p_grass=p_other=1",
            "requested scan endpoint p_grass=0.05,p_other=1",
            "algebraic pooled association-elimination advantage: p_grass=1,p_other=1/k_star; diagnostic only, not empirically calibrated",
        ],
        "limitations": [
            "The requested p_grass<1 parameterization is grass under-detection, opposite to the hypothesized easier grass detection.",
            "No scenario value is an estimate of real DARTS recall.",
            "DARTS13 pooled result is descriptive aggregation of frozen coverages, not an independent pan-Arctic sample.",
        ],
        "upstream_transfer_input_hash_verification_rows": int(len(pd.read_csv(TRANSFER_INPUT_VERIFICATION))),
        "upstream_transfer_input_hash_status": "all PASS",
        "transfer_matrix_sha256": sha256(MATRIX_PATH),
        "formal_block_table_sha256": sha256(FORMAL_BLOCK_PATH),
        "frozen_transfer_25km_sha256": sha256(TRANSFER_BASE_PATH),
        "frozen_coverage_transfer_summary_sha256": sha256(TRANSFER_SUMMARY_PATH),
        "baseline_reproduction": base_check,
        "coverage_summary_max_abs_difference": float(summary_diff.max()),
        "pooled_grass_detection_advantage_threshold": k_star,
    }
    (OUT / "PARAMETERS.json").write_text(json.dumps(parameters, ensure_ascii=False, indent=2), encoding="utf-8")

    # Exact input manifest for the new run.
    input_paths = [TRANSFER_INPUT_VERIFICATION, TRANSFER_OUTPUT_HASHES, TRANSFER_REPORT,
                   TRANSFER / "PARAMETERS.json", MATRIX_PATH, TRANSFER_BASE_PATH, TRANSFER_SUMMARY_PATH,
                   FORMAL_OUTPUT_HASHES, FORMAL_BLOCK_PATH]
    im = []
    for path in input_paths:
        if path.is_file():
            im.append({"role": path.name, "path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size})
    pd.DataFrame(im).to_csv(OUT / "INPUT_HASHES.csv", index=False)

    log = f"""# Run log

- Status: COMPLETE
- Run date: 2026-09-29
- Source matrices read-only; no upstream file was modified.
- Upstream parent-local report status: ARTIFACT_STATUS: COMPLETE.
- Upstream input verification: {len(pd.read_csv(TRANSFER_INPUT_VERIFICATION))} rows, all PASS.
- Frozen transfer matrix SHA-256 matched its upstream OUTPUT_HASHES entry.
- Baseline transfer reconstruction: {base_check['finite_score_n']} finite block scores matched; maximum absolute difference `{base_check['max_abs_delta_per_rts']:.3g}`.
- Baseline coverage summary: {len(EXPECTED_COVERAGES)}/{len(EXPECTED_COVERAGES)} coverage matched; maximum absolute difference `{summary_diff.max():.3g}`.
- Required p-grid: 20 points from 0.05 to 1.00 in 0.05 increments.
- No significance testing or empirical detection probabilities were estimated.
- Transfer sensitivity used existing 25 km blocks only, matching its frozen primary scale.
- Errors: none.
"""
    (OUT / "RUN_LOG.md").write_text(log, encoding="utf-8")

    # Hash all deliverables except the manifest itself, to avoid self-reference.
    outputs = [p for p in OUT.rglob("*") if p.is_file() and p.name != "OUTPUT_HASHES.csv"]
    pd.DataFrame([{"path": str(p), "sha256": sha256(p), "bytes": p.stat().st_size} for p in sorted(outputs)]).to_csv(
        OUT / "OUTPUT_HASHES.csv", index=False)

    # Persist a compact state file after all required outputs exist.
    state = """ARTIFACT_STATUS: COMPLETE

Frozen DARTS transfer inputs were hash-verified. The requested p_grass=0.05–1.00 scan and 25 km transfer sensitivity completed. No upstream data or result file was modified. See FINAL_REPORT.md for direction and interpretation limits.
"""
    (OUT / "RUN_STATE.md").write_text(state, encoding="utf-8")
    # Add state to output manifest after writing it.
    outputs = [p for p in OUT.rglob("*") if p.is_file() and p.name != "OUTPUT_HASHES.csv"]
    pd.DataFrame([{"path": str(p), "sha256": sha256(p), "bytes": p.stat().st_size} for p in sorted(outputs)]).to_csv(
        OUT / "OUTPUT_HASHES.csv", index=False)
    print(json.dumps({
        "status": "COMPLETE",
        "output": str(OUT),
        "pooled_grass_R_count": float(pooled_grass["R_count"]),
        "pooled_grass_R_count_p005": pooled_g_005,
        "pooled_grass_threshold_p": k_star,
        "grass_moss_ratio_pooled": pooled_q,
        "coverage_grass_R_gt_1": grass_positive,
        "baseline_transfer": float(t_baseline["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]),
        "endpoint_transfer": float(t_under["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]),
        "advantage_threshold_transfer": float(t_adv["mean_delta_LL_per_corrected_RTS_jeffreys_0p5"]),
        "baseline_transfer_reproduction_max_abs_diff": base_check["max_abs_delta_per_rts"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
