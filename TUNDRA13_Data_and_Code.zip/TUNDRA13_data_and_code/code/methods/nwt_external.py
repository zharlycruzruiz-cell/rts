from pathlib import Path
import hashlib,json,time
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp
from pyproj import Transformer
ROOT=Path(r'E:\zuom\gu\RUNS\ROUND_20260828_01'); PROJ=ROOT/'RTS_TUNDRA13_FULL_REANALYSIS_V1'; RES=PROJ/'results'; OUT=PROJ/'nwt'/'results'; NWT=ROOT/'RTS_NWT2015_022_EXTERNAL_BLIND_VALIDATION_V1'; FORMAL=ROOT/'RTS_NWT_2015_022_FORMALIZATION_V1'
IDS=json.loads((PROJ/'TUNDRA13_COVERAGE_MANIFEST.json').read_text(encoding='utf-8'))['coverage_ids']; CATS=['GRASS_HERBACEOUS','SHRUB','MOSS_LICHEN','FOREST','WETLAND','SPARSE_BARE']; FREE=np.arange(1,6); SEED=20261008; NBOOT=1000

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def fit(q,y):
 q=np.asarray(q,float);y=np.asarray(y,float);n=y.sum(axis=1);ok=(n>0)&(q.sum(axis=1)>0);q=q[ok];y=y[ok];n=n[ok]
 if np.any((q==0)&(y>0)):raise RuntimeError('zero background with positive RTS count')
 obs=y/n[:,None];lq=np.full_like(q,-np.inf);np.log(q,out=lq,where=q>0);w=np.ones(len(n))/len(n)
 def fg(x):
  beta=np.zeros(6);beta[FREE]=x;z=lq+beta[None,:];lp=z-logsumexp(z,axis=1,keepdims=True);pr=np.exp(lp);loss=-float(np.sum(w[:,None]*obs*np.where(obs>0,lp,0)));grad=np.sum(w[:,None]*(pr-obs),axis=0)[FREE];return loss,grad
 r=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':1000});beta=np.zeros(6);beta[FREE]=r.x;loss,g=fg(r.x)
 if not np.isfinite(beta).all() or np.max(np.abs(g))>2e-6:raise RuntimeError('13-zone beta fit did not converge')
 return beta,{'n_train_coverage':len(n),'n_train_rts':int(n.sum()),'objective':loss,'max_abs_gradient':float(np.max(np.abs(g))),'success':bool(r.success)}
def predict(q,b):
 z=np.full(6,-np.inf);np.log(q,out=z,where=q>0);z+=b;return np.exp(z-logsumexp(z))
def score(obs,qa,p):
 tv_a=.5*np.abs(obs-qa).sum();tv_b=.5*np.abs(obs-p).sum();ll=lambda pr:float(np.sum(np.where(obs>0,obs*np.log(np.where(pr>0,pr,1)),0)))
 return {'TV_area':float(tv_a),'TV_shared13':float(tv_b),'delta_TV':float(tv_a-tv_b),'G':float(1-tv_b/tv_a) if tv_a>1e-15 else np.nan,'mean_log_score_area':ll(qa),'mean_log_score_shared13':ll(p)}
def main():
 start=time.time()
 qd=pd.read_csv(RES/'TUNDRA13_BACKGROUND_BLIND_Q.csv').set_index('coverage_id').loc[IDS];q=np.array([[qd.loc[cid,'q_'+cat] for cat in CATS] for cid in IDS])
 yd=pd.read_csv(RES/'TUNDRA13_RCOUNT_ALL_CLASSES.csv');y=np.array([[int(yd[(yd.coverage_id==cid)&(yd.vegetation==cat)].RTS_n.iloc[0]) for cat in CATS] for cid in IDS])
 beta,info=fit(q,y)
 # Freeze external prediction before reading any target RTS class assignments.
 qtab=pd.read_csv(NWT/'NWT2015_022_BACKGROUND_Q_V1.csv').set_index('vegetation_class').loc[CATS];qn=qtab.q_NWT.to_numpy(float)
 if not np.isclose(qn.sum(),1,atol=1e-12):raise RuntimeError('NWT q does not close')
 pn=predict(qn,beta)
 pred=pd.DataFrame({'vegetation_class':CATS,'q_area_only':qn,'beta_full_TUNDRA13':beta,'association_multiplier':np.exp(beta),'prediction_area_only':qn,'prediction_shared_TUNDRA13':pn,'training_coverage_n':len(IDS),'training_coverage_ids':'|'.join(IDS),'training_RTS_n':int(y.sum()),'prediction_written_before_target_class_open':'YES'})
 pred.to_csv(OUT/'NWT_TUNDRA13_PREDICTION_LOCK.csv',index=False)
 lock={'prediction_file_sha256':sha(OUT/'NWT_TUNDRA13_PREDICTION_LOCK.csv'),'prediction_sum':float(pn.sum()),'target_assignment_opened_before_prediction':False,'model_fit':info,'coverage_ids':IDS,'excluded':'DARTS2023_COV_024'}
 (OUT/'NWT_TUNDRA13_PREDICTION_LOCK.json').write_text(json.dumps(lock,indent=2),encoding='utf-8')
 # Score only after predictions are saved and hash-locked.
 ass=pd.read_csv(NWT/'NWT2015_022_ACTIVE_RTS_ASSIGNMENT_V1.csv'); valid=ass[ass.community.isin(CATS)].copy();yn=valid.community.value_counts().reindex(CATS,fill_value=0).to_numpy(int);obs=yn/yn.sum();m=score(obs,qn,pn)
 pd.DataFrame({'vegetation_class':CATS,'RTS_n':yn,'observed_share':obs,'q_area_only':qn,'prediction_shared_TUNDRA13':pn,'residual_shared13':obs-pn}).to_csv(OUT/'NWT_TUNDRA13_SCORE_BY_CLASS.csv',index=False)
 # Training-zone bootstrap estimates uncertainty in the newly refit 13-zone association.
 rng=np.random.default_rng(SEED);boot=[];fail=0
 for rep in range(1,NBOOT+1):
  ix=rng.integers(0,len(IDS),size=len(IDS)); yb=[]
  for j in ix:
   n=int(y[j].sum());yb.append(rng.multinomial(n,y[j]/n))
  try:
   bb,_=fit(q[ix],np.asarray(yb));pp=predict(qn,bb);sm=score(obs,qn,pp);boot.append({'replicate':rep,**sm,'predicted_grass':pp[0]})
  except Exception as e:fail+=1;boot.append({'replicate':rep,'failure':repr(e),'G':np.nan})
 bdf=pd.DataFrame(boot);bdf.to_csv(OUT/'NWT_TUNDRA13_TRAINING_COVERAGE_BOOTSTRAP.csv',index=False)
 # Target spatial block bootstrap with the locked full-13 beta.
 bg=pd.read_csv(FORMAL/'NWT_2015_022_BACKGROUND_GRID.csv'); bg=bg[bg.community.isin(CATS)].copy(); rt=valid[['rts_id','community','centroid_lon','centroid_lat']].copy()
 tr=Transformer.from_crs(4326,6933,always_xy=True)
 for km in [25,50]:
  size=km*1000; bx,by=tr.transform(bg.center_lon.to_numpy(float),bg.center_lat.to_numpy(float));bg['block']=np.floor(np.asarray(bx)/size).astype(int).astype(str)+'_'+np.floor(np.asarray(by)/size).astype(int).astype(str)
  rx,ry=tr.transform(rt.centroid_lon.to_numpy(float),rt.centroid_lat.to_numpy(float));rt['block']=np.floor(np.asarray(rx)/size).astype(int).astype(str)+'_'+np.floor(np.asarray(ry)/size).astype(int).astype(str)
  blocks=sorted(bg.block.unique()); amap=bg.pivot_table(index='block',columns='community',values='coverage_intersection_area_m2',aggfunc='sum',fill_value=0).reindex(index=blocks,columns=CATS,fill_value=0).to_numpy(float); ymap=pd.crosstab(rt.block,rt.community).reindex(index=blocks,columns=CATS,fill_value=0).to_numpy(int); rrng=np.random.default_rng(SEED+km); rows=[]
  for rep in range(1,NBOOT+1):
   take=rrng.integers(0,len(blocks),size=len(blocks)); aa=amap[take].sum(axis=0); nn=ymap[take].sum(axis=0)
   if aa.sum()<=0 or nn.sum()<=0:continue
   qb=aa/aa.sum();ob=nn/nn.sum(); pb=predict(qb,beta);rows.append({'replicate':rep,'sampled_blocks_n':len(blocks),'sampled_RTS_n':int(nn.sum()),**score(ob,qb,pb)})
  z=pd.DataFrame(rows);z.to_csv(OUT/f'NWT_TUNDRA13_SPATIAL_BOOTSTRAP_{km}KM.csv',index=False)
 summary={'training_coverages':len(IDS),'training_RTS_n':int(y.sum()),'target':'NWT 2015-022 active RTS, unresolved external source provenance retained','target_valid_RTS_n':int(yn.sum()),'training_beta_fit':info,**m,'training_coverage_bootstrap_requested':NBOOT,'training_coverage_bootstrap_valid':int(bdf.G.notna().sum()),'training_coverage_bootstrap_failures':fail,'training_bootstrap_G_CI95':[float(bdf.G.quantile(.025)),float(bdf.G.quantile(.975))],'training_bootstrap_P_G_gt0':float((bdf.G>0).mean()),'prediction_file_sha256':lock['prediction_file_sha256'],'elapsed_seconds':time.time()-start}
 (OUT/'NWT_TUNDRA13_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 inp=[NWT/'NWT2015_022_BACKGROUND_Q_V1.csv',NWT/'NWT2015_022_ACTIVE_RTS_ASSIGNMENT_V1.csv',FORMAL/'NWT_2015_022_BACKGROUND_GRID.csv',RES/'TUNDRA13_BACKGROUND_BLIND_Q.csv',RES/'TUNDRA13_RCOUNT_ALL_CLASSES.csv']
 pd.DataFrame([{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in inp]).to_csv(OUT/'INPUT_HASHES.csv',index=False)
 (OUT/'FINAL_REPORT.md').write_text('# NWT external prediction with newly refit 13-zone association\n\n**ARTIFACT_STATUS: COMPLETE**\n\n'+json.dumps(summary,indent=2),encoding='utf-8')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
