"""Portable reproduction of the regional composition models and SM16 sensitivity.

Run from any directory: python /path/to/code/reproduce.py check
All package inputs are read-only. New results go to a separate output directory.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, json, platform, time
from pathlib import Path
import numpy as np
import pandas as pd
import models as M
import regularization as R

PACKAGE=Path(__file__).resolve().parents[1]
DATA=PACKAGE/'data'

def inputs():
    with np.load(DATA/'model_inputs.npz',allow_pickle=False) as a:
        ids=a['coverage_ids'].tolist(); cats=a['classes'].tolist()
        q=a['q'].copy();y=a['y'].copy()
        areas=[a[f'area_{j:02d}'].copy() for j in range(13)]
        counts=[a[f'count_{j:02d}'].copy() for j in range(13)]
    assert cats==M.CATS and len(ids)==len(set(ids))==13
    assert int(y.sum())==11189 and int(y[:,0].sum())==10108
    for j,(area,count) in enumerate(zip(areas,counts)):
        assert np.array_equal(count.sum(axis=0),y[j])
        assert np.max(np.abs(area.sum(axis=0)/area.sum()-q[j]))<1e-12
    return ids,q,y,areas,counts

def regularized(qq,yy,ids,rep):
    beta,theta,gradient,dgradient=R.fit_batch(qq,yy)
    rows=[];params=[];weights=[]
    for j,label in enumerate(R.LABELS):
        d=np.zeros((13,6));d[:,0]=theta[j,:13]
        rows.extend(R.metric_rows(qq,yy,R.predict_all(qq,beta[j,:13]),ids,'C_'+label,rep))
        rows.extend(R.metric_rows(qq,yy,R.predict_all(qq,d),ids,'D_'+label,rep))
        for f,cid in enumerate(ids):
            params.append(dict(replicate=rep,setting=label,coverage_id=cid,
                C_gradient=float(gradient[j,f]),D_gradient=float(dgradient[j,f]),D_theta=float(theta[j,f]),
                **{'beta_'+c:float(beta[j,f,k]) for k,c in enumerate(M.CATS)}))
        for k,c in enumerate(M.CATS):
            weights.append(dict(replicate=rep,setting=label,community=c,beta=float(beta[j,13,k]),weight=float(np.exp(beta[j,13,k]))))
    b,_=R.fit_global_unpenalized(qq,yy)
    for k,c in enumerate(M.CATS):
        weights.append(dict(replicate=rep,setting='unpenalized',community=c,beta=float(b[k]),weight=float(np.exp(b[k]))))
    return pd.DataFrame(rows),pd.DataFrame(params),pd.DataFrame(weights)

def sampled(rng,q,y,areas,counts):
    qs=[];ys=[]
    for a,c in zip(areas,counts):
        ix=rng.integers(0,len(a),size=len(a));aa=a[ix].sum(axis=0)
        qs.append(aa/aa.sum());ys.append(c[ix].sum(axis=0))
    # This advances the original interleaved object-bootstrap stream, preserving
    # the published paired spatial draws rather than silently using a new stream.
    M.advance_legacy_object_stream(rng,y)
    return np.asarray(qs),np.asarray(ys)

def main_models(qq,yy,ids,rep):
    p,_,_=M.evaluate(qq,yy,ids);p['replicate']=rep
    return p

def compare_values(actual,expected,keys,columns,tolerance=1e-6):
    a=actual.set_index(keys).sort_index();b=expected.set_index(keys).reindex(a.index)
    if b[columns].isna().any().any(): raise RuntimeError('Missing expected records')
    av=a[columns].to_numpy(float);bv=b[columns].to_numpy(float)
    finite=np.isfinite(av)&np.isfinite(bv)
    same_nonfinite=(av==bv)&~np.isfinite(av)&~np.isfinite(bv)
    if not np.all(finite|same_nonfinite):
        raise RuntimeError('Non-finite scores differ between reproduced and stored records')
    error=float(np.max(np.abs(av[finite]-bv[finite]))) if finite.any() else 0.0
    if error>tolerance: raise RuntimeError(f'Reproduction error {error} exceeds {tolerance}')
    return error

def check(out,reps):
    start=time.monotonic();ids,q,y,areas,counts=inputs()
    expected=pd.read_csv(DATA/'model_points.csv')
    p=main_models(q,y,ids,0);r,_,_=regularized(q,y,ids,0)
    point=pd.concat([p,r],ignore_index=True)
    point_error=compare_values(point,expected,['model','coverage_id'],['TV','logscore_nats_per_RTS','raw_logscore_nats_per_RTS'])
    stored=pd.read_csv(DATA/'bootstrap_scores.csv.xz')
    assert len(stored)==143000 and stored.groupby('replicate').size().eq(143).all()
    original=stored[stored.model.isin(M.MODELS)]
    assert len(original)==65000
    rng=np.random.default_rng(M.SEED);errors=[]
    for rep in range(1,reps+1):
        qq,yy=sampled(rng,q,y,areas,counts)
        p=main_models(qq,yy,ids,rep);r,_,_=regularized(qq,yy,ids,rep)
        current=pd.concat([p,r],ignore_index=True)
        errors.append(compare_values(current,stored[stored.replicate.eq(rep)],['model','coverage_id'],['TV','logscore_nats_per_RTS','raw_logscore_nats_per_RTS'],1e-5))
    # Intervals are recomputed from every retained score, not a demonstration subset.
    pp=R.paired(expected);bp=R.paired(stored)
    summary=R.summaries(pp,bp,['setting','comparison'],['delta_TV','delta_logscore_nats_per_RTS','G'])
    source=json.loads((DATA/'source_tables.json').read_text(encoding='utf-8'))['PAIRED_SUMMARY.csv']
    ref=pd.DataFrame(source[1:],columns=source[0])
    keys=['setting','comparison','metric','statistic']
    numeric=[c for c in ['point','ci025','ci975'] if c in summary]
    summary_error=compare_values(summary,ref,keys,numeric,1e-9)
    summary.to_csv(out/'paired_summary.csv',index=False)
    info=dict(status='PASS',coverage_n=13,object_n=11189,original_score_rows=65000,
              total_score_rows=len(stored),point_max_abs_error=point_error,
              resamples_refitted=reps,resample_score_max_abs_error=max(errors,default=0),
              all_replicate_summary_max_abs_error=summary_error,
              python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
              elapsed_seconds=time.monotonic()-start)
    (out/'verification.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(info,indent=2))

def bootstrap(out,reps):
    start=time.monotonic();ids,q,y,areas,counts=inputs()
    p=main_models(q,y,ids,0);r,params,weights=regularized(q,y,ids,0)
    point=pd.concat([p,r],ignore_index=True);point.to_csv(out/'model_points.csv',index=False)
    all_scores=[];all_params=[params];all_weights=[weights]
    rng=np.random.default_rng(M.SEED)
    for rep in range(1,reps+1):
        qq,yy=sampled(rng,q,y,areas,counts)
        p=main_models(qq,yy,ids,rep);r,params,weights=regularized(qq,yy,ids,rep)
        all_scores.append(pd.concat([p,r],ignore_index=True))
        all_params.append(params);all_weights.append(weights)
        if rep%50==0: print(f'{rep}/{reps}',flush=True)
    scores=pd.concat(all_scores,ignore_index=True)
    cols=['replicate','coverage_id','model','TV','logscore_nats_per_RTS','raw_logscore_nats_per_RTS']
    scores[cols].to_csv(out/'bootstrap_scores.csv.xz',index=False,compression='xz')
    pd.concat(all_params,ignore_index=True).to_csv(out/'fold_parameters.csv.xz',index=False,compression='xz')
    w=pd.concat(all_weights,ignore_index=True);w.to_csv(out/'weight_replicates.csv.xz',index=False,compression='xz')
    pp=R.paired(point);bp=R.paired(scores)
    R.summaries(pp,bp,['setting','comparison'],['delta_TV','delta_logscore_nats_per_RTS','G']).to_csv(out/'paired_summary.csv',index=False)
    intervals=[]
    for (setting,cat),g in w.groupby(['setting','community'],sort=False):
        pt=g[g.replicate.eq(0)].iloc[0];bs=g[g.replicate.gt(0)]
        intervals.append(dict(setting=setting,community=cat,point_beta=pt.beta,point_weight=pt.weight,
            beta_ci025=bs.beta.quantile(.025),beta_ci975=bs.beta.quantile(.975),
            weight_ci025=bs.weight.quantile(.025),weight_ci975=bs.weight.quantile(.975),bootstrap_n=len(bs)))
    pd.DataFrame(intervals).to_csv(out/'weight_intervals.csv',index=False)
    print(json.dumps(dict(status='COMPLETE',resamples=reps,score_rows=len(scores),elapsed_seconds=time.monotonic()-start)))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['check','bootstrap'])
    parser.add_argument('--replicates',type=int)
    parser.add_argument('--out',type=Path,default=PACKAGE/'reproduced_results')
    args=parser.parse_args()
    reps=args.replicates if args.replicates is not None else (3 if args.command=='check' else 1000)
    if not 1<=reps<=1000: parser.error('--replicates must be between 1 and 1000')
    out=args.out.resolve()
    if out==DATA.resolve() or DATA.resolve() in out.parents: parser.error('Output must not be inside the data directory')
    out.mkdir(parents=True,exist_ok=True)
    if args.command=='check':check(out,reps)
    else:bootstrap(out,reps)
