from __future__ import annotations

import hashlib
import itertools
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp
from scipy.stats import spearmanr

ROOT = Path(r"E:/zuom/gu")
ROUND = ROOT / "RUNS/ROUND_20260828_01"
OUT = ROUND / "RTS_SHARED_RULE_BLIND_RECONSTRUCTION_FINAL_AUDIT_V1"
V1 = ROUND / "RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V1/checkpoints"
V2 = ROUND / "RTS_VEGETATION_CIRCUMARCTIC_EXPANSION_V2/unit_cache"
CLASSES = ["GRASS_HERBACEOUS", "SHRUB", "MOSS_LICHEN", "FOREST", "WETLAND", "SPARSE_BARE"]
IDS_NUM = [1, 3, 13, 14, 17, 19, 21, 22, 24, 28, 31, 32, 33, 35]
IDS = [f"DARTS2023_COV_{i:03d}" for i in IDS_NUM]
REF = 0
FREE = np.array([1, 2, 3, 4, 5], dtype=int)
SEED = 20261007
BOOT_REPS = 1000
STRUCT_PERM_REPS = 10000


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def assignment_path(i: int) -> Path:
    base = V1 if i in {1, 3, 13, 14, 17, 21, 22} else V2
    return base / f"DARTS2023_COV_{i:03d}_RTS_ASSIGNMENTS.csv"


def read_counts(i: int) -> np.ndarray:
    d = pd.read_csv(assignment_path(i), usecols=["rts_id", "community"])
    if d.rts_id.astype(str).duplicated().any():
        raise RuntimeError(f"Duplicate RTS IDs in {IDS[IDS_NUM.index(i)]}")
    allowed = set(CLASSES) | {"EXCLUDED_NON_VEGETATION"}
    if not set(d.community.dropna().unique()).issubset(allowed):
        raise RuntimeError(f"Unexpected class in {IDS[IDS_NUM.index(i)]}")
    # Fixed canonical mask excludes explicit non-vegetation assignments; they
    # are audited but never folded into one of the six vegetation classes.
    return d.loc[d.community.isin(CLASSES), "community"].value_counts().reindex(CLASSES, fill_value=0).to_numpy(dtype=int)


def softmax_q_beta(q: np.ndarray, beta: np.ndarray) -> np.ndarray:
    q = np.asarray(q, float)
    b = np.asarray(beta, float)
    z = np.full_like(q, -np.inf)
    np.log(q, out=z, where=q > 0)
    z = z + b
    den = logsumexp(z)
    if not np.isfinite(den):
        raise RuntimeError("Prediction cannot be normalized")
    return np.exp(z - den)


def fit_beta(q: np.ndarray, y: np.ndarray, weighting: str) -> tuple[np.ndarray, dict]:
    """Unregularized shared association; grass is the frozen reference class."""
    q = np.asarray(q, float)
    y = np.asarray(y, float)
    n = y.sum(axis=1)
    active = (n > 0) & (q.sum(axis=1) > 0)
    q = q[active]
    y = y[active]
    n = n[active]
    if len(n) < 2:
        raise RuntimeError("Insufficient informative training coverages")
    if np.any((q == 0) & (y > 0)):
        raise RuntimeError("Training support inconsistency q=0 with RTS count>0")
    obs = y / n[:, None]
    logq = np.full_like(q, -np.inf)
    np.log(q, out=logq, where=q > 0)
    if weighting == "coverage_equal":
        w = np.full(len(n), 1.0 / len(n))
    elif weighting == "object_weighted":
        w = n / n.sum()
    else:
        raise ValueError(weighting)

    def fg(x):
        beta = np.zeros(len(CLASSES))
        beta[FREE] = x
        z = logq + beta[None, :]
        lp = z - logsumexp(z, axis=1, keepdims=True)
        p = np.exp(lp)
        loss = -np.sum(w[:, None] * obs * np.where(obs > 0, lp, 0.0))
        grad = np.sum(w[:, None] * (p - obs), axis=0)[FREE]
        return float(loss), grad

    res = minimize(lambda x: fg(x), np.zeros(len(FREE)), jac=True, method="BFGS",
                   options={"gtol": 1e-10, "maxiter": 1000})
    loss, grad = fg(res.x)
    beta = np.zeros(len(CLASSES))
    beta[FREE] = res.x
    # Do not accept an optimizer status alone: a small score gradient is required.
    if not np.isfinite(beta).all() or np.max(np.abs(grad)) > 2e-6:
        raise RuntimeError(f"Unresolved shared-model fit ({weighting}): {res.message}; maxgrad={np.max(np.abs(grad))}; beta={beta}")
    info = {"weighting": weighting, "converged": bool(res.success), "optimizer_message": str(res.message),
            "iterations": int(res.nit), "objective_mean_per_object": loss,
            "max_abs_gradient": float(np.max(np.abs(grad))), "training_coverages": int(len(n)),
            "training_RTS_n": int(n.sum())}
    return beta, info


def tv(obs: np.ndarray, pred: np.ndarray) -> float:
    return float(0.5 * np.abs(np.asarray(obs) - np.asarray(pred)).sum())


def comp_matrix_distance(x: np.ndarray) -> np.ndarray:
    return 0.5 * np.abs(x[:, None, :] - x[None, :, :]).sum(axis=2)


def upper_corr(a: np.ndarray, b: np.ndarray) -> float:
    ix = np.triu_indices(a.shape[0], 1)
    val = spearmanr(a[ix], b[ix]).statistic
    return float(val) if np.isfinite(val) else float("nan")


def input_manifest() -> pd.DataFrame:
    base = pd.read_csv(OUT / "INPUT_HASHES.csv")
    rows = []
    for r in base.itertuples(index=False):
        p = Path(r.path)
        actual = sha(p)
        if actual != r.sha256 or p.stat().st_size != int(r.size_bytes):
            raise RuntimeError(f"Frozen q input hash mismatch: {p}")
        rows.append({"path": str(p), "sha256": actual, "size_bytes": p.stat().st_size, "role": r.role})
    for i in IDS_NUM:
        p = assignment_path(i)
        if not p.exists():
            raise FileNotFoundError(p)
        rows.append({"path": str(p), "sha256": sha(p), "size_bytes": p.stat().st_size,
                     "role": "frozen DARTS CGLS RTS assignment; class counts opened only after target prediction stored in each LOCO fold"})
    return pd.DataFrame(rows)


def bootstrap(q: np.ndarray, y: np.ndarray, reps: int, seed: int):
    rng = np.random.default_rng(seed)
    m = len(IDS)
    g_rows = []
    med_rows = []
    failures = 0
    for b in range(reps):
        sampled_targets = rng.integers(0, m, size=m)
        # Each coverage is resampled as an independent outer cluster. Within each
        # training coverage, RTS objects are resampled by its observed class composition.
        target_g = []
        for target in np.unique(sampled_targets):
            other_ids = np.array([j for j in range(m) if j != target])
            draw = rng.choice(other_ids, size=m - 1, replace=True)
            tq, ty = [], []
            for j in draw:
                n_j = int(y[j].sum())
                if n_j == 0:
                    continue
                tq.append(q[j])
                ty.append(rng.multinomial(n_j, y[j] / n_j))
            try:
                beta, _ = fit_beta(np.asarray(tq), np.asarray(ty), "coverage_equal")
                n_t = int(y[target].sum())
                if n_t == 0:
                    continue
                y_t = rng.multinomial(n_t, y[target] / n_t)
                obs_t = y_t / y_t.sum()
                p_a = q[target]
                p_b = softmax_q_beta(p_a, beta)
                tv_a, tv_b = tv(obs_t, p_a), tv(obs_t, p_b)
                g = np.nan if tv_a <= 1e-12 else 1.0 - tv_b / tv_a
                target_g.append((int(target), float(g), tv_a, tv_b))
            except Exception:
                failures += 1
        if len(target_g) == 0:
            continue
        expanded = []
        for target, g, _, _ in target_g:
            expanded.extend([g] * int((sampled_targets == target).sum()))
            g_rows.append({"replicate": b + 1, "coverage_id": IDS[target], "G": g})
        med_rows.append({"replicate": b + 1, "median_G": float(np.nanmedian(expanded)),
                         "mean_G": float(np.nanmean(expanded)), "n_target_folds_scored": len(expanded)})
    return pd.DataFrame(med_rows), pd.DataFrame(g_rows), failures


def main():
    start = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    hashes = input_manifest()
    hashes.to_csv(OUT / "ALL_INPUT_HASHES_V1.csv", index=False)
    qtab = pd.read_csv(OUT / "Q_BACKGROUND_COMPOSITION_INDEPENDENT.csv").set_index("coverage_id").loc[IDS]
    q = qtab[[f"q_{c}" for c in CLASSES]].to_numpy(float)
    if not np.isfinite(q).all() or (q < 0).any() or not np.allclose(q.sum(axis=1), 1, atol=1e-10):
        raise RuntimeError("Independent background q table invalid")
    sup = pd.read_csv(OUT / "RTS_SHARED_RULE_SUPPORT_AUDIT_V1.csv")
    if sup.support_flag.eq("SUPPORT_VIOLATION_Q0_RTS_POSITIVE").any():
        raise RuntimeError("Support audit failed; no model permitted")

    input_support = []
    for i in IDS_NUM:
        src = pd.read_csv(assignment_path(i), usecols=["rts_id", "community"])
        input_support.append({"coverage_id": IDS[IDS_NUM.index(i)], "assignment_rows_total": len(src),
                              "six_class_RTS_n": int(src.community.isin(CLASSES).sum()),
                              "explicit_nonvegetation_excluded_n": int(src.community.eq("EXCLUDED_NON_VEGETATION").sum()),
                              "other_or_missing_assignment_n": int((~src.community.isin(CLASSES) & ~src.community.eq("EXCLUDED_NON_VEGETATION")).sum())})
    pd.DataFrame(input_support).to_csv(OUT / "RTS_SHARED_RULE_INPUT_SUPPORT_V1.csv", index=False)

    rows, predrows, betarows = [], [], []
    y_all = np.zeros((len(IDS), len(CLASSES)), dtype=int)
    for i, target_id in enumerate(IDS):
        # Strict blind order: read only the 13 training compositions, fit beta,
        # and persist predictions before opening the target assignment file.
        train_idx = [j for j in range(len(IDS)) if j != i]
        train_y = np.stack([read_counts(IDS_NUM[j]) for j in train_idx])
        train_q = q[train_idx]
        beta_equal, info_equal = fit_beta(train_q, train_y, "coverage_equal")
        beta_object, info_object = fit_beta(train_q, train_y, "object_weighted")
        pred_a = q[i].copy()
        pred_b = softmax_q_beta(q[i], beta_equal)
        pred_b_obj = softmax_q_beta(q[i], beta_object)
        # Now the target is opened, only for scoring and stored observed composition.
        y_target = read_counts(IDS_NUM[i])
        y_all[i] = y_target
        n_target = int(y_target.sum())
        obs = y_target / n_target
        tv_a = tv(obs, pred_a)
        tv_b = tv(obs, pred_b)
        tv_b_obj = tv(obs, pred_b_obj)
        gain = np.nan if tv_a <= 1e-12 else 1.0 - tv_b / tv_a
        gain_obj = np.nan if tv_a <= 1e-12 else 1.0 - tv_b_obj / tv_a
        row = {"coverage_id": target_id, "n_RTS": n_target, "TV_A": tv_a, "TV_B_equal": tv_b,
               "TV_A_minus_TV_B_equal": tv_a - tv_b, "SHARED_RECONSTRUCTION_GAIN_G": gain,
               "B_equal_better_than_A": bool(tv_b < tv_a), "TV_B_object_weighted": tv_b_obj,
               "G_object_weighted_secondary": gain_obj, "B_object_weighted_better_than_A": bool(tv_b_obj < tv_a),
               "TV_C_theoretical_perfect_endpoint": 0.0,
               "C_status": "OBSERVED_COMPOSITION_ENDPOINT_ONLY_NOT_AN_INDEPENDENT_MODEL"}
        for k, c in enumerate(CLASSES):
            row[f"q_{c}"] = q[i, k]
            row[f"obs_{c}"] = obs[k]
            row[f"pred_A_{c}"] = pred_a[k]
            row[f"pred_B_equal_{c}"] = pred_b[k]
            row[f"pred_B_object_{c}"] = pred_b_obj[k]
            predrows.append({"coverage_id": target_id, "vegetation_class": c, "q_background": q[i,k],
                             "observed_RTS_composition": obs[k], "pred_A_background_only": pred_a[k],
                             "pred_B_shared_coverage_equal": pred_b[k], "pred_B_shared_object_weighted": pred_b_obj[k],
                             "residual_B_equal_obs_minus_pred": obs[k] - pred_b[k]})
            for version, beta, info in [("PRIMARY_COVERAGE_EQUAL", beta_equal, info_equal),
                                        ("SECONDARY_OBJECT_WEIGHTED", beta_object, info_object)]:
                betarows.append({"target_coverage_id": target_id, "training_excludes_target": True,
                                 "training_coverage_n": 13,
                                 "training_coverage_ids": "|".join(IDS[j] for j in train_idx),
                                 "model_branch": version, "fit_weighting": info["weighting"],
                                 "vegetation_class": c, "beta_relative_to_grass": beta[k],
                                 "association_multiplier": np.exp(beta[k]), **info})
        rows.append(row)
        print(f"LOCO {i+1}/14 {target_id}: TV_A={tv_a:.4f}, TV_B={tv_b:.4f}, G={gain:.4f}", flush=True)

    result = pd.DataFrame(rows)
    predictions = pd.DataFrame(predrows)
    betas = pd.DataFrame(betarows)
    result.to_csv(OUT / "RTS_SHARED_RULE_COVERAGE_RESULTS_V1.csv", index=False)
    predictions.to_csv(OUT / "RTS_SHARED_RULE_PREDICTED_COMPOSITIONS_V1.csv", index=False)
    betas.to_csv(OUT / "RTS_SHARED_RULE_LOCO_BETAS_V1.csv", index=False)

    # Coverage-equal summary. No object-weighted statistic is used as primary.
    g = result.SHARED_RECONSTRUCTION_GAIN_G.to_numpy(float)
    tv_a = result.TV_A.to_numpy(float)
    tv_b = result.TV_B_equal.to_numpy(float)
    observed = y_all / y_all.sum(axis=1, keepdims=True)
    pred = predictions.pivot(index="coverage_id", columns="vegetation_class", values="pred_B_shared_coverage_equal").loc[IDS, CLASSES].to_numpy()
    dq, dobs, dpred = map(comp_matrix_distance, (q, observed, pred))
    r_q = upper_corr(dobs, dq)
    r_pred = upper_corr(dobs, dpred)
    rng = np.random.default_rng(SEED + 11)
    struct_null = np.empty(STRUCT_PERM_REPS)
    for b in range(STRUCT_PERM_REPS):
        perm = rng.permutation(len(IDS))
        struct_null[b] = upper_corr(dobs, dpred[np.ix_(perm, perm)])
    delta_r = r_pred - r_q
    struct_p = (1 + np.sum((struct_null - r_q) >= delta_r)) / (STRUCT_PERM_REPS + 1)
    structure = pd.DataFrame([{"rho_DOBS_DQ": r_q, "rho_DOBS_DPRED": r_pred, "delta_r_pred_minus_q": delta_r,
                               "null_percentile_rho_pred": float(np.mean(struct_null <= r_pred)),
                               "permutation_p_one_sided_delta_vs_q": struct_p,
                               "permutations": STRUCT_PERM_REPS}])
    structure.to_csv(OUT / "RTS_SHARED_RULE_STRUCTURE_RECONSTRUCTION_V1.csv", index=False)
    pd.DataFrame({"replicate": np.arange(1, STRUCT_PERM_REPS + 1), "rho_DOBS_DPRED_permuted": struct_null,
                  "delta_r_vs_background": struct_null - r_q}).to_csv(OUT / "RTS_SHARED_RULE_STRUCTURE_PERMUTATION_NULL_V1.csv", index=False)

    # Exact 6! association-label permutations; one shared class permutation is
    # applied consistently across all LOCO folds.
    beta_mat = betas[betas.model_branch.eq("PRIMARY_COVERAGE_EQUAL")].pivot(
        index="target_coverage_id", columns="vegetation_class", values="beta_relative_to_grass").loc[IDS, CLASSES].to_numpy()
    label_rows = []
    all_perms = list(itertools.permutations(range(len(CLASSES))))
    identity = tuple(range(len(CLASSES)))
    for perm in all_perms:
        g_perm, tvbs = [], []
        for i in range(len(IDS)):
            p = softmax_q_beta(q[i], beta_mat[i, list(perm)])
            tva, tvb = tv(observed[i], q[i]), tv(observed[i], p)
            tvbs.append(tvb)
            g_perm.append(np.nan if tva <= 1e-12 else 1 - tvb / tva)
        label_rows.append({"permutation": ",".join(CLASSES[k] for k in perm), "is_identity": perm == identity,
                           "median_TV_B": float(np.median(tvbs)), "median_G": float(np.nanmedian(g_perm)),
                           "B_better_than_A_n": int(np.sum(np.asarray(g_perm) > 0))})
    labels = pd.DataFrame(label_rows)
    actual_idx = labels.index[labels.is_identity][0]
    actual_g = float(labels.loc[actual_idx, "median_G"])
    labels["rank_median_G_descending"] = labels.median_G.rank(method="min", ascending=False).astype(int)
    rank = int(labels.loc[actual_idx, "rank_median_G_descending"])
    exact_p = float(np.sum(labels.median_G >= actual_g - 1e-12) / len(labels))
    labels.to_csv(OUT / "RTS_SHARED_RULE_PERMUTATION_NULL_V1.csv", index=False)

    # Two-level bootstrap: resample coverage targets and, within training and
    # target coverages, resample RTS objects; refit beta for every target fold.
    boot_summary, boot_cov, boot_fail = bootstrap(q, y_all, BOOT_REPS, SEED + 21)
    boot_summary.to_csv(OUT / "RTS_SHARED_RULE_BOOTSTRAP_SUMMARY_V1.csv", index=False)
    boot_cov.to_csv(OUT / "RTS_SHARED_RULE_BOOTSTRAP_COVERAGE_V1.csv", index=False)
    if len(boot_summary) < BOOT_REPS * 0.95:
        raise RuntimeError(f"Too many failed bootstrap replicates: {len(boot_summary)}/{BOOT_REPS}; failed fold fits={boot_fail}")
    boot_ci = np.quantile(boot_summary.median_G, [0.025, 0.975])
    p_med_pos = float(np.mean(boot_summary.median_G > 0))
    cov_ci = boot_cov.groupby("coverage_id").G.agg(
        boot_n="count", median="median", ci_low=lambda x: x.quantile(.025), ci_high=lambda x: x.quantile(.975)).reset_index()
    cov_ci.to_csv(OUT / "RTS_SHARED_RULE_COVERAGE_BOOTSTRAP_CI_V1.csv", index=False)

    # Leave-one-coverage influence using final strict LOCO fold predictions.
    infl_rows = []
    for omitted in range(len(IDS)):
        keep = np.array([j for j in range(len(IDS)) if j != omitted])
        corr = upper_corr(dobs[np.ix_(keep,keep)], dpred[np.ix_(keep,keep)])
        infl_rows.append({"omitted_coverage": IDS[omitted], "median_G": float(np.nanmedian(g[keep])),
                          "mean_G": float(np.nanmean(g[keep])), "B_better_than_A_n": int(np.sum(g[keep] > 0)),
                          "n_remaining": len(keep), "rho_DOBS_DPRED": corr})
    influence = pd.DataFrame(infl_rows)
    influence.to_csv(OUT / "RTS_SHARED_RULE_LEAVE_ONE_COVERAGE_V1.csv", index=False)

    # The only named-window records previously found were post-hoc RTS-derived
    # extents outside/partially outside the frozen DARTS14 support. They are not
    # independent fixed-window tests and are not assigned predictive scores.
    cases_path = ROUND / "RTS_BROAD_TO_LOCAL_TRANSFER_V1/POST_HOC_CASE_SUPPORT_AUDIT.csv"
    if cases_path.exists():
        cases = pd.read_csv(cases_path)
        named = cases[cases.case.isin(["Peel", "Banks", "Novaya"])].copy()
        named["analysis_status"] = "ILLUSTRATIVE_ONLY_NOT_SCORABLE_AS_BLIND_EXTERNAL_PREDICTION"
        named["reason"] = "Existing audit records RTS-derived extents; no pre-fixed independent window boundary and no independent q table. Strict blind score withheld."
    else:
        named = pd.DataFrame([{"case": x, "analysis_status": "NOT_AUDITABLE_NO_FROZEN_WINDOW_RECORD"} for x in ["Peel", "Banks", "Novaya"]])
    # Explicit NA columns show that no q/OBS/prediction score was generated for
    # windows that failed the pre-fixed-boundary / independent-q audit.
    for c in CLASSES:
        for prefix in ("q", "observed", "pred_A", "pred_B"):
            col = f"{prefix}_{c}"
            if col not in named:
                named[col] = np.nan
    for col in ("TV_A", "TV_B", "G"):
        if col not in named:
            named[col] = np.nan
    named.to_csv(OUT / "RTS_SHARED_RULE_NAMED_WINDOWS_V1.csv", index=False)

    # Error anatomy for failures, without selecting a favorable subset.
    failrows = []
    for i, cov in enumerate(IDS):
        resid = observed[i] - pred[i]
        worst = int(np.argmax(np.abs(resid)))
        failrows.append({"coverage_id": cov, "TV_B": tv_b[i], "G": g[i],
                         "B_worse_than_A": tv_b[i] > tv_a[i], "largest_absolute_class_residual": CLASSES[worst],
                         "observed_minus_predicted_residual": resid[worst],
                         "overpredicted_class": CLASSES[worst] if resid[worst] < 0 else "",
                         "underpredicted_class": CLASSES[worst] if resid[worst] > 0 else ""})
    pd.DataFrame(failrows).to_csv(OUT / "RTS_SHARED_RULE_FAILURE_ANATOMY_V1.csv", index=False)

    summary = {
        "n_coverages": len(IDS), "n_rts": int(y_all.sum()), "median_TV_A": float(np.median(tv_a)),
        "median_TV_B_equal": float(np.median(tv_b)), "median_G": float(np.nanmedian(g)),
        "mean_G": float(np.nanmean(g)), "IQR_G": [float(np.nanquantile(g,.25)), float(np.nanquantile(g,.75))],
        "B_better_than_A_n": int(np.sum(tv_b < tv_a)), "B_worse_than_A_n": int(np.sum(tv_b > tv_a)),
        "bootstrap_median_G_CI95": [float(boot_ci[0]), float(boot_ci[1])],
        "bootstrap_P_median_G_gt_0": p_med_pos, "bootstrap_success_replicates": int(len(boot_summary)),
        "bootstrap_failed_fold_fits": int(boot_fail), "rho_DOBS_DQ": r_q, "rho_DOBS_DPRED": r_pred,
        "delta_r_pred_minus_q": delta_r, "structure_permutation_p": struct_p,
        "association_identity_rank_desc_median_G": rank, "association_identity_percentile": float((720-rank+1)/720),
        "association_identity_exact_permutation_probability": exact_p,
        "min_leave_one_out_median_G": float(influence.median_G.min()),
        "max_leave_one_out_median_G": float(influence.median_G.max()),
        "named_windows_status": "ILLUSTRATIVE_ONLY_NOT_SCORABLE_AS_BLIND_EXTERNAL_PREDICTION",
        "old_predictive_gain_not_comparable": True,
    }
    (OUT / "SUMMARY_METRICS_V1.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    print(f"Finished in {(time.time()-start)/60:.1f} minutes", flush=True)


if __name__ == "__main__":
    main()
