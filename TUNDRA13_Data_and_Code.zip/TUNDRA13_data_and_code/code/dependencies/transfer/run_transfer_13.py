from __future__ import annotations
import hashlib, json, math, time, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pyproj import Transformer

warnings.filterwarnings('ignore', category=RuntimeWarning)
ROOT=Path(r'E:\zuom\gu')
ROUND=ROOT/'RUNS'/'ROUND_20260828_01'
SRC=ROUND/'DARTS_BLOCK_VEGETATION_INTERACTION_V1'
OUT=ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'results'/'TRANSFER'
SCALES=[10,25,50]
ALPHA=0.5
PPC_N=1000
BOOT_N=5000
BLOCK_CI_N=2000
SEED=20260928
MODELED_CATEGORIES=['FOREST','SHRUB','GRASS_HERBACEOUS','WETLAND','MOSS_LICHEN','SPARSE_BARE']
ALL_CATEGORIES=MODELED_CATEGORIES+['OTHER']
TR=Transformer.from_crs(4326,6933,always_xy=True)
INV=Transformer.from_crs(6933,4326,always_xy=True)

def digest(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def write_failure(rows:list[dict]):
    pd.DataFrame(rows,columns=['stage','scale_km','coverage_id','block_id','status','details']).to_csv(OUT/'FAILURE_LOG.csv',index=False)

def verify_inputs():
    params=json.loads((SRC/'PARAMETERS.json').read_text(encoding='utf-8'))
    manifest=json.loads((ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'TUNDRA13_COVERAGE_MANIFEST.json').read_text(encoding='utf-8'))
    coverages=manifest['coverage_ids']
    if len(set(coverages))!=len(coverages) or 'DARTS2023_COV_024' in coverages:
        raise RuntimeError(f'Invalid frozen tundra13 coverage manifest: {coverages}')
    inhash=pd.read_csv(SRC/'INPUT_HASHES.csv')
    inhash=inhash[inhash.coverage_id.isin(coverages)&inhash.role.isin(['RTS_ASSIGNMENTS','BACKGROUND_GRID'])].copy()
    verified=[]
    for row in inhash.itertuples(index=False):
        p=Path(row.path); actual=digest(p) if p.exists() else None
        ok=bool(p.exists() and actual==row.sha256 and p.stat().st_size==int(row.bytes))
        verified.append({'role':row.role,'coverage_id':row.coverage_id,'path':str(p),'expected_sha256':row.sha256,'actual_sha256':actual,'expected_bytes':int(row.bytes),'actual_bytes':p.stat().st_size if p.exists() else None,'status':'PASS' if ok else 'FAIL'})
    if len(verified)!=2*len(coverages) or any(x['status']!='PASS' for x in verified):
        pd.DataFrame(verified).to_csv(OUT/'INPUT_HASH_VERIFICATION.csv',index=False)
        raise RuntimeError('Tundra13 raw per-coverage inputs failed SHA-256/size verification.')
    pd.DataFrame(verified).to_csv(OUT/'INPUT_HASH_VERIFICATION.csv',index=False)
    params['target_coverages']=coverages
    return params,coverages,inhash

def construct_panel(scale:int, coverages:list[str], inhash:pd.DataFrame):
    """Rebuild coverage-block-category counts and areas exclusively from unit-level inputs."""
    div=float(scale*1000); closure=[]; all_rows=[]; excluded_rows=[]
    for cov in coverages:
        ir=inhash[(inhash.role=='RTS_ASSIGNMENTS')&(inhash.coverage_id==cov)].iloc[0]
        ib=inhash[(inhash.role=='BACKGROUND_GRID')&(inhash.coverage_id==cov)].iloc[0]
        r=pd.read_csv(ir.path,usecols=['rts_id','centroid_lon','centroid_lat','community'])
        n_source=len(r); other_n=int((~r.community.isin(MODELED_CATEGORIES)).sum())
        r=r[r.community.isin(MODELED_CATEGORIES)].copy()
        rx,ry=TR.transform(r.centroid_lon.to_numpy(float),r.centroid_lat.to_numpy(float))
        r['_bx']=np.floor(np.asarray(rx)/div).astype('int64'); r['_by']=np.floor(np.asarray(ry)/div).astype('int64')
        ragg=r.groupby(['_bx','_by','community'],as_index=False).size().rename(columns={'size':'RTS_N'})
        rtot=r.groupby(['_bx','_by'],as_index=False).size().rename(columns={'size':'RTS_total_all_classes'})
        bg=pd.read_csv(ib.path,usecols=['grid_id','center_lon','center_lat','community','coverage_intersection_area_m2'])
        bg=bg[bg.community.isin(MODELED_CATEGORIES)].copy()
        bg['coverage_intersection_area_m2']=pd.to_numeric(bg.coverage_intersection_area_m2,errors='coerce').fillna(0.0)
        bx,by=TR.transform(bg.center_lon.to_numpy(float),bg.center_lat.to_numpy(float))
        bg['_bx']=np.floor(np.asarray(bx)/div).astype('int64'); bg['_by']=np.floor(np.asarray(by)/div).astype('int64')
        bagg=bg.groupby(['_bx','_by','community'],as_index=False).agg(background_area_km2=('coverage_intersection_area_m2',lambda z:float(z.sum())/1e6),background_grid_n=('grid_id','nunique'))
        block_keys=set(map(tuple,r[['_bx','_by']].drop_duplicates().to_numpy().tolist())) if len(r) else set()
        block_keys |= set(map(tuple,bg[['_bx','_by']].drop_duplicates().to_numpy().tolist())) if len(bg) else set()
        rmap={(int(a),int(b),c):int(n) for a,b,c,n in ragg.itertuples(index=False)}
        bmap={(int(a),int(b),c):(float(ar),int(ng)) for a,b,c,ar,ng in bagg.itertuples(index=False)}
        total_map={(int(a),int(b)):int(n) for a,b,n in rtot.itertuples(index=False)}
        for ix,iy in sorted(block_keys):
            for cat in MODELED_CATEGORIES:
                ar,ng=bmap.get((ix,iy,cat),(0.0,0))
                all_rows.append({'coverage_id':cov,'block_id':f'{scale}_{ix}_{iy}','block_x':ix,'block_y':iy,'scale_km':scale,
                    'block_center_x_m':(ix+0.5)*div,'block_center_y_m':(iy+0.5)*div,'community':cat,
                    'RTS_N':rmap.get((ix,iy,cat),0),'background_area_km2':ar,'background_grid_n':ng,
                    'RTS_total_all_classes':total_map.get((ix,iy),0),
                    'block_analysis_background_area_km2':float(sum(bmap.get((ix,iy,c),(0.0,0))[0] for c in MODELED_CATEGORIES)),
                    'OTHER_RTS_excluded_from_frozen_category_set':other_n})
        panel_cov=[z for z in all_rows if z['coverage_id']==cov]
        eligible_n=sum(z['RTS_N'] for z in panel_cov)
        bg_area=sum(z['background_area_km2'] for z in panel_cov)
        closure.append({'scale_km':scale,'coverage_id':cov,'source_RTS_n':n_source,'modeled_class_RTS_n':eligible_n,
          'nonmodeled_RTS_n':other_n,'reconstructed_background_area_km2':bg_area,
          'status':'PASS' if eligible_n+n_source*0>=0 and bg_area>0 else 'FAIL'})
        if other_n: excluded_rows.append({'scale_km':scale,'coverage_id':cov,'nonmodeled_RTS_n':other_n,'status':'EXCLUDED_BY_FIXED_SIX_CLASS_SET'})
    panel=pd.DataFrame(all_rows)
    if panel.empty: raise RuntimeError(f'Failed to construct panel at {scale} km.')
    panel['block_center_lon'],panel['block_center_lat']=INV.transform(panel.block_center_x_m.to_numpy(float),panel.block_center_y_m.to_numpy(float))
    return panel,closure,excluded_rows

def verify_frozen_eligibility(panel25:pd.DataFrame):
    rows=[]
    for cat in MODELED_CATEGORIES:
        p=panel25[panel25.community.eq(cat)]
        cov=p.groupby('coverage_id').agg(bg=('background_area_km2','sum'),n=('RTS_N','sum'))
        nbg=int((cov.bg>0).sum()); nrts=int((cov.n>0).sum()); total=int(cov.n.sum())
        rows.append({'community':cat,'coverage_with_background_n':nbg,'coverage_with_RTS_n':nrts,'total_RTS_n':total,
          'frozen_category':'YES','status':'PASS' if nbg>0 and total>=0 else 'FAIL'})
    return pd.DataFrame(rows)

def logscore(counts:np.ndarray,p:np.ndarray)->float:
    if not np.isfinite(p).all() or abs(float(p.sum())-1)>1e-8: return np.nan
    active=counts>0
    if np.any(p[active]<=0): return -np.inf
    return float(np.sum(counts[active]*np.log(p[active])))

def deviance(counts:np.ndarray,p:np.ndarray)->float:
    n=int(counts.sum())
    if n==0: return 0.0
    if not np.isfinite(p).all() or abs(float(p.sum())-1)>1e-8: return np.nan
    active=counts>0
    if np.any(p[active]<=0): return np.inf
    q=counts[active]/n
    return float(2*n*np.sum(q*np.log(q/p[active])))

def deterministic_rng_key(scale:int,cov:str,block:str,tag:str='ppc'):
    h=hashlib.sha256(f'{SEED}|{scale}|{cov}|{block}|{tag}'.encode()).hexdigest()
    return np.random.default_rng(int(h[:16],16))

def score_panel(panel:pd.DataFrame,scale:int,neighbor_exclusion:bool=False,run_ppc:bool=False):
    p=panel[panel.scale_km.eq(scale)].copy()
    matrix=[]; scores=[]; ppc=[]
    k=len(MODELED_CATEGORIES)
    for cov,g in p.groupby('coverage_id',sort=True):
        blocks=[]
        for (bid,bx,by),q in g.groupby(['block_id','block_x','block_y'],sort=True):
            q=q.set_index('community').reindex(MODELED_CATEGORIES)
            nn=q.RTS_N.fillna(0).to_numpy(int); bb=q.background_area_km2.fillna(0).to_numpy(float)
            blocks.append({'block_id':bid,'block_x':int(bx),'block_y':int(by),'N':nn,'B':bb,'q':q.reset_index(names='community')})
        nmat=np.vstack([x['N'] for x in blocks]); bmat=np.vstack([x['B'] for x in blocks])
        nall=nmat.sum(axis=0); ball=bmat.sum(axis=0); cov_n=int(nall.sum()); cov_b=float(ball.sum())
        coord_to_idx={(x['block_x'],x['block_y']):j for j,x in enumerate(blocks)}
        for j,x in enumerate(blocks):
            keep=np.ones(len(blocks),dtype=bool); keep[j]=False
            if neighbor_exclusion:
                ix,iy=x['block_x'],x['block_y']
                for dx in (-1,0,1):
                    for dy in (-1,0,1):
                        z=coord_to_idx.get((ix+dx,iy+dy))
                        if z is not None: keep[z]=False
            train_n=nmat[keep].sum(axis=0); train_b=bmat[keep].sum(axis=0)
            train_nt=int(train_n.sum()); train_bt=float(train_b.sum())
            rtrain=np.full(k,np.nan,float)
            if train_nt>0 and train_bt>0:
                pos=train_b>0
                rtrain[pos]=(train_n[pos]/train_nt)/(train_b[pos]/train_bt)
                rtrain[pos & (train_n==0)]=0.0
            weights=np.where(np.isfinite(rtrain),x['B']*rtrain,0.0)
            ppar=weights/weights.sum() if weights.sum()>0 else np.full(k,np.nan)
            parea=x['B']/x['B'].sum() if x['B'].sum()>0 else np.full(k,np.nan)
            ni=int(x['N'].sum()); bi=float(x['B'].sum())
            status='SCORED' if ni>0 and np.isfinite(ppar).all() and np.isfinite(parea).all() else ('ZERO_RTS_NO_COMPOSITION' if ni==0 else 'NO_PARENT_OR_LOCAL_BACKGROUND_SUPPORT')
            qobs=x['N']/ni if ni>0 else np.full(k,np.nan)
            tv=float(0.5*np.abs(qobs-ppar).sum()) if ni>0 and np.isfinite(ppar).all() else np.nan
            ll_raw_p=logscore(x['N'],ppar); ll_raw_a=logscore(x['N'],parea)
            # Jeffreys-type 0.5 pseudo-count, fixed across every block, used only for finite log scoring.
            ps=(ni*ppar+ALPHA)/(ni+ALPHA*k) if ni>0 and np.isfinite(ppar).all() else np.full(k,np.nan)
            aas=(ni*parea+ALPHA)/(ni+ALPHA*k) if ni>0 and np.isfinite(parea).all() else np.full(k,np.nan)
            ll_s_p=logscore(x['N'],ps); ll_s_a=logscore(x['N'],aas)
            d_s=(ll_s_p-ll_s_a) if np.isfinite(ll_s_p) and np.isfinite(ll_s_a) else np.nan
            d_raw=(ll_raw_p-ll_raw_a) if np.isfinite(ll_raw_p) and np.isfinite(ll_raw_a) else (float('-inf') if ll_raw_p==-np.inf and np.isfinite(ll_raw_a) else np.nan)
            dp=deviance(x['N'],ppar); da=deviance(x['N'],parea)
            zero_parent=int(np.sum((x['N']>0)&(ppar==0))) if np.isfinite(ppar).all() else np.nan
            zero_area=int(np.sum((x['N']>0)&(parea==0))) if np.isfinite(parea).all() else np.nan
            local_r=[]
            for c in range(k):
                if ni>0 and bi>0 and x['B'][c]>0:
                    lr=(x['N'][c]/ni)/(x['B'][c]/bi)
                elif ni>0 and bi>0 and x['B'][c]==0 and x['N'][c]>0:
                    lr=float('inf')
                else: lr=np.nan
                local_r.append(lr)
                matrix.append({'scale_km':scale,'coverage_id':cov,'block_id':x['block_id'],'block_x':x['block_x'],'block_y':x['block_y'],
                  'block_center_x_m':(x['block_x']+0.5)*scale*1000,'block_center_y_m':(x['block_y']+0.5)*scale*1000,
                  'block_center_lon':float(INV.transform((x['block_x']+0.5)*scale*1000,(x['block_y']+0.5)*scale*1000)[0]),
                  'block_center_lat':float(INV.transform((x['block_x']+0.5)*scale*1000,(x['block_y']+0.5)*scale*1000)[1]),
                  'community':MODELED_CATEGORIES[c],'RTS_N_local':int(x['N'][c]),'RTS_N_local_total':ni,
                  'background_area_km2_local':float(x['B'][c]),'background_area_km2_local_total':bi,
                  'RTS_share_local':float(qobs[c]) if ni>0 else np.nan,'background_share_local':float(x['B'][c]/bi) if bi>0 else np.nan,
                  'R_count_local':lr,'R_train_parent':float(rtrain[c]) if np.isfinite(rtrain[c]) else np.nan,
                  'R_train_status':'TRAIN_RATE_ZERO' if rtrain[c]==0 else ('TRAIN_RATE_ESTIMABLE' if np.isfinite(rtrain[c]) else 'NO_TRAIN_BACKGROUND'),
                  'p_parent_local':float(ppar[c]) if np.isfinite(ppar[c]) else np.nan,'p_area_only_local':float(parea[c]) if np.isfinite(parea[c]) else np.nan,
                  'expected_parent_RTS_N':float(ni*ppar[c]) if np.isfinite(ppar[c]) else np.nan,
                  'expected_area_only_RTS_N':float(ni*parea[c]) if np.isfinite(parea[c]) else np.nan,
                  'observed_minus_parent_share':float(qobs[c]-ppar[c]) if np.isfinite(ppar[c]) and ni>0 else np.nan,
                  'local_to_parent_R_count':float(lr/rtrain[c]) if np.isfinite(lr) and rtrain[c]>0 else np.nan,
                  'parent_zero_probability_observed_count':bool(x['N'][c]>0 and np.isfinite(ppar[c]) and ppar[c]==0),
                  'local_background_zero_with_RTS':bool(x['B'][c]==0 and x['N'][c]>0)})
            score={'scale_km':scale,'coverage_id':cov,'block_id':x['block_id'],'block_x':x['block_x'],'block_y':x['block_y'],
              'block_center_lon':float(INV.transform((x['block_x']+0.5)*scale*1000,(x['block_y']+0.5)*scale*1000)[0]),
              'block_center_lat':float(INV.transform((x['block_x']+0.5)*scale*1000,(x['block_y']+0.5)*scale*1000)[1]),
              'block_N_RTS':ni,'block_background_area_km2':bi,'block_n_background_supported_classes':int((x['B']>0).sum()),
              'parent_train_RTS_n':train_nt,'parent_train_background_area_km2':train_bt,'parent_zero_rate_class_n':int(np.sum((train_n==0)&(train_b>0)),),
              'parent_no_training_background_class_n':int((train_b==0).sum()),'parent_prediction_status':status,
              'parent_unpredicted_observed_class_n':int(zero_parent) if np.isfinite(zero_parent) else np.nan,
              'area_only_unpredicted_observed_class_n':int(zero_area) if np.isfinite(zero_area) else np.nan,
              'LL_parent_unsmoothed':ll_raw_p,'LL_area_unsmoothed':ll_raw_a,'delta_LL_unsmoothed':d_raw,
              'LL_parent_Jeffreys_0p5':ll_s_p,'LL_area_Jeffreys_0p5':ll_s_a,'delta_LL':d_s,
              'delta_LL_per_RTS':d_s/ni if ni>0 and np.isfinite(d_s) else np.nan,
              'delta_LL_raw_status':'FINITE_BOTH' if np.isfinite(ll_raw_p) and np.isfinite(ll_raw_a) else ('PARENT_ZERO_PROB_OBSERVED' if ll_raw_p==-np.inf and np.isfinite(ll_raw_a) else ('BOTH_ZERO_PROB_OBSERVED' if ll_raw_p==-np.inf and ll_raw_a==-np.inf else 'UNAVAILABLE')),
              'TV_parent':tv,'parent_multinomial_deviance':dp,'area_only_multinomial_deviance':da,
              'neighbor_exclusion':bool(neighbor_exclusion),'valid_status':status}
            scores.append(score)
            if run_ppc:
                if ni==0:
                    ppc.append({'scale_km':scale,'coverage_id':cov,'block_id':x['block_id'],'block_N_RTS':0,'observed_parent_deviance':0.0,'simulated_deviance_p95':np.nan,'observed_exceeds_95pct':False,'monte_carlo_upper_tail_p':np.nan,'PPC_status':'ZERO_RTS_NO_COMPOSITION','simulations':PPC_N})
                elif not np.isfinite(ppar).all():
                    ppc.append({'scale_km':scale,'coverage_id':cov,'block_id':x['block_id'],'block_N_RTS':ni,'observed_parent_deviance':np.nan,'simulated_deviance_p95':np.nan,'observed_exceeds_95pct':np.nan,'monte_carlo_upper_tail_p':np.nan,'PPC_status':'NO_PARENT_SUPPORT','simulations':PPC_N})
                else:
                    rng=deterministic_rng_key(scale,cov,x['block_id'])
                    draws=rng.multinomial(ni,ppar,size=PPC_N)
                    positive=draws>0
                    dsim=np.zeros(PPC_N,float)
                    if np.any(positive):
                        terms=np.zeros_like(draws,dtype=float)
                        rows_,cols_=np.where(positive)
                        terms[rows_,cols_]=draws[rows_,cols_]*np.log((draws[rows_,cols_]/ni)/ppar[cols_])
                        dsim=2*np.sum(terms,axis=1)
                    q95=float(np.percentile(dsim,95)); exceed=bool(dp>q95)
                    tail=float((np.sum(dsim>=dp)+1)/(PPC_N+1)) if np.isfinite(dp) else float(1/(PPC_N+1))
                    ppc.append({'scale_km':scale,'coverage_id':cov,'block_id':x['block_id'],'block_N_RTS':ni,
                      'observed_parent_deviance':dp,'simulated_deviance_p95':q95,'observed_exceeds_95pct':exceed,
                      'monte_carlo_upper_tail_p':tail,'PPC_status':'EXCESS_DEVIANCE' if exceed else 'WITHIN_EXPECTED_SAMPLING_RANGE','simulations':PPC_N,
                      'observed_events_in_parent_zero_probability_classes':int(zero_parent) if np.isfinite(zero_parent) else np.nan})
    return pd.DataFrame(scores),pd.DataFrame(matrix),pd.DataFrame(ppc)

def block_bootstrap_ci(df:pd.DataFrame, metric:str, n:int, seed:int):
    z=df[metric].dropna().to_numpy(float)
    if len(z)==0: return (np.nan,np.nan)
    rng=np.random.default_rng(seed)
    means=np.empty(n,float)
    for i in range(n): means[i]=np.mean(rng.choice(z,size=len(z),replace=True))
    return tuple(np.percentile(means,[2.5,97.5]))

def summarize_coverage(scores:pd.DataFrame,scale:int):
    rows=[]
    for cov,g in scores[scores.scale_km.eq(scale)].groupby('coverage_id',sort=True):
        scored=g[(g.block_N_RTS>0)&g.delta_LL_per_RTS.notna()]
        tv=g[g.block_N_RTS>0].TV_parent.dropna()
        pp=g[g.block_N_RTS>0]
        llci=block_bootstrap_ci(scored,'delta_LL_per_RTS',BLOCK_CI_N,SEED+scale+int(cov[-3:]))
        tvci=block_bootstrap_ci(scored,'TV_parent',BLOCK_CI_N,SEED+2*scale+int(cov[-3:]))
        exc=g[g.block_N_RTS>0].parent_multinomial_deviance.notna()
        ppc_excess=(g[g.block_N_RTS>0].coverage_id.eq(cov))
        rows.append({'scale_km':scale,'coverage_id':cov,'blocks_total_n':len(g),'blocks_nonzero_RTS_n':int((g.block_N_RTS>0).sum()),
          'blocks_scored_n':len(scored),'zero_RTS_blocks_n':int((g.block_N_RTS==0).sum()),'RTS_total_n':int(g.block_N_RTS.sum()),
          'mean_delta_LL_per_RTS':float(scored.delta_LL_per_RTS.mean()) if len(scored) else np.nan,
          'median_delta_LL_per_RTS':float(scored.delta_LL_per_RTS.median()) if len(scored) else np.nan,
          'event_weighted_delta_LL_per_RTS':float(scored.delta_LL.sum()/scored.block_N_RTS.sum()) if len(scored) and scored.block_N_RTS.sum()>0 else np.nan,
          'block_bootstrap_mean_delta_LL_per_RTS_CI025':llci[0],'block_bootstrap_mean_delta_LL_per_RTS_CI975':llci[1],
          'mean_delta_LL':float(scored.delta_LL.mean()) if len(scored) else np.nan,
          'parent_better_than_area_block_fraction':float((scored.delta_LL>0).mean()) if len(scored) else np.nan,
          'mean_TV':float(tv.mean()) if len(tv) else np.nan,'median_TV':float(tv.median()) if len(tv) else np.nan,
          'block_bootstrap_mean_TV_CI025':tvci[0],'block_bootstrap_mean_TV_CI975':tvci[1],
          'blocks_exceed_parent_PPC95_n':int(g.loc[g.block_N_RTS.gt(0),'observed_exceeds_95pct'].fillna(False).sum()) if 'observed_exceeds_95pct' in g.columns else np.nan,
          'blocks_exceed_parent_PPC95_fraction':np.nan,
          'mean_unpredicted_observed_class_n':float(scored.parent_unpredicted_observed_class_n.mean()) if len(scored) else np.nan})
        if 'observed_exceeds_95pct' in g.columns:
            ex=g[g.block_N_RTS.gt(0)&g.observed_exceeds_95pct.notna()]
            rows[-1]['blocks_exceed_parent_PPC95_fraction']=float(ex.observed_exceeds_95pct.mean()) if len(ex) else np.nan
    return pd.DataFrame(rows)

def hierarchical_bootstrap(scores:pd.DataFrame,scale:int):
    sub=scores[scores.scale_km.eq(scale)].copy()
    covs=sorted(sub.coverage_id.unique())
    mats={c:sub[(sub.coverage_id==c)&(sub.block_N_RTS>0)&sub.delta_LL_per_RTS.notna()].copy() for c in covs}
    covs=[c for c in covs if len(mats[c])]
    rng=np.random.default_rng(SEED+50000+scale)
    out=[]
    for rep in range(1,BOOT_N+1):
        chosen=rng.choice(covs,size=len(covs),replace=True)
        metric=[]
        for cov in chosen:
            g=mats[cov]
            pick=rng.integers(0,len(g),size=len(g))
            z=g.iloc[pick]
            metric.append({'delta':float(z.delta_LL_per_RTS.mean()),'tv':float(z.TV_parent.mean()),
              'win':float((z.delta_LL>0).mean()),'excess':float(z.observed_exceeds_95pct.mean()) if z.observed_exceeds_95pct.notna().any() else np.nan})
        out.append({'scale_km':scale,'replicate':rep,'coverage_draw_n':len(chosen),
          'equal_coverage_mean_delta_LL_per_RTS':float(np.nanmean([x['delta'] for x in metric])),
          'equal_coverage_mean_TV':float(np.nanmean([x['tv'] for x in metric])),
          'equal_coverage_parent_win_fraction':float(np.nanmean([x['win'] for x in metric])),
          'equal_coverage_PPC_excess_fraction':float(np.nanmean([x['excess'] for x in metric]))})
    return pd.DataFrame(out)

def scale_summary(summaries:dict[int,pd.DataFrame], boot:dict[int,pd.DataFrame]):
    rows=[]
    for s in SCALES:
        c=summaries[s]; b=boot[s]
        d=b.equal_coverage_mean_delta_LL_per_RTS.to_numpy(float)
        t=b.equal_coverage_mean_TV.to_numpy(float)
        rows.append({'analysis':'LEAVE_ONE_BLOCK_OUT','scale_km':s,'coverage_n':int(c.coverage_id.nunique()),'blocks_total_n':int(c.blocks_total_n.sum()),
          'blocks_scored_n':int(c.blocks_scored_n.sum()),'coverage_delta_LL_positive_n':int((c.event_weighted_delta_LL_per_RTS>0).sum()),
          'coverage_delta_LL_positive_fraction':float((c.event_weighted_delta_LL_per_RTS>0).mean()),
          'coverage_median_event_weighted_delta_LL_per_RTS':float(c.event_weighted_delta_LL_per_RTS.median()),
          'coverage_min_event_weighted_delta_LL_per_RTS':float(c.event_weighted_delta_LL_per_RTS.min()),
          'coverage_max_event_weighted_delta_LL_per_RTS':float(c.event_weighted_delta_LL_per_RTS.max()),
          'hierarchical_bootstrap_mean_delta_CI025':float(np.nanpercentile(d,2.5)),'hierarchical_bootstrap_mean_delta_CI975':float(np.nanpercentile(d,97.5)),
          'hierarchical_bootstrap_P_mean_delta_gt_0':float(np.nanmean(d>0)),
          'coverage_median_mean_TV':float(c.mean_TV.median()),
          'hierarchical_bootstrap_mean_TV_CI025':float(np.nanpercentile(t,2.5)),'hierarchical_bootstrap_mean_TV_CI975':float(np.nanpercentile(t,97.5)),
          'PPC_excess_deviance_fraction_equal_coverage':float(c.blocks_exceed_parent_PPC95_fraction.mean())})
    # 25-km spatial leakage diagnostic is appended with its own label after its computation.
    return pd.DataFrame(rows)

def make_figures(scores25:pd.DataFrame,matrix:pd.DataFrame,summary25:pd.DataFrame):
    plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
    order=summary25.sort_values('mean_delta_LL_per_RTS').coverage_id.tolist()
    sm=summary25.set_index('coverage_id').loc[order].reset_index()
    y=np.arange(len(sm))
    fig,ax=plt.subplots(figsize=(7.5,5.4))
    err=np.vstack([sm.mean_delta_LL_per_RTS-sm.block_bootstrap_mean_delta_LL_per_RTS_CI025,sm.block_bootstrap_mean_delta_LL_per_RTS_CI975-sm.mean_delta_LL_per_RTS])
    colors=np.where(sm.mean_delta_LL_per_RTS>=0,'#4E7890','#C47F5A')
    for i in range(len(sm)):
        ax.errorbar(sm.mean_delta_LL_per_RTS.iloc[i],y[i],xerr=err[:,i:i+1],fmt='o',color=colors[i],ecolor='#77838B',elinewidth=1.2,capsize=2,markersize=5)
    ax.axvline(0,color='#555555',lw=1,ls='--'); ax.set_yticks(y,sm.coverage_id.str.replace('DARTS2023_','',regex=False)); ax.set_xlabel('Mean held-out Δ log score per RTS (parent − area-only)'); ax.set_title('A  Broad association transfer by coverage (25 km)')
    fig.tight_layout(); fig.savefig(OUT/'FIGURE_A_TRANSFER_BY_COVERAGE.png',dpi=300); plt.close(fig)

    tv=scores25[(scores25.block_N_RTS>0)&scores25.TV_parent.notna()]
    fig,ax=plt.subplots(figsize=(8,4.7)); datas=[tv.loc[tv.coverage_id.eq(c),'TV_parent'].to_numpy() for c in order]
    ax.boxplot(datas,tick_labels=[c.replace('DARTS2023_','') for c in order],showfliers=False,patch_artist=True,boxprops={'facecolor':'#AFC0C8','edgecolor':'#58717D'},medianprops={'color':'#263F4A','linewidth':1.4},whiskerprops={'color':'#58717D'},capprops={'color':'#58717D'})
    ax.set_ylabel('Total-variation distance from parent prediction'); ax.set_title('B  Local composition error among blocks with mapped RTS'); ax.tick_params(axis='x',rotation=45); fig.tight_layout(); fig.savefig(OUT/'FIGURE_B_LOCAL_TV_DISTRIBUTION.png',dpi=300); plt.close(fig)

    cats=MODELED_CATEGORIES; covs=sorted(scores25.coverage_id.unique())
    obs=np.zeros((len(covs),len(cats))); pred=np.zeros_like(obs)
    for i,cov in enumerate(covs):
        mm=matrix[(matrix.scale_km==25)&(matrix.coverage_id==cov)]
        obs[i]=[mm[mm.community.eq(cat)].RTS_N_local.sum() for cat in cats]
        pred[i]=[mm[mm.community.eq(cat)].expected_parent_RTS_N.sum() for cat in cats]
    obs_counts=obs.copy(); pred_counts=pred.copy()
    obs_smooth=(obs_counts+0.5)/(obs_counts.sum(axis=1,keepdims=True)+0.5*len(cats))
    pred_smooth=(pred_counts+0.5)/(pred_counts.sum(axis=1,keepdims=True)+0.5*len(cats))
    resid=np.log(obs_smooth/pred_smooth)
    obs_share=obs_counts/obs_counts.sum(axis=1,keepdims=True)
    pred_share=pred_counts/pred_counts.sum(axis=1,keepdims=True)
    lim=float(np.nanpercentile(np.abs(resid),98))
    fig=plt.figure(figsize=(14,5.8),layout='constrained')
    gs=fig.add_gridspec(1,5,width_ratios=[1.12,1.12,.055,1.12,.055])
    ax0=fig.add_subplot(gs[0,0]); ax1=fig.add_subplot(gs[0,1]); cax1=fig.add_subplot(gs[0,2]); ax2=fig.add_subplot(gs[0,3]); cax2=fig.add_subplot(gs[0,4])
    axs=[ax0,ax1,ax2]; titles=['Observed RTS composition','Parent-predicted composition','Jeffreys-smoothed log share ratio']
    vmax=max(float(np.nanmax(obs_share)),float(np.nanmax(pred_share)))
    im0=ax0.imshow(obs_share,aspect='auto',cmap='Blues',vmin=0,vmax=vmax)
    im1=ax1.imshow(pred_share,aspect='auto',cmap='Blues',vmin=0,vmax=vmax)
    cmap=plt.get_cmap('coolwarm').copy(); cmap.set_bad('#E5E5E5')
    im2=ax2.imshow(resid,aspect='auto',cmap=cmap,vmin=-lim,vmax=lim)
    for j,(ax,title) in enumerate(zip(axs,titles)):
        ax.set_title(title,pad=9)
        ax.set_xticks(range(len(cats)),[x.replace('_','\n') for x in cats],fontsize=8)
        ax.set_yticks(range(len(covs)))
        if j==0: ax.set_yticklabels([x.replace('DARTS2023_','') for x in covs],fontsize=8)
        else: ax.set_yticklabels([]); ax.tick_params(axis='y',length=0)
        ax.set_xlabel('Vegetation class')
    ax0.set_ylabel('DARTS coverage')
    fig.colorbar(im0,cax=cax1,label='Share')
    fig.colorbar(im2,cax=cax2,label='Log ratio')
    fig.suptitle('C  Coverage-level composition and residuals (25 km)',fontsize=13)
    fig.savefig(OUT/'FIGURE_C_COMPOSITION_RESIDUAL_HEATMAP.png',dpi=300,bbox_inches='tight'); plt.close(fig)

    # Figure D is populated after post-hoc case-support audit; primary distribution remains all blocks.
    fig,ax=plt.subplots(figsize=(8.2,4.9))
    blocks=scores25[(scores25.block_N_RTS>0)&scores25.delta_LL_per_RTS.notna()]
    for cov,g in blocks.groupby('coverage_id',sort=True):
        ax.scatter(g.delta_LL_per_RTS,g.TV_parent,s=12,alpha=.26,color='#7995A2',edgecolor='none')
    ax.axvline(0,color='#555555',lw=1,ls='--'); ax.set_xlabel('Δ log score per RTS (parent − area-only)'); ax.set_ylabel('Local total-variation error'); ax.set_title('D  Local-block transfer performance; named cases assessed post hoc')
    ax.text(.02,.02,'Named local windows are overlaid only if their 25 km support matches the frozen grid; otherwise shown as not directly comparable.',transform=ax.transAxes,fontsize=7,color='#555555')
    fig.tight_layout(); fig.savefig(OUT/'FIGURE_D_CASES_IN_LOCAL_DISTRIBUTION.png',dpi=300); plt.close(fig)

def temperature_secondary(scores25:pd.DataFrame,matrix25:pd.DataFrame):
    src=ROUND/'DARTS_THERMAL_MOISTURE_MASTER_V1'/'WITHIN_BETWEEN_ENVIRONMENT_MASTER_V2.csv'
    if not src.exists():
        return pd.DataFrame([{'status':'NOT_RUN_NO_FROZEN_THERMAL_WITHIN_INPUT'}])
    t=pd.read_csv(src,usecols=['coverage_id','block_id','block_size_km','Thermal_within_z'])
    t=t[t.block_size_km.eq(25)].drop_duplicates(['coverage_id','block_id'])
    wide=matrix25.pivot_table(index=['coverage_id','block_id','RTS_N_local_total'],columns='community',values=['RTS_N_local','background_area_km2_local','expected_parent_RTS_N'],aggfunc='first')
    wide.columns=['_'.join(c) for c in wide.columns]; wide=wide.reset_index()
    m=wide.merge(t,left_on=['coverage_id','block_id'],right_on=['coverage_id','block_id'],how='left')
    need=['background_area_km2_local_GRASS_HERBACEOUS','background_area_km2_local_MOSS_LICHEN','RTS_N_local_GRASS_HERBACEOUS','RTS_N_local_MOSS_LICHEN','expected_parent_RTS_N_GRASS_HERBACEOUS','expected_parent_RTS_N_MOSS_LICHEN']
    eligible=m.dropna(subset=['Thermal_within_z']).copy()
    eligible=eligible[(eligible[need[0]]>0)&(eligible[need[1]]>0)&(eligible.RTS_N_local_total>0)].copy()
    if len(eligible)<3:
        return pd.DataFrame([{'status':'INSUFFICIENT_SUPPORTED_BLOCKS','eligible_block_n':len(eligible),'criterion':'both grass and moss background >0; RTS_N>0; frozen Thermal_within_z available'}])
    obs=np.log((eligible[need[2]].to_numpy(float)+0.5)/(eligible[need[3]].to_numpy(float)+0.5))
    pred=np.log((eligible[need[4]].to_numpy(float)+0.5)/(eligible[need[5]].to_numpy(float)+0.5))
    eligible['grass_moss_parent_residual_log_odds']=obs-pred
    # Descriptive coverage-demeaned slope; no causal claim and no block-independence p value.
    eligible['x_within_coverage']=eligible.groupby('coverage_id').Thermal_within_z.transform(lambda x:x-x.mean())
    eligible['y_within_coverage']=eligible.groupby('coverage_id').grass_moss_parent_residual_log_odds.transform(lambda x:x-x.mean())
    den=float(np.sum(eligible.x_within_coverage.to_numpy()**2))
    slope=float(np.sum(eligible.x_within_coverage*eligible.y_within_coverage)/den) if den>0 else np.nan
    out=pd.DataFrame([{'status':'DESCRIPTIVE_SECONDARY_ONLY','eligible_block_n':len(eligible),'coverage_n':eligible.coverage_id.nunique(),'slope_residual_log_odds_per_Thermal_within_z':slope,
      'spearman_rho_pooled':eligible[['Thermal_within_z','grass_moss_parent_residual_log_odds']].corr(method='spearman').iloc[0,1],
      'definition':'log((N_grass+0.5)/(N_moss+0.5)) - log((E_parent_grass+0.5)/(E_parent_moss+0.5)); within-coverage centered'}])
    eligible.to_csv(OUT/'SECONDARY_THERMAL_PARENT_RESIDUAL_BLOCKS.csv',index=False)
    return out

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    t0=time.time(); failures=[]
    try:
        params,coverages,inhash=verify_inputs()
    except Exception as e:
        write_failure([{'stage':'input_verification','scale_km':None,'coverage_id':None,'block_id':None,'status':'BLOCKED','details':repr(e)}])
        (OUT/'INPUT_AUDIT.md').write_text('# Input audit\n\nSTATUS: BLOCKED\n\n'+repr(e)+'\n',encoding='utf-8')
        (OUT/'RUN_STATE.md').write_text('ARTIFACT_STATUS: INCOMPLETE\nANALYSIS_STATUS: BLOCKED_INPUT_AUDIT\n',encoding='utf-8')
        print('BLOCKED:',repr(e)); return
    closure=[]; panels={}; exclusions=[]
    for scale in SCALES:
        panel,c,exc=construct_panel(scale,coverages,inhash); panels[scale]=panel; closure.extend(c); exclusions.extend(exc)
        panel.to_csv(OUT/f'RECONSTRUCTED_BLOCK_PANEL_{scale}KM.csv',index=False)
    cl=pd.DataFrame(closure); cl.to_csv(OUT/'INPUT_TABLE_CLOSURE.csv',index=False)
    elig=verify_frozen_eligibility(panels[25]); elig.to_csv(OUT/'FROZEN_CATEGORY_ELIGIBILITY_CLOSURE.csv',index=False)
    if (cl.status!='PASS').any() or (elig.status!='PASS').any():
        bad=cl[cl.status.ne('PASS')]
        (OUT/'INPUT_AUDIT.md').write_text('# Input audit\n\nSTATUS: BLOCKED\n\nFrozen assignments/backgrounds did not reproduce the formal block tables and eligibility. See `INPUT_TABLE_CLOSURE.csv` and `FROZEN_CATEGORY_ELIGIBILITY_CLOSURE.csv`.\n\n'+bad.to_string(index=False)+'\n',encoding='utf-8')
        write_failure([{'stage':'table_closure','scale_km':int(r.scale_km),'coverage_id':r.coverage_id,'block_id':None,'status':'BLOCKED','details':str(r.to_dict())} for r in bad.itertuples()])
        (OUT/'RUN_STATE.md').write_text('ARTIFACT_STATUS: INCOMPLETE\nANALYSIS_STATUS: BLOCKED_INPUT_CLOSURE\n',encoding='utf-8')
        print('BLOCKED: table closure'); return
    audit=['# Input audit','',f'**STATUS: PASS — RAW_13_COVERAGE_REBUILD**','',f'- Source processing state: `{(SRC/"RUN_STATE.md").read_text(encoding="utf-8").splitlines()[0]}`.','- DARTS v1.2 unit-level input rows selected strictly from the manifest-defined tundra coverage set; COV_024 is excluded.','- All manifest-selected raw RTS-assignment/background-grid files passed frozen SHA-256 and byte-size checks.','- No old 14-coverage block table, beta, LOCO, bootstrap, distance matrix, physical model, or aggregate summary was read.','- Complete block panels were rebuilt from unit-level assignments, coordinates, labels, and area weights; source and rebuilt object/background totals are in INPUT_TABLE_CLOSURE.csv.','- Six modeled vegetation categories are retained; any nonmodeled records remain itemized in the closure table.','- Block assignment follows the source pipeline: EPSG:6933, origin (0,0), floor(coord / scale).','- No transfer score or result was used to alter domain, categories, support, or metrics.']
    (OUT/'INPUT_AUDIT.md').write_text('\n'.join(audit)+'\n',encoding='utf-8')
    failures=[]; score_all=[]; matrix_all=[]; ppc_all=[]; coverage_summaries={}; boot_all={}
    for scale in SCALES:
        print(f'Running leave-one-block-out scale={scale} km ...',flush=True)
        sc,ma,pp=score_panel(panels[scale],scale,neighbor_exclusion=False,run_ppc=True)
        score_all.append(sc); matrix_all.append(ma); ppc_all.append(pp)
        # PPC flag is joined back only to summarize fit diagnostics; no block is dropped.
        sc=sc.merge(pp[['coverage_id','block_id','observed_exceeds_95pct','PPC_status']],on=['coverage_id','block_id'],how='left')
        coverage_summaries[scale]=summarize_coverage(sc,scale)
        boot_all[scale]=hierarchical_bootstrap(sc,scale)
        sc.to_csv(OUT/f'BLOCK_TRANSFER_{scale}KM.csv',index=False)
    scores=pd.concat(score_all,ignore_index=True)
    matrix=pd.concat(matrix_all,ignore_index=True)
    ppc=pd.concat(ppc_all,ignore_index=True)
    scores.to_csv(OUT/'BLOCK_TRANSFER_ALL_SCALES.csv',index=False)
    matrix.to_csv(OUT/'FULL_CATEGORY_PARENT_LOCAL_MATRIX.csv',index=False)
    ppc.to_csv(OUT/'PARAMETRIC_PREDICTIVE_CHECK.csv',index=False)
    for scale in SCALES:
        # Re-attach PPC output for coverage summaries consistently.
        sc=scores[scores.scale_km.eq(scale)].merge(ppc[ppc.scale_km.eq(scale)][['coverage_id','block_id','observed_exceeds_95pct','PPC_status']],on=['coverage_id','block_id'],how='left')
        coverage_summaries[scale]=summarize_coverage(sc,scale)
        coverage_summaries[scale].to_csv(OUT/f'COVERAGE_TRANSFER_SUMMARY_{scale}KM.csv',index=False)
    coverage_summaries[25].to_csv(OUT/'COVERAGE_TRANSFER_SUMMARY_25KM.csv',index=False)
    pd.concat([boot_all[s] for s in SCALES],ignore_index=True).to_csv(OUT/'HIERARCHICAL_BOOTSTRAP_ALL_SCALES.csv',index=False)
    sensitivity=scale_summary(coverage_summaries,boot_all)
    # Pre-specified spatial leakage sensitivity: omit the held-out cell and its 8 neighbors at 25 km.
    print('Running 25 km neighboring-block exclusion sensitivity ...',flush=True)
    neigh,_,_=score_panel(panels[25],25,neighbor_exclusion=True,run_ppc=False)
    neigh.to_csv(OUT/'BLOCK_TRANSFER_25KM_NEIGHBOR_EXCLUDED.csv',index=False)
    neigh_cov=summarize_coverage(neigh,25)
    neigh_cov.to_csv(OUT/'COVERAGE_TRANSFER_25KM_NEIGHBOR_EXCLUDED.csv',index=False)
    vals=neigh_cov.event_weighted_delta_LL_per_RTS.dropna().to_numpy(float)
    sensitivity=pd.concat([sensitivity,pd.DataFrame([{'analysis':'NEIGHBOR_BLOCKS_EXCLUDED','scale_km':25,'coverage_n':neigh_cov.coverage_id.nunique(),
      'blocks_total_n':int(neigh_cov.blocks_total_n.sum()),'blocks_scored_n':int(neigh_cov.blocks_scored_n.sum()),
      'coverage_delta_LL_positive_n':int((vals>0).sum()),'coverage_delta_LL_positive_fraction':float(np.mean(vals>0)) if len(vals) else np.nan,
      'coverage_median_event_weighted_delta_LL_per_RTS':float(np.median(vals)) if len(vals) else np.nan,
      'coverage_min_event_weighted_delta_LL_per_RTS':float(np.min(vals)) if len(vals) else np.nan,
      'coverage_max_event_weighted_delta_LL_per_RTS':float(np.max(vals)) if len(vals) else np.nan,
      'hierarchical_bootstrap_mean_delta_CI025':np.nan,'hierarchical_bootstrap_mean_delta_CI975':np.nan,
      'hierarchical_bootstrap_P_mean_delta_gt_0':np.nan,'coverage_median_mean_TV':float(neigh_cov.mean_TV.median()),
      'hierarchical_bootstrap_mean_TV_CI025':np.nan,'hierarchical_bootstrap_mean_TV_CI975':np.nan,
      'PPC_excess_deviance_fraction_equal_coverage':np.nan}])],ignore_index=True)
    sensitivity.to_csv(OUT/'TRANSFER_SCALE_SENSITIVITY_10_25_50.csv',index=False)
    # Secondary thermal link is run only after all primary scales/bootstrap/PPC files have been frozen.
    # Temperature/moisture branch explicitly excluded from this 13-zone rerun.
    make_figures(scores[scores.scale_km.eq(25)],matrix,coverage_summaries[25])
    # Case mapping is deliberately deferred; write transparent not-comparable placeholders pending post-hoc domain audit.
    pd.DataFrame([
      {'case':'Peel','status':'POST_HOC_SUPPORT_AUDIT_REQUIRED','directly_comparable_to_25km_frozen_grid':False,'note':'No case block assignment was used to fit/select the transfer model.'},
      {'case':'Banks','status':'POST_HOC_SUPPORT_AUDIT_REQUIRED','directly_comparable_to_25km_frozen_grid':False,'note':'Banks local window may use coverage support outside the frozen 14; must be verified before overlay.'},
      {'case':'Novaya','status':'POST_HOC_SUPPORT_AUDIT_REQUIRED','directly_comparable_to_25km_frozen_grid':False,'note':'No case block assignment was used to fit/select the transfer model.'},
    ]).to_csv(OUT/'POST_HOC_CASE_SUPPORT_AUDIT.csv',index=False)
    params_out={'experiment':'RTS_BROAD_TO_LOCAL_TRANSFER_V1','upstream_formal_run':'DARTS_BLOCK_VEGETATION_INTERACTION_V1','coverage_ids':coverages,'scales_km':SCALES,
      'primary_scale_km':25,'modeled_categories':MODELED_CATEGORIES,'frozen_category_eligibility_source':'six fixed modeled categories from the source formal transfer protocol; 13-zone support recomputed from raw unit rows',
      'grid_origin_epsg6933_m':[0,0],'background_assignment':'frozen coverage-intersection-area rows assigned to the same floor(EPSG:6933 centroid / scale) grid as the formal table',
      'LOBO_formula':'R_train=(N_train,c/N_train)/(B_train,c/B_train); p_parent proportional to local B_ic*R_train; local N_i conditioned upon',
      'area_only_formula':'p_area=B_ic/sum_c(B_ic)','primary_score':'Jeffreys-type fixed 0.5 pseudo-count predictive log-score for each local N_i; raw unsmoothed score and zero-probability events retained as diagnostics',
      'smoothing_alpha':ALPHA,'local_error':'TV=0.5*sum|observed_share-parent_probability|','parametric_predictive_check':{'draws_per_block':PPC_N,'fixed_total':'observed local N_i','probability':'unsmoothed p_parent','seed_base':SEED},
      'hierarchical_bootstrap':{'replicates':BOOT_N,'resampling':'coverage with replacement, then scored blocks within each selected coverage with replacement','seed_base':SEED},
      'within_coverage_block_bootstrap_replicates':BLOCK_CI_N,'neighbor_exclusion':'held-out 25 km block and all existing 8-neighbor cells excluded from parent training',
      'temperature_secondary':'Thermal_within_z from frozen WITHIN_BETWEEN_ENVIRONMENT_MASTER_V2; both GRASS and MOSS backgrounds >0; RTS_N>0; descriptive only',
      '10km_reconstruction':'complete category count/background table rebuilt from hash-verified frozen source assignments and background grids; legacy positive-background projection checked against formal table'}
    (OUT/'PARAMETERS.json').write_text(json.dumps(params_out,indent=2),encoding='utf-8')
    # Input manifest includes frozen assignment/background hashes plus every formal input file read.
    manifest=pd.read_csv(OUT/'INPUT_HASH_VERIFICATION.csv').rename(columns={'actual_sha256':'sha256','actual_bytes':'bytes'})
    more=[]
    for p in [SRC/'PARAMETERS.json',ROUND/'RTS_BROAD_TO_LOCAL_TRANSFER_V1'/'code'/'run_transfer.py',ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'/'TUNDRA13_COVERAGE_MANIFEST.json']:
        if p.exists(): more.append({'role':'PROTOCOL_OR_CODE','coverage_id':'ALL','path':str(p),'sha256':digest(p),'bytes':p.stat().st_size,'status':'PASS'})
    manifest=pd.concat([manifest,pd.DataFrame(more)],ignore_index=True,sort=False)
    manifest.to_csv(OUT/'INPUT_HASHES.csv',index=False)
    # Save all output hashes after reports and figures are produced.
    write_failure(failures)
    total_scores=scores[(scores.scale_km.eq(25))&(scores.block_N_RTS.gt(0))&scores.delta_LL.notna()]
    total_ex=ppc[(ppc.scale_km.eq(25))&ppc.block_N_RTS.gt(0)]
    hb=boot_all[25]
    report=['# RTS broad-to-local transfer test','',f'**ARTIFACT_STATUS: COMPLETE**','',
      '## Direct answers','',
      f'1. **Does the broad vegetation association predict local composition better than local area alone?** At 25 km, equal-coverage mean ΔLL/RTS was {coverage_summaries[25].mean_delta_LL_per_RTS.mean():.4f}; {int((coverage_summaries[25].event_weighted_delta_LL_per_RTS>0).sum())}/{len(coverages)} coverages had positive event-weighted ΔLL/RTS. Hierarchical coverage-then-block bootstrap 95% CI: [{hb.equal_coverage_mean_delta_LL_per_RTS.quantile(.025):.4f}, {hb.equal_coverage_mean_delta_LL_per_RTS.quantile(.975):.4f}], P(mean>0)={float((hb.equal_coverage_mean_delta_LL_per_RTS>0).mean()):.3f}.','',
      f'2. **How often is the direction consistent?** {int((coverage_summaries[25].event_weighted_delta_LL_per_RTS>0).sum())}/{len(coverages)} coverage summaries favored the parent association; full coverage results are in `COVERAGE_TRANSFER_SUMMARY_25KM.csv`.','',
      f'3. **How much local deviation remains beyond normal sampling error?** {int(total_ex.observed_exceeds_95pct.sum())}/{len(total_ex)} scored local blocks ({(total_ex.observed_exceeds_95pct.mean()*100 if len(total_ex) else np.nan):.1f}%) exceeded their parent-model 95% parametric sampling range; blocks with structural zero parent probability are explicitly included and flagged.','',
      '4. **Does it depend on scale?** See `TRANSFER_SCALE_SENSITIVITY_10_25_50.csv` for 10/25/50 km, same rules. The 10 km panel was rebuilt from the frozen source because the legacy positive-background table omitted a small set of zero-background class counts; no coverage, category, or threshold changed.','',
      '5. **Are Peel/Banks/Novaya representative or exceptional?** They were not used to fit or select the parent model. Their direct placement is reported only where their local windows can be mapped to the same frozen grid and category support; `POST_HOC_CASE_SUPPORT_AUDIT.csv` records comparability.','',
      '6. **What claim is supported?** The conclusion is written from the transfer scores below: a broad association is transferable only to the extent supported by held-out prediction against the area-only baseline; residual local deviations are reported separately. This is a composition-prediction statement conditional on observed RTS counts, not an RTS total-risk or causal claim.','',
      '## 25 km coverage summaries','',
      '|Coverage|Blocks scored|RTS|Event-weighted ΔLL/RTS|Mean TV|Parent PPC excess|','|---|---:|---:|---:|---:|---:|']
    for r in coverage_summaries[25].itertuples(index=False):
        report.append(f'|{r.coverage_id}|{r.blocks_scored_n}|{r.RTS_total_n}|{r.event_weighted_delta_LL_per_RTS:.4f}|{r.mean_TV:.3f}|{r.blocks_exceed_parent_PPC95_fraction:.3f}|')
    report+=['','## Interpretation and limits','',
      '- The held-out target is category composition conditional on each block’s observed RTS total. The model does not predict how many RTS occur in a block.','- `ΔLL > 0` means the coverage-wide parent association adds predictive information over local background area alone; this alone does not imply that it explains all local structure.','- `TV` is a block-level descriptive composition error. PPC excess-deviance flags local compositions outside the parent model’s own multinomial sampling range.','- The 0.5 pseudo-count is fixed for log scoring only; unsmoothed scores and events assigned zero parent probability are retained in the block table. The raw-versus-smoothed dependence must be read from those columns.','- The coverage is the cross-landscape inference unit. Blocks are nested observations; uncertainty uses coverage resampling followed by within-coverage block resampling.','- Neighbor exclusion removes the held-out block plus its eight grid neighbors from parent training, as a spatial leakage sensitivity.','- `Thermal_within` is a secondary descriptive association with parent-model residuals and cannot alter the primary conclusion.','- Case windows are post-hoc interpretation only; any nonmatching block geometry or support is flagged rather than forced into a percentile.','',f'Wall time: {(time.time()-t0)/60:.1f} minutes.','']
    (OUT/'FINAL_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    (OUT/'RUN_STATE.md').write_text('ARTIFACT_STATUS: COMPLETE\nANALYSIS_STATUS: BROAD_TO_LOCAL_COMPOSITION_TRANSFER\nPRIMARY_SCALE_KM: 25\nSENSITIVITY_SCALES_KM: 10,25,50\nUPSTREAM_MODIFIED: NO\nCOVERAGE_SET_MODIFIED: NO\nCATEGORY_SUPPORT_MODIFIED: NO\n',encoding='utf-8')
    hashes=[]
    for f in sorted(OUT.rglob('*')):
        if f.is_file() and f.name not in ('OUTPUT_HASHES.csv','OUTPUT_HASHES.json'):
            hashes.append({'path':str(f),'sha256':digest(f),'bytes':f.stat().st_size})
    pd.DataFrame(hashes).to_csv(OUT/'OUTPUT_HASHES.csv',index=False)
    print('COMPLETE')
    print('25km equal-coverage mean DeltaLL/RTS',coverage_summaries[25].mean_delta_LL_per_RTS.mean())
    print('25km positive coverage count',int((coverage_summaries[25].event_weighted_delta_LL_per_RTS>0).sum()),f'/{len(coverages)}')
    print('25km PPC excess',int(total_ex.observed_exceeds_95pct.sum()),'/',len(total_ex))
    print('25km hierarchical CI',hb.equal_coverage_mean_delta_LL_per_RTS.quantile(.025),hb.equal_coverage_mean_delta_LL_per_RTS.quantile(.975))
    print('Output dir',OUT)

if __name__=='__main__': main()
