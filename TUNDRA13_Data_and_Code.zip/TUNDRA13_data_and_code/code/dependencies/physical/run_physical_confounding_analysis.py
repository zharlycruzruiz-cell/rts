from __future__ import annotations
import hashlib, json, math, os, platform, subprocess, sys, time, traceback
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.optimize import minimize
from scipy.special import gammaln, logsumexp
from scipy.stats import chi2
from scipy.sparse import csr_matrix
from scipy.linalg import qr

ROOT = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01")
OUT = ROOT / "RTS_TUNDRA13_FULL_REANALYSIS_V1" / "physical"
PHYS = ROOT / "PHYSICAL_CONFOUNDING_SENSITIVITY_V1"
DATA = ROOT / "DARTS16_WORLDCOVER_PRODUCT_SENSITIVITY_V1" / "worldcover_unit_cache"
GLO = PHYS / "COPERNICUS_GLO30_PIXEL_SLOPE_SUPPORT_V1" / "physical_attributes"
ICE = PHYS / "V2_TECHNICAL_REVISION" / "physical_attributes_exact_overlap_v2"
ARCTIC = PHYS / "V2_TECHNICAL_REVISION" / "data_processed" / "ArcticDEM_v4.1_32m_CROPS"
CLASSES = ["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE", "OTHER"]
MODEL_CLASSES = ["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE"]
GRASS = "GRASS_HERBACEOUS"
SCALES = [10, 25, 50]
NBOOT_RCOUNT = 1000
RCOUNT_SEED = 20263422
NBOOT_EFFECT = 5000
EFFECT_SEED = 20260930
NBOOT_TRANSFER = 5000
TRANSFER_SEED = 20260929
TRANSFER_ALPHA = 0.5
RTS_EXCLUDED = {"DARTS2023_COV_028": {"75739", "75836", "75837"}}
TARGET = json.loads((ROOT / "RTS_TUNDRA13_FULL_REANALYSIS_V1" / "TUNDRA13_COVERAGE_MANIFEST.json").read_text(encoding="utf-8"))["coverage_ids"]
ARCTIC_PASS = ["DARTS2023_COV_001", "DARTS2023_COV_003", "DARTS2023_COV_014", "DARTS2023_COV_019", "DARTS2023_COV_021", "DARTS2023_COV_033"]
TR = Transformer.from_crs(4326, 6933, always_xy=True)

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def csv_read(path: Path, usecols=None):
    return pd.read_csv(path, usecols=usecols, low_memory=False)

def safe_ratio(a,b):
    if not np.isfinite(a) or not np.isfinite(b) or b <= 0: return np.nan
    return float(a/b)

def extended_mean(vals):
    x=np.asarray(vals,dtype=float); x=x[~np.isnan(x)]
    if len(x)==0: return np.nan
    pos=np.isposinf(x).any(); neg=np.isneginf(x).any()
    if pos and neg: return np.nan
    if pos: return np.inf
    if neg: return -np.inf
    return float(x.mean())

def extended_quantile(vals, q):
    x=np.asarray(vals,dtype=float); x=x[~np.isnan(x)]
    if len(x)==0: return np.nan
    return float(np.quantile(x,q,method="inverted_cdf"))

def read_cov(uid: str):
    rpath=DATA/f"{uid}_RTS_ASSIGNMENTS.csv"
    bpath=DATA/f"{uid}_BACKGROUND_GRID.csv"
    r=csv_read(rpath, ["rts_id","centroid_lon","centroid_lat","cgls_community"])
    b=csv_read(bpath, ["grid_id","center_lon","center_lat","coverage_intersection_area_m2","community"])
    r=r.rename(columns={"cgls_community":"community"})
    r["rts_id"]=r.rts_id.astype(str)
    b["grid_id"]=b.grid_id.astype(str)
    if r.rts_id.duplicated().any() or b.grid_id.duplicated().any():
        raise RuntimeError(f"duplicate sample IDs in frozen CGLS input: {uid}")
    r=r[r.community.isin(CLASSES)].copy()
    b=b[b.community.isin(CLASSES)].copy()
    b["coverage_intersection_area_m2"]=pd.to_numeric(b.coverage_intersection_area_m2,errors="coerce")
    b=b[np.isfinite(b.coverage_intersection_area_m2)&(b.coverage_intersection_area_m2>0)].copy()
    if r[["centroid_lon","centroid_lat"]].isna().any().any() or b[["center_lon","center_lat"]].isna().any().any():
        raise RuntimeError(f"missing coordinates for spatial block assignment: {uid}")
    for d,lon,lat in [(r,"centroid_lon","centroid_lat"),(b,"center_lon","center_lat")]:
        xx,yy=TR.transform(d[lon].to_numpy(float),d[lat].to_numpy(float),errcheck=True)
        d["x6933"]=np.asarray(xx,dtype=float); d["y6933"]=np.asarray(yy,dtype=float)
        for sc in SCALES:
            d[f"block_{sc}"]=np.floor(d.x6933/(sc*1000)).astype(np.int64).astype(str)+"_"+np.floor(d.y6933/(sc*1000)).astype(np.int64).astype(str)
    return r,b,rpath,bpath

def add_glo(uid,r,b):
    code=uid.split("_")[-1]
    rp=GLO/f"COV_{code}_RTS_GLO30_SLOPE_RING.csv.gz"
    bp=GLO/f"COV_{code}_BACKGROUND_GLO30_SLOPE_RING.csv.gz"
    rs=csv_read(rp,["rts_id","slope_valid_pixel_n","slope_valid_fraction","slope_mean_deg","slope_median_deg"])
    bs=csv_read(bp,["grid_id","slope_valid_pixel_n","slope_valid_fraction","slope_mean_deg","slope_median_deg"])
    rs.rts_id=rs.rts_id.astype(str); bs.grid_id=bs.grid_id.astype(str)
    if rs.rts_id.duplicated().any() or bs.grid_id.duplicated().any(): raise RuntimeError(f"duplicate GLO-30 IDs {uid}")
    missing_r=set(r.rts_id)-set(rs.rts_id); missing_b=set(b.grid_id)-set(bs.grid_id)
    if missing_r or missing_b: raise RuntimeError(f"GLO-30 physical attributes missing analysis IDs {uid}: RTS={len(missing_r)}, BG={len(missing_b)}")
    extra_r=len(set(rs.rts_id)-set(r.rts_id)); extra_b=len(set(bs.grid_id)-set(b.grid_id))
    r=r.merge(rs,on="rts_id",how="left",validate="one_to_one")
    b=b.merge(bs,on="grid_id",how="left",validate="one_to_one")
    r.attrs["physical_attribute_extra_id_n"]=extra_r; b.attrs["physical_attribute_extra_id_n"]=extra_b
    return r,b,rp,bp

def add_ice(uid,r,b,branch):
    adir=ICE/uid
    rp=adir/f"{uid}_RTS_EXACT_OVERLAP_PHYSICAL_ATTRIBUTES.csv.gz"
    bp=adir/f"{uid}_BG_EXACT_OVERLAP_PHYSICAL_ATTRIBUTES.csv.gz"
    mean=f"{branch}_VIC_area_weighted_mean_raw"; valid=f"{branch}_valid_overlap_area_m2"; fraction=f"{branch}_valid_fraction"; eligible="eligible_overlap_area_m2"
    rs=csv_read(rp,["rts_id",mean,valid,fraction,eligible]); bs=csv_read(bp,["grid_id",mean,valid,fraction,eligible])
    rs.rts_id=rs.rts_id.astype(str); bs.grid_id=bs.grid_id.astype(str)
    if rs.rts_id.duplicated().any() or bs.grid_id.duplicated().any(): raise RuntimeError(f"duplicate exact-VIC IDs {uid} {branch}")
    missing_r=set(r.rts_id)-set(rs.rts_id); missing_b=set(b.grid_id)-set(bs.grid_id)
    if missing_r or missing_b: raise RuntimeError(f"exact-VIC physical attributes missing analysis IDs {uid} {branch}: RTS={len(missing_r)}, BG={len(missing_b)}")
    extra_r=len(set(rs.rts_id)-set(r.rts_id)); extra_b=len(set(bs.grid_id)-set(b.grid_id))
    rs=rs.rename(columns={mean:"vic_mean",valid:"vic_valid_area_m2",fraction:"vic_valid_fraction",eligible:"vic_eligible_area_m2"})
    bs=bs.rename(columns={mean:"vic_mean",valid:"vic_valid_area_m2",fraction:"vic_valid_fraction",eligible:"vic_eligible_area_m2"})
    r=r.merge(rs,on="rts_id",how="left",validate="one_to_one")
    b=b.merge(bs,on="grid_id",how="left",validate="one_to_one")
    r.attrs["physical_attribute_extra_id_n"]=extra_r; b.attrs["physical_attribute_extra_id_n"]=extra_b
    return r,b,rp,bp

def valid_slope_r(r):
    return (pd.to_numeric(r.slope_valid_fraction,errors="coerce")>=0.95)&np.isfinite(pd.to_numeric(r.slope_median_deg,errors="coerce"))

def valid_slope_b(b):
    return (pd.to_numeric(b.slope_valid_pixel_n,errors="coerce")>0)&np.isfinite(pd.to_numeric(b.slope_median_deg,errors="coerce"))

def valid_ice(d):
    return np.isfinite(pd.to_numeric(d.vic_mean,errors="coerce"))&(pd.to_numeric(d.vic_valid_area_m2,errors="coerce")>0)&(pd.to_numeric(d.vic_eligible_area_m2,errors="coerce")>0)

def make_terciles(bg, value_col):
    x=pd.to_numeric(bg[value_col],errors="coerce").to_numpy(float)
    x=x[np.isfinite(x)]
    if len(x)<20: return None,"DEGENERATE_OR_LOW_SUPPORT",np.nan,np.nan
    q1,q2=np.quantile(x,[1/3,2/3],method="linear")
    if not np.isfinite(q1+q2) or q1>=q2: return None,"DEGENERATE_OR_LOW_SUPPORT",float(q1),float(q2)
    return (float(q1),float(q2)),"PASS",float(q1),float(q2)

def label_tercile(df,value_col,prefix,cut):
    if cut is None: return None
    q1,q2=cut; x=pd.to_numeric(df[value_col],errors="coerce").to_numpy(float)
    labels=np.where(x<=q1,f"{prefix}_LOW",np.where(x<=q2,f"{prefix}_MID",f"{prefix}_HIGH"))
    labels[~np.isfinite(x)]=""
    return pd.Series(labels,index=df.index,dtype="object")

def attach_strata(r,b,mode,uid,threshold_rows,branch=""):
    """Returns copied tables carrying a frozen physical stratum; None means this coverage is non-estimable for the adjusted stage."""
    if mode=="ALL":
        r=r.copy(); b=b.copy(); r["physical_stratum"]="ALL"; b["physical_stratum"]="ALL"
        return r,b,"PASS"
    slope_cut,ss,q1s,q2s=make_terciles(b,"slope_median_deg")
    threshold_rows.append(dict(coverage_id=uid,scenario=mode,branch=branch,variable="slope",q33=q1s,q67=q2s,valid_bg_n=int(np.isfinite(pd.to_numeric(b.slope_median_deg,errors="coerce")).sum()),status=ss))
    if slope_cut is None:
        r=r.copy(); b=b.copy(); r["physical_stratum"]="SLOPE_DEGENERATE_OR_LOW_SUPPORT"; b["physical_stratum"]="SLOPE_DEGENERATE_OR_LOW_SUPPORT"
        if mode=="SLOPE": return r,b,"DEGENERATE_OR_LOW_SUPPORT_NO_SLOPE_ADJUSTMENT"
        # For the joint stage, a valid VIC dimension can still be stratified;
        # the slope dimension remains explicitly degenerate and is not binned.
        ice_cut,is_,q1i,q2i=make_terciles(b,"vic_mean")
        threshold_rows.append(dict(coverage_id=uid,scenario=mode,branch=branch,variable="ground_ice",q33=q1i,q67=q2i,valid_bg_n=int(np.isfinite(pd.to_numeric(b.vic_mean,errors="coerce")).sum()),status=is_))
        if ice_cut is not None:
            r["vic_bin"]=label_tercile(r,"vic_mean","VIC",ice_cut); b["vic_bin"]=label_tercile(b,"vic_mean","VIC",ice_cut)
            r["physical_stratum"]="SLOPE_DEGENERATE|"+r.vic_bin.astype(str); b["physical_stratum"]="SLOPE_DEGENERATE|"+b.vic_bin.astype(str)
            return r,b,"PARTIAL_STRATA_SLOPE_DEGENERATE"
        return r,b,"DEGENERATE_OR_LOW_SUPPORT_NO_JOINT_ADJUSTMENT"
    r=r.copy(); b=b.copy(); r["slope_bin"]=label_tercile(r,"slope_median_deg","SLOPE",slope_cut); b["slope_bin"]=label_tercile(b,"slope_median_deg","SLOPE",slope_cut)
    if mode in ("SLOPE","SLOPE_VIC"):
        if mode=="SLOPE": r["physical_stratum"]=r.slope_bin; b["physical_stratum"]=b.slope_bin
        else:
            ice_cut,is_,q1i,q2i=make_terciles(b,"vic_mean")
            threshold_rows.append(dict(coverage_id=uid,scenario=mode,branch=branch,variable="ground_ice",q33=q1i,q67=q2i,valid_bg_n=int(np.isfinite(pd.to_numeric(b.vic_mean,errors="coerce")).sum()),status=is_))
            if ice_cut is None:
                r["physical_stratum"]=r.slope_bin.astype(str)+"|VIC_DEGENERATE_OR_LOW_SUPPORT"; b["physical_stratum"]=b.slope_bin.astype(str)+"|VIC_DEGENERATE_OR_LOW_SUPPORT"
                return r,b,"PARTIAL_STRATA_VIC_DEGENERATE"
            r["vic_bin"]=label_tercile(r,"vic_mean","VIC",ice_cut); b["vic_bin"]=label_tercile(b,"vic_mean","VIC",ice_cut)
            r["physical_stratum"]=r.slope_bin.astype(str)+"|"+r.vic_bin.astype(str)
            b["physical_stratum"]=b.slope_bin.astype(str)+"|"+b.vic_bin.astype(str)
    else: raise ValueError(mode)
    if r.physical_stratum.isna().any() or b.physical_stratum.isna().any() or (r.physical_stratum=="").any() or (b.physical_stratum=="").any():
        return None,None,"MISSING_PHYSICAL_VALUE_AFTER_COMMON_SUPPORT"
    return r,b,"PASS"

def direct_and_stratified_rcount(r,b,adjusted):
    strata=sorted(set(r.physical_stratum.astype(str))|set(b.physical_stratum.astype(str)))
    nmat=np.zeros((len(strata),len(CLASSES)),dtype=float); amat=np.zeros_like(nmat)
    sidx={s:i for i,s in enumerate(strata)}; cidx={c:i for i,c in enumerate(CLASSES)}
    for (s,c),g in r.groupby(["physical_stratum","community"],sort=False): nmat[sidx[str(s)],cidx[str(c)]]=len(g)
    for (s,c),g in b.groupby(["physical_stratum","community"],sort=False): amat[sidx[str(s)],cidx[str(c)]]=float(g.coverage_intersection_area_m2.sum())
    return point_from_matrices(nmat,amat,adjusted),nmat,amat,strata

def point_from_matrices(nmat,amat,adjusted):
    nmat=np.asarray(nmat,float); amat=np.asarray(amat,float)
    nt=nmat.sum(axis=1); bt=amat.sum(axis=1)
    out={}
    if not adjusted:
        N=float(nt.sum()); B=float(bt.sum())
        for j,c in enumerate(CLASSES):
            out[c]={"R_count":safe_ratio(safe_ratio(nmat[:,j].sum(),N),safe_ratio(amat[:,j].sum(),B)),"RTS_n":int(round(nmat[:,j].sum())),"background_area_m2":float(amat[:,j].sum()),"strata_n_used":1 if N>0 and B>0 else 0,"background_area_used_m2":B,"background_area_omitted_m2":0.0}
        return out
    for j,c in enumerate(CLASSES):
        ok=(nt>0)&(bt>0)&(amat[:,j]>0)
        rs=np.full(len(nt),np.nan); rs[ok]=(nmat[ok,j]/nt[ok])/(amat[ok,j]/bt[ok])
        w=np.where(ok,bt,0.0); denom=float(w.sum())
        val=float(np.sum(np.where(ok,rs*w,0.0))/denom) if denom>0 else np.nan
        out[c]={"R_count":val,"RTS_n":int(round(nmat[:,j].sum())),"background_area_m2":float(amat[:,j].sum()),"strata_n_used":int(ok.sum()),"background_area_used_m2":denom,"background_area_omitted_m2":float(bt.sum()-denom)}
    return out

def stratum_table(uid,scenario,branch,r,b,adjusted):
    p,_,_,_=direct_and_stratified_rcount(r,b,adjusted)
    rows=[]
    for s in sorted(set(r.physical_stratum.astype(str))|set(b.physical_stratum.astype(str))):
        rr=r[r.physical_stratum.astype(str).eq(s)]; bb=b[b.physical_stratum.astype(str).eq(s)]
        n_total=len(rr); bg_total=float(bb.coverage_intersection_area_m2.sum()); bg_n=bb.grid_id.nunique()
        for c in CLASSES:
            n=int((rr.community==c).sum()); area=float(bb.loc[bb.community==c,"coverage_intersection_area_m2"].sum())
            rc=(n/n_total)/(area/bg_total) if n_total>0 and bg_total>0 and area>0 else np.nan
            flag="SUPPORTED" if n>=20 and area>0 else ("LOW_SUPPORT" if n<20 and area>0 else ("NOT_ESTIMABLE_NO_BACKGROUND" if area<=0 else "LOW_SUPPORT"))
            rows.append(dict(coverage_id=uid,scenario=scenario,groundice_branch=branch,physical_stratum=s,vegetation_class=c,RTS_n=n,RTS_total_stratum=n_total,background_grid_n=bg_n,background_area_m2=area,background_total_stratum_m2=bg_total,R_count_stratum=rc,stratum_support="LOW_SUPPORT" if n_total<20 or bg_n<20 else "SUPPORTED",category_support=flag))
    return rows

def block_tensors(r,b,blocks,adjusted):
    strata=sorted(set(r.physical_stratum.astype(str))|set(b.physical_stratum.astype(str)))
    bi={v:i for i,v in enumerate(blocks)}; si={v:i for i,v in enumerate(strata)}; ci={v:i for i,v in enumerate(CLASSES)}
    C=np.zeros((len(blocks),len(strata),len(CLASSES)),dtype=np.float64)
    A=np.zeros_like(C)
    if len(r):
        q=r.groupby(["block_25","physical_stratum","community"],sort=False).size()
        for (bid,s,c),v in q.items(): C[bi[str(bid)],si[str(s)],ci[str(c)]]=float(v)
    if len(b):
        q=b.groupby(["block_25","physical_stratum","community"],sort=False).coverage_intersection_area_m2.sum()
        for (bid,s,c),v in q.items(): A[bi[str(bid)],si[str(s)],ci[str(c)]]=float(v)
    return C.reshape(len(blocks),-1),A.reshape(len(blocks),-1),strata

def bootstrap_rcount(r,b,blocks,W,adjusted):
    C,A,strata=block_tensors(r,b,blocks,adjusted)
    BC=W@C; BA=W@A; arr=np.full((W.shape[0],len(CLASSES)),np.nan)
    ns=len(strata)
    for k in range(W.shape[0]):
        nm=BC[k].reshape(ns,len(CLASSES)); am=BA[k].reshape(ns,len(CLASSES))
        d=point_from_matrices(nm,am,adjusted)
        arr[k]=[d[c]["R_count"] for c in CLASSES]
    return arr

def scenario_rcount_rows(uid,scenario,branch,r,b,adjusted,boots,baseline_rts_n,baseline_bg_n,baseline_bg_area):
    point,_,_,_=direct_and_stratified_rcount(r,b,adjusted)
    rows=[]; current_n=len(r); current_bg_n=int(b.grid_id.nunique()); current_area=float(b.coverage_intersection_area_m2.sum())
    for c in CLASSES:
        d=point[c]; v=boots[:,CLASSES.index(c)]; finite=v[np.isfinite(v)]
        rows.append(dict(coverage_id=uid,scenario=scenario,groundice_branch=branch or "NA",vegetation_class=c,RTS_n=d["RTS_n"],RTS_total=current_n,RTS_fraction=(d["RTS_n"]/current_n if current_n else np.nan),background_area_m2=d["background_area_m2"],background_fraction=(d["background_area_m2"]/current_area if current_area else np.nan),R_count=d["R_count"],CI95_low=float(np.quantile(finite,.025)) if len(finite) else np.nan,CI95_high=float(np.quantile(finite,.975)) if len(finite) else np.nan,bootstrap_replicates=NBOOT_RCOUNT,bootstrap_finite_n=len(finite),bootstrap_fraction_R_count_gt1=float(np.mean(finite>1)) if len(finite) else np.nan,physical_strata_n_used=d["strata_n_used"],background_area_used_m2=d["background_area_used_m2"],background_area_omitted_m2=d["background_area_omitted_m2"],retained_RTS_fraction=(current_n/baseline_rts_n if baseline_rts_n else np.nan),retained_BG_grid_fraction=(current_bg_n/baseline_bg_n if baseline_bg_n else np.nan),retained_BG_area_fraction=(current_area/baseline_bg_area if baseline_bg_area else np.nan),category_support="ZERO_COUNT" if d["RTS_n"]==0 else ("LOW_SUPPORT" if d["RTS_n"]<20 else ("NO_BACKGROUND" if d["background_area_m2"]<=0 else "SUPPORTED"))))
    return rows

def aggregate_cells(r,b,scale=25):
    bc=f"block_{scale}"
    rc=(r.groupby([bc,"physical_stratum","community"],sort=False).size().rename("RTS_n").reset_index().rename(columns={bc:"block_id","community":"vegetation_class"}))
    ba=(b.groupby([bc,"physical_stratum","community"],sort=False).coverage_intersection_area_m2.sum().rename("background_area_m2").reset_index().rename(columns={bc:"block_id","community":"vegetation_class"}))
    z=rc.merge(ba,on=["block_id","physical_stratum","vegetation_class"],how="outer",validate="one_to_one")
    z.RTS_n=z.RTS_n.fillna(0).astype(int); z.background_area_m2=z.background_area_m2.fillna(0.0).astype(float)
    z["coverage_id"]=r.coverage_id.iloc[0] if len(r) else (b.coverage_unit_id.iloc[0] if "coverage_unit_id" in b else "")
    return z[["coverage_id","block_id","physical_stratum","vegetation_class","RTS_n","background_area_m2"]]

def fit_conditional(cells, include_phys, include_coverage, start_coefficients=None):
    """Frozen block-conditional composition likelihood; area is a category exposure offset."""
    d=cells[cells.vegetation_class.isin(MODEL_CLASSES)].copy()
    # Match the established DARTS block-interaction likelihood: category rows
    # with no local background exposure are outside the conditional likelihood
    # support. Keep the category in the global model and report these unsupported
    # block/stratum counts; do not fail the entire pooled model or add exposure.
    group_cols=["coverage_id","block_id","physical_stratum","vegetation_class"]
    all_counts=cells[cells.vegetation_class.isin(MODEL_CLASSES)].groupby(group_cols).RTS_n.sum()
    all_area=cells[cells.vegetation_class.isin(MODEL_CLASSES)].groupby(group_cols).background_area_m2.sum()
    unsupported=[(k,float(v)) for k,v in all_counts.items() if v>0 and float(all_area.get(k,0.0))<=0]
    unsupported_cell_n=len(unsupported)
    unsupported_rts_n=int(round(sum(v for _,v in unsupported)))
    d=d[d.background_area_m2>0].copy()
    if len(d)==0: return {"status":"MODEL_FAILED","reason":"NO_POSITIVE_BACKGROUND_ROWS"}
    d=d.sort_values(["coverage_id","block_id","physical_stratum","vegetation_class"]).reset_index(drop=True)
    group_keys=list(zip(d.coverage_id.astype(str),d.block_id.astype(str),d.physical_stratum.astype(str)))
    gid,_=pd.factorize(pd.MultiIndex.from_tuples(group_keys),sort=True); n_group=int(gid.max()+1)
    group_total=np.bincount(gid,weights=d.RTS_n.to_numpy(float),minlength=n_group)
    use=group_total[gid]>0
    d=d.loc[use].reset_index(drop=True); gid=gid[use]; group_total=group_total
    # Rows include only eligible-category exposure with positive local area; the likelihood conditions on their RTS total.
    cov=d.coverage_id.astype(str).to_numpy(); cat=d.vegetation_class.astype(str).to_numpy(); phys=d.physical_stratum.astype(str).to_numpy()
    covs=sorted(pd.unique(cov)); cats=MODEL_CLASSES; phys_levels=sorted(pd.unique(phys)); base=GRASS
    specs=[]
    for c in cats:
        if c!=base: specs.append((f"vegetation[{c}]",lambda i,c=c:cat[i]==c))
    if include_phys:
        for lev in phys_levels[1:]:
            for c in cats:
                if c!=base: specs.append((f"physical[{lev}]:vegetation[{c}]",lambda i,lev=lev,c=c:(phys[i]==lev)&(cat[i]==c)))
    if include_coverage:
        for co in covs[1:]:
            for c in cats:
                if c!=base: specs.append((f"coverage[{co}]:vegetation[{c}]",lambda i,co=co,c=c:(cov[i]==co)&(cat[i]==c)))
    # Sparse one-hot design.
    rr=[]; cc=[]; data=[]; terms=[]
    for j,(name,pred) in enumerate(specs):
        ix=np.flatnonzero(pred(np.arange(len(d))))
        if len(ix): rr.extend(ix.tolist()); cc.extend([j]*len(ix)); data.extend([1.0]*len(ix)); terms.append(name)
    # Rebuild only populated columns; each specification maps to its original candidate position.
    if len(terms):
        X=csr_matrix((data,(rr,cc)),shape=(len(d),len(specs)),dtype=float)
        populated=np.asarray(X.getnnz(axis=0)>0).ravel(); X=X[:,populated]; terms=[t for t,k in zip([s[0] for s in specs],populated) if k]
    else: X=csr_matrix((len(d),0),dtype=float); terms=[]
    if X.shape[1]:
        gram=(X.T@X).toarray(); q,rmat,piv=qr(gram,pivoting=True,mode="economic"); diag=np.abs(np.diag(rmat)); tol=(diag.max() if len(diag) else 0)*1e-10
        rank=int(np.sum(diag>tol)); keep=np.asarray(piv[:rank],dtype=int); dropped=[terms[j] for j in range(len(terms)) if j not in set(keep.tolist())]
        X=X[:,keep]; kept_terms=[terms[j] for j in keep]
    else: dropped=[]; kept_terms=[]
    # Factor groups again after removing empty categories/strata.
    gkeys=list(zip(d.coverage_id.astype(str),d.block_id.astype(str),d.physical_stratum.astype(str))); gid,_=pd.factorize(pd.MultiIndex.from_tuples(gkeys),sort=True); ng=int(gid.max()+1)
    n=d.RTS_n.to_numpy(float); bg=d.background_area_m2.to_numpy(float); offset=np.log(bg)
    totals=np.bincount(gid,weights=n,minlength=ng)
    def eval_ll(theta,gradient=False):
        eta=np.asarray(X@theta).ravel()+offset if len(theta) else offset
        mx=np.full(ng,-np.inf); np.maximum.at(mx,gid,eta)
        ex=np.exp(eta-mx[gid]); denom=np.bincount(gid,weights=ex,minlength=ng)
        lz=mx+np.log(denom)
        p=ex/denom[gid]
        ll=float(np.sum(n*eta)-np.sum(totals*lz)-np.sum(gammaln(n+1)))
        if gradient:
            g=np.asarray(X.T@(n-totals[gid]*p)).ravel() if len(theta) else np.zeros(0)
            return -ll,-g
        return ll
    if len(kept_terms):
        theta0=np.zeros(len(kept_terms),dtype=float)
        if start_coefficients:
            theta0=np.asarray([float(start_coefficients.get(term,0.0)) for term in kept_terms],dtype=float)
        # Match the formal DARTS interaction optimizer: L-BFGS-B with the null
        # fit as the alternative start for shared terms; additional interaction
        # coefficients start at zero. This changes only numerical initialization.
        res=minimize(lambda t:eval_ll(t,True),theta0,jac=True,method="L-BFGS-B",options={"maxiter":5000,"ftol":1e-12,"gtol":1e-7,"maxls":50})
        theta=res.x; ok=bool(res.success or (res.jac is not None and np.linalg.norm(res.jac)<1e-4)); msg=str(res.message)
    else: theta=np.zeros(0); ok=True; msg="intercept-only conditional model"
    ll=eval_ll(theta,False)
    return {"status":"PASS" if ok else "MODEL_FAILED","ok":ok,"ll":ll,"n_rows":len(d),"n_groups":ng,"n_coverage":len(covs),"n_blocks":d[["coverage_id","block_id"]].drop_duplicates().shape[0],"n_parameters":len(kept_terms),"terms":kept_terms,"theta":theta,"dropped_terms":dropped,"message":msg,"model_categories":";".join(cats),"unsupported_zero_area_cell_n":unsupported_cell_n,"unsupported_zero_area_RTS_n":unsupported_rts_n}

def heterogeneity_test(scenario,cells,include_phys):
    m0=fit_conditional(cells,include_phys=include_phys,include_coverage=False)
    start=dict(zip(m0.get("terms",[]),m0.get("theta",[]))) if m0.get("ok",False) else None
    m1=fit_conditional(cells,include_phys=include_phys,include_coverage=True,start_coefficients=start)
    ok=m0.get("ok",False) and m1.get("ok",False)
    stat=2*(m1["ll"]-m0["ll"]) if ok else np.nan
    df=m1.get("n_parameters",0)-m0.get("n_parameters",0) if ok else 0
    p=float(chi2.sf(stat,df)) if ok and df>0 else np.nan
    inter=[float(v) for t,v in zip(m1.get("terms",[]),m1.get("theta",[])) if t.startswith("coverage[")]
    return dict(scenario=scenario,physical_adjustment="YES" if include_phys else "NO",M0_status=m0.get("status"),M1_status=m1.get("status"),M0_loglik=m0.get("ll",np.nan),M1_loglik=m1.get("ll",np.nan),heterogeneity_LR=stat,df=df,nominal_p=p,M0_n_rows=m0.get("n_rows"),M1_n_rows=m1.get("n_rows"),M0_coverage_n=m0.get("n_coverage"),M1_coverage_n=m1.get("n_coverage"),M0_parameters=m0.get("n_parameters"),M1_parameters=m1.get("n_parameters"),M0_unsupported_zero_area_cell_n=m0.get("unsupported_zero_area_cell_n"),M1_unsupported_zero_area_cell_n=m1.get("unsupported_zero_area_cell_n"),M0_unsupported_zero_area_RTS_n=m0.get("unsupported_zero_area_RTS_n"),M1_unsupported_zero_area_RTS_n=m1.get("unsupported_zero_area_RTS_n"),coverage_interaction_coefficient_min=min(inter) if inter else np.nan,coverage_interaction_coefficient_max=max(inter) if inter else np.nan,M0_message=m0.get("message",m0.get("reason")),M1_message=m1.get("message",m1.get("reason")),M0_rank_dropped=";".join(m0.get("dropped_terms",[])),M1_rank_dropped=";".join(m1.get("dropped_terms",[])),model_categories=m1.get("model_categories",""),status="PASS" if ok and df>0 else "MODEL_FAILED_OR_UNIDENTIFIABLE")

def score_counts(n,p,alpha=0.0):
    n=np.asarray(n,float); p=np.asarray(p,float)
    # Fixed additive pseudo-count is applied only to the held-out log score.
    # It does not change observed counts, fitted parent rates, or predictions.
    if alpha > 0:
        n_total=float(n.sum())
        if n_total <= 0: return np.nan
        p=(n_total*p+float(alpha))/(n_total+float(alpha)*len(p))
    if np.any((n>0)&(p<=0)): return -np.inf
    return float(np.sum(n[n>0]*np.log(p[n>0])))

def ext_diff(a,b):
    if np.isnan(a) or np.isnan(b): return np.nan
    if np.isneginf(a) and np.isneginf(b): return np.nan
    if np.isposinf(a) and np.isposinf(b): return np.nan
    return a-b

def transfer_for_coverage(uid,scenario,r,b,scale,alpha=None):
    if alpha is None: alpha=TRANSFER_ALPHA
    bc=f"block_{scale}"
    blocks=sorted(set(r[bc].astype(str))|set(b[bc].astype(str)))
    strata=sorted(set(r.physical_stratum.astype(str))|set(b.physical_stratum.astype(str)))
    bi={x:i for i,x in enumerate(blocks)}; si={x:i for i,x in enumerate(strata)}; ci={x:i for i,x in enumerate(CLASSES)}
    C=np.zeros((len(blocks),len(strata),len(CLASSES)),dtype=float); A=np.zeros_like(C)
    q=r.groupby([bc,"physical_stratum","community"],sort=False).size()
    for (blk,st,c),v in q.items(): C[bi[str(blk)],si[str(st)],ci[str(c)]]=float(v)
    q=b.groupby([bc,"physical_stratum","community"],sort=False).coverage_intersection_area_m2.sum()
    for (blk,st,c),v in q.items(): A[bi[str(blk)],si[str(st)],ci[str(c)]]=float(v)
    totc=C.sum(axis=0); tota=A.sum(axis=0); rows=[]
    for i,blk in enumerate(blocks):
        localc=C[i]; locala=A[i]; N=float(localc.sum()); area=float(locala.sum())
        if N<=0: continue
        fallback_n=0; unscorable=False; score_p=0.0; score_a=0.0; obs_mix=np.zeros(len(CLASSES)); pp_mix=np.zeros(len(CLASSES)); pa_mix=np.zeros(len(CLASSES)); n_scored=0
        for j,st in enumerate(strata):
            nc=localc[j]; B=locala[j]; ns=float(nc.sum())
            if ns<=0: continue
            sb=float(B.sum())
            if sb<=0: unscorable=True; break
            pa=B/sb
            train_n=totc[j]-nc; train_b=tota[j]-B; tn=float(train_n.sum()); tb=float(train_b.sum())
            rates=np.full(len(CLASSES),np.nan)
            if tn>0 and tb>0:
                for k in range(len(CLASSES)):
                    if train_b[k]>0: rates[k]=(train_n[k]/tn)/(train_b[k]/tb)
            # A category absent from the held-out block's background has no
            # prediction support and must carry exactly zero weight. Its
            # undefined parent rate is irrelevant to normalization.
            need=(B>0)
            w=np.zeros_like(B,dtype=float)
            invalid=(tn<=0 or tb<=0 or np.any(need&~np.isfinite(rates)))
            if not invalid:
                w[need]=B[need]*rates[need]
                invalid=(not np.isfinite(w[need]).all() or not np.isfinite(w.sum()) or w.sum()<=0)
            if invalid:
                pp=pa.copy(); fallback_n+=1
            else: pp=w/w.sum()
            sa=score_counts(nc,pa,alpha=alpha); sp=score_counts(nc,pp,alpha=alpha)
            if np.isneginf(score_a) or np.isneginf(sa): score_a=-np.inf
            else: score_a+=sa
            if np.isneginf(score_p) or np.isneginf(sp): score_p=-np.inf
            else: score_p+=sp
            obs_mix += nc
            pa_mix += ns*pa
            pp_mix += ns*pp
            n_scored += ns
        if unscorable or n_scored<=0:
            rows.append(dict(coverage_id=uid,scenario=scenario,scale_km=scale,block_id=blk,N_rts=N,delta_LL=np.nan,delta_LL_per_RTS=np.nan,score_parent=score_p,score_area=score_a,TV_parent=np.nan,TV_area=np.nan,parent_fallback_strata_n=fallback_n,status="UNSCORABLE_STRATUM_NO_BACKGROUND")); continue
        obs=obs_mix/n_scored; pa=pa_mix/n_scored; pp=pp_mix/n_scored
        d=ext_diff(score_p,score_a)
        rows.append(dict(coverage_id=uid,scenario=scenario,scale_km=scale,block_id=blk,N_rts=N,scoring_alpha=float(alpha),delta_LL=d,delta_LL_per_RTS=(d/N if np.isfinite(d) else d),score_parent=score_p,score_area=score_a,TV_parent=float(.5*np.abs(obs-pp).sum()),TV_area=float(.5*np.abs(obs-pa).sum()),parent_fallback_strata_n=fallback_n,status="PARENT_FALLBACK_AREA" if fallback_n else "SCORED",low_support=int(N<20),zero_observed_categories=";".join([c for c,nc in zip(CLASSES,obs_mix) if nc==0])))
    return pd.DataFrame(rows)

def transfer_summaries(block_df):
    covrows=[]
    if block_df.empty: return pd.DataFrame(),pd.DataFrame()
    for (scenario,sc,cov),g in block_df.groupby(["scenario","scale_km","coverage_id"],sort=True):
        z=g[g.status.isin(["SCORED","PARENT_FALLBACK_AREA"])].copy(); x=z.delta_LL_per_RTS.to_numpy(float); f=x[np.isfinite(x)]
        med=extended_quantile(x,.5)
        covrows.append(dict(scenario=scenario,scale_km=sc,coverage_id=cov,block_n=len(g),scored_block_n=len(z),finite_delta_block_n=int(np.isfinite(x).sum()),coverage_median_delta_LL_per_RTS=med,coverage_mean_delta_LL_per_RTS=extended_mean(x),coverage_finite_mean_delta_LL_per_RTS=float(f.mean()) if len(f) else np.nan,positive_block_fraction=float(np.mean(x>0)) if len(x) else np.nan,median_TV_parent=float(z.TV_parent.median()) if len(z) else np.nan,median_TV_area=float(z.TV_area.median()) if len(z) else np.nan,parent_fallback_block_fraction=float(z.status.eq("PARENT_FALLBACK_AREA").mean()) if len(z) else np.nan,low_support_block_fraction=float(z.low_support.mean()) if len(z) and "low_support" in z else np.nan))
    cs=pd.DataFrame(covrows); overall=[]
    rng=np.random.default_rng(TRANSFER_SEED)
    for (scenario,sc),g in block_df.groupby(["scenario","scale_km"],sort=True):
        z=g[g.status.isin(["SCORED","PARENT_FALLBACK_AREA"])].copy()
        per=[]
        by={c:sub.reset_index(drop=True) for c,sub in z.groupby("coverage_id",sort=True)}
        for c,sub in by.items(): per.append(extended_mean(sub.delta_LL_per_RTS.to_numpy(float)))
        point=extended_mean(per)
        pos_cov=int((cs[(cs.scenario==scenario)&(cs.scale_km==sc)].coverage_median_delta_LL_per_RTS>0).sum())
        vals=z.delta_LL_per_RTS.to_numpy(float); positive=float(np.mean(vals>0)) if len(vals) else np.nan
        boot=np.full(NBOOT_TRANSFER,np.nan); finiteboot=np.full(NBOOT_TRANSFER,np.nan)
        covs=list(by)
        for rep in range(NBOOT_TRANSFER):
            if not covs: continue
            chosen=rng.integers(0,len(covs),size=len(covs)); means=[]; fmeans=[]
            for ix in chosen:
                arr=by[covs[ix]].delta_LL_per_RTS.to_numpy(float)
                draw=arr[rng.integers(0,len(arr),size=len(arr))]
                means.append(extended_mean(draw))
                f=draw[np.isfinite(draw)]; fmeans.append(float(f.mean()) if len(f) else np.nan)
            boot[rep]=extended_mean(means); fv=np.asarray(fmeans,float); fv=fv[np.isfinite(fv)]; finiteboot[rep]=float(fv.mean()) if len(fv) else np.nan
        valid=boot[~np.isnan(boot)]; fb=finiteboot[np.isfinite(finiteboot)]
        finite_z=vals[np.isfinite(vals)]
        overall.append(dict(scenario=scenario,scale_km=sc,coverage_n=len(by),coverage_positive_count=pos_cov,positive_block_fraction=positive,block_n=len(z),finite_block_n=len(finite_z),delta_LL_per_RTS_coverage_equal_mean=point,delta_LL_CI95_low=extended_quantile(valid,.025),delta_LL_CI95_high=extended_quantile(valid,.975),bootstrap_replicates=NBOOT_TRANSFER,bootstrap_valid_n=len(valid),bootstrap_seed=TRANSFER_SEED,finite_only_delta_LL_per_RTS=float(finite_z.mean()) if len(finite_z) else np.nan,finite_only_coverage_equal_mean=(float(np.nanmean([np.nanmean(by[c].delta_LL_per_RTS[np.isfinite(by[c].delta_LL_per_RTS)]) if np.isfinite(by[c].delta_LL_per_RTS).any() else np.nan for c in by]))),finite_only_CI95_low=float(np.quantile(fb,.025)) if len(fb) else np.nan,finite_only_CI95_high=float(np.quantile(fb,.975)) if len(fb) else np.nan,finite_only_bootstrap_valid_n=len(fb),median_TV_parent=float(z.TV_parent.median()) if len(z) else np.nan,median_TV_area=float(z.TV_area.median()) if len(z) else np.nan,mean_TV_parent=float(z.TV_parent.mean()) if len(z) else np.nan,mean_TV_area=float(z.TV_area.mean()) if len(z) else np.nan,parent_fallback_block_fraction=float(z.status.eq("PARENT_FALLBACK_AREA").mean()) if len(z) else np.nan))
    return cs,pd.DataFrame(overall)
