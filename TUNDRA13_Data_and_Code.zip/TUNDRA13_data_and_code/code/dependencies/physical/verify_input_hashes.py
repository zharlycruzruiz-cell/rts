from pathlib import Path
import json,hashlib,pandas as pd
ROOT=Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01"); OUT=ROOT/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"physical"; PHYS=ROOT/"PHYSICAL_CONFOUNDING_SENSITIVITY_V1"
IDS=json.loads((ROOT/"RTS_TUNDRA13_FULL_REANALYSIS_V1"/"TUNDRA13_COVERAGE_MANIFEST.json").read_text(encoding="utf-8"))["coverage_ids"]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for x in iter(lambda:f.read(1024*1024),b""): h.update(x)
 return h.hexdigest()
def norm(x): return str(x).replace("/","\\").lower()
def lookup(path):
 d=pd.read_csv(path,low_memory=False); return {norm(x.path):str(x.sha256).lower() for x in d.itertuples(index=False)}
raw=lookup(PHYS/"V2_TECHNICAL_REVISION"/"V2_INPUT_OUTPUT_HASHES.csv")
glo=lookup(PHYS/"COPERNICUS_GLO30_PIXEL_SLOPE_SUPPORT_V1"/"OUTPUT_HASHES.csv")
vic=lookup(PHYS/"V2_TECHNICAL_REVISION"/"V2_INPUT_OUTPUT_HASHES.csv")
base=ROOT/"DARTS16_WORLDCOVER_PRODUCT_SENSITIVITY_V1"/"worldcover_unit_cache"; out=[]
for uid in IDS:
 code=uid.split("_")[-1]
 files=[("RTS_ASSIGNMENT",base/f"{uid}_RTS_ASSIGNMENTS.csv",raw),("BACKGROUND_GRID",base/f"{uid}_BACKGROUND_GRID.csv",raw),("GLO30_RTS_SLOPE",PHYS/"COPERNICUS_GLO30_PIXEL_SLOPE_SUPPORT_V1"/"physical_attributes"/f"COV_{code}_RTS_GLO30_SLOPE_RING.csv.gz",glo),("GLO30_BG_SLOPE",PHYS/"COPERNICUS_GLO30_PIXEL_SLOPE_SUPPORT_V1"/"physical_attributes"/f"COV_{code}_BACKGROUND_GLO30_SLOPE_RING.csv.gz",glo)]
 adir=PHYS/"V2_TECHNICAL_REVISION"/"physical_attributes_exact_overlap_v2"/uid
 files += [("VIC_RTS",adir/f"{uid}_RTS_EXACT_OVERLAP_PHYSICAL_ATTRIBUTES.csv.gz",vic),("VIC_BG",adir/f"{uid}_BG_EXACT_OVERLAP_PHYSICAL_ATTRIBUTES.csv.gz",vic)]
 if uid in ["DARTS2023_COV_001","DARTS2023_COV_003","DARTS2023_COV_014","DARTS2023_COV_019","DARTS2023_COV_021","DARTS2023_COV_033"]:
  ad=PHYS/"V2_TECHNICAL_REVISION"/"data_processed"/"ArcticDEM_v4.1_32m_CROPS"/uid
  files += [("ARCTICDEM_RTS",ad/f"{uid}_RTS_SLOPE_RING_ATTRIBUTES_V2.csv.gz",vic),("ARCTICDEM_BG",ad/f"{uid}_BACKGROUND_SLOPE_RING_ATTRIBUTES_V2.csv.gz",vic)]
 for role,p,manifest in files:
  exp=manifest.get(norm(p),""); actual=sha(p) if p.exists() else ""; status="PASS" if p.exists() and exp and exp==actual.lower() else "FAIL"
  out.append({"coverage_id":uid,"role":role,"path":str(p),"expected_sha256":exp,"actual_sha256":actual,"bytes":p.stat().st_size if p.exists() else None,"status":status})
df=pd.DataFrame(out); df.to_csv(OUT/"INPUT_HASH_AUDIT.csv",index=False); df[df.status.eq("PASS")].to_csv(OUT/"INPUT_HASHES.csv",index=False)
(OUT/"HASH_VERIFICATION.md").write_text(f"# Input hash verification\n\n13-zone selected inputs checked: {len(df)}\nPASS: {(df.status=="PASS").sum()}\nFAIL: {(df.status!="PASS").sum()}\n\nNo old 14-zone aggregate model output was an input.\n",encoding="utf-8")
print(f"checked={len(df)} pass={(df.status=="PASS").sum()} fail={(df.status!="PASS").sum()}")
if df.status.ne("PASS").any(): raise SystemExit(2)

