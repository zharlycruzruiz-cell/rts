# Analysis dependencies

These files contain the original helper scripts used by the geospatial and sensitivity analyses. The inventory, ring, physical, transfer and reconstruction folders group scripts by their role.

The scripts retain their original paths and input requirements. Running them from raw data requires the corresponding public products, intermediate files, geospatial libraries and path configuration. The regional model check in `code/reproduce.py` uses the supplied analysis-ready inputs.
