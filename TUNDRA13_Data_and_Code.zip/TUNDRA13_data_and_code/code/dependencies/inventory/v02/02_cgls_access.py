"""Local CGLS tile cache copy and bounded HTTP range retrieval."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import struct
import time
import urllib.request
import zlib
import numpy as np

SOURCE_ROOT = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01\NORTH_SIBERIA_VEGETATION_LIFECYCLE_BRIDGE")
SOURCE_CACHE = SOURCE_ROOT / "tile_cache"
URL = "https://zenodo.org/records/3939050/files/PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif?download=1"
TILE = 256


def load_index():
    off = (SOURCE_ROOT / "cgls_offsets.bin").read_bytes()
    bc = (SOURCE_ROOT / "cgls_bytecounts.bin").read_bytes()
    n = min(len(off), len(bc)) // 8
    offsets = [struct.unpack_from("<Q", off, i * 8)[0] for i in range(n)]
    counts = [struct.unpack_from("<Q", bc, i * 8)[0] for i in range(n)]
    return offsets, counts


def valid_tile(path: Path, expected: int) -> bool:
    if not path.exists() or path.stat().st_size != expected:
        return False
    try:
        np.frombuffer(zlib.decompress(path.read_bytes()), dtype=np.uint8).reshape((TILE, TILE))
        return True
    except Exception:
        return False


def copy_existing(target: Path):
    target.mkdir(parents=True, exist_ok=True)
    copied = 0
    for src in sorted(SOURCE_CACHE.glob("tile_*.bin")):
        dst = target / src.name
        if not dst.exists() or dst.stat().st_size != src.stat().st_size:
            dst.write_bytes(src.read_bytes())
            copied += 1
    return copied


def _fetch_one(ti: int, offsets, counts, target: Path, retries: int = 3):
    dst = target / f"tile_{ti:07d}.bin"
    expected = int(counts[ti])
    if valid_tile(dst, expected):
        return {"tile_id": ti, "status": "EXISTING_VALID", "bytes": expected, "sha256": hashlib.sha256(dst.read_bytes()).hexdigest(), "source_url": URL, "error": ""}
    start = int(offsets[ti]); end = start + expected - 1
    err = ""
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(URL, headers={"Range": f"bytes={start}-{end}", "User-Agent": "FORMAL-PIPELINE-V0.2"})
            with urllib.request.urlopen(req, timeout=25) as resp:
                data = resp.read()
            if len(data) != expected:
                raise IOError(f"range returned {len(data)} bytes, expected {expected}")
            np.frombuffer(zlib.decompress(data), dtype=np.uint8).reshape((TILE, TILE))
            tmp = dst.with_suffix(".part")
            tmp.write_bytes(data)
            tmp.replace(dst)
            return {"tile_id": ti, "status": "DOWNLOADED", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "source_url": URL, "error": ""}
        except Exception as exc:
            err = repr(exc)
            time.sleep(min(2 ** (attempt - 1), 4))
    return {"tile_id": ti, "status": "FAILED", "bytes": 0, "sha256": "", "source_url": URL, "error": err}


def ensure_tiles(tile_ids: set[int], target: Path):
    offsets, counts = load_index()
    target.mkdir(parents=True, exist_ok=True)
    ids = sorted(int(i) for i in tile_ids if 0 <= int(i) < len(counts))
    rows = []
    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = [ex.submit(_fetch_one, ti, offsets, counts, target) for ti in ids]
        for i, fut in enumerate(as_completed(futs), 1):
            rows.append(fut.result())
            if i % 100 == 0 or i == len(futs):
                print(f"CGLS v0.2 tiles {i}/{len(futs)}", flush=True)
    rows.sort(key=lambda x: x["tile_id"])
    return rows
