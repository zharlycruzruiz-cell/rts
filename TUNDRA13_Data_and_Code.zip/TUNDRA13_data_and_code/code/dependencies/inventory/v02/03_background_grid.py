"""Independent coverage-grid denominator for DARTS Peel.

This module deliberately separates the landscape frame (coverage-grid cell
areas) from RTS ring support.  Rings are used only to assign the modal class
at each RTS or background grid location; they are never summed as a
denominator.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import importlib.util
import json
import math
import numpy as np
import pandas as pd

V01 = Path(__file__).resolve().parent.parent / "FORMAL_RTS_COMMUNITY_ANALYSIS_V0_1"
spec = importlib.util.spec_from_file_location("v01_ring", V01 / "05_background_ring.py")
ring = importlib.util.module_from_spec(spec); spec.loader.exec_module(ring)
spec2 = importlib.util.spec_from_file_location("v01_loader", V01 / "01_inventory_loader.py")
loader = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(loader)
spec3 = importlib.util.spec_from_file_location("v01_cw", V01 / "04_vegetation_crosswalk.py")
cw = importlib.util.module_from_spec(spec3); spec3.loader.exec_module(cw)
from pyproj import Transformer
from shapely.geometry import box, Point
from shapely import contains_xy
from scipy.ndimage import binary_erosion
from rasterio.features import rasterize
from rasterio.transform import from_origin
from shapely.ops import transform as shp_transform, unary_union

GRID_CRS = "EPSG:6933"  # WGS84 / NSIDC EASE-Grid 2.0 Global (equal-area)


def _utm_for(g):
    return 32600 + int((float(g.centroid.x) + 180.0) // 6.0) + 1


def coverage_grid(frame: dict, spacing_m: float = 500.0):
    """Create fixed 500m cells and retain exact coverage intersection area."""
    if not frame.get("coverage"):
        raise ValueError("DARTS Peel coverage polygon is required")
    cov_w = unary_union(frame["coverage"])
    # The Peel coverage spans several UTM zones; a single UTM zone would
    # introduce longitude-dependent scale distortion in the denominator.
    # Use a global equal-area CRS for the fixed 500m landscape grid.
    zone = GRID_CRS
    to_m = Transformer.from_crs(4326, GRID_CRS, always_xy=True).transform
    to_w = Transformer.from_crs(GRID_CRS, 4326, always_xy=True).transform
    cov_m = shp_transform(to_m, cov_w)
    minx, miny, maxx, maxy = cov_m.bounds
    # Rasterize the coverage on the fixed 500m grid. Exact polygon
    # intersections are evaluated only in the narrow touched/edge band;
    # interior cells carry the exact full-cell weight. This avoids millions
    # of per-cell Shapely intersections for the large Peel coverage.
    x0 = math.floor(minx / spacing_m) * spacing_m
    y1 = math.ceil(maxy / spacing_m) * spacing_m
    width = int(math.ceil((maxx - x0) / spacing_m))
    height = int(math.ceil((y1 - miny) / spacing_m))
    transform = from_origin(x0, y1, spacing_m, spacing_m)
    center_mask = rasterize([(cov_m, 1)], out_shape=(height, width), transform=transform, all_touched=False).astype(bool)
    touch_mask = rasterize([(cov_m, 1)], out_shape=(height, width), transform=transform, all_touched=True).astype(bool)
    interior_mask = binary_erosion(center_mask, structure=np.ones((3, 3), dtype=bool), border_value=0)
    full_mask = interior_mask
    edge_mask = touch_mask & ~interior_mask
    yy, xx = np.indices((height, width), dtype=np.int64)
    centers_x = x0 + (xx.ravel() + 0.5) * spacing_m
    centers_y = y1 - (yy.ravel() + 0.5) * spacing_m
    full = float(spacing_m * spacing_m)
    rows = []
    idx_full = np.flatnonzero(full_mask.ravel())
    ix_full = xx.ravel()[idx_full].astype(int); iy_full = yy.ravel()[idx_full].astype(int)
    lon_full, lat_full = to_w(centers_x[idx_full], centers_y[idx_full])
    rows.extend({"grid_id": f"PEEL500_{ix:05d}_{iy:05d}", "grid_ix": int(ix), "grid_iy": int(iy), "center_lon": float(lon), "center_lat": float(lat), "coverage_intersection_area_m2": full, "grid_cell_area_m2": full, "utm_epsg": zone} for ix, iy, lon, lat in zip(ix_full, iy_full, lon_full, lat_full))
    for j in np.flatnonzero(edge_mask.ravel()):
        ix = int(xx.ravel()[j]); iy = int(yy.ravel()[j])
        # y index increases downward in raster coordinates.
        cell = box(float(x0 + ix * spacing_m), float(y1 - (iy + 1) * spacing_m), float(x0 + (ix + 1) * spacing_m), float(y1 - iy * spacing_m))
        inter = cell.intersection(cov_m)
        if inter.is_empty or inter.area <= 0:
            continue
        center_m = Point(float(centers_x[j]), float(centers_y[j]))
        center_w = shp_transform(to_w, center_m)
        rows.append({"grid_id": f"PEEL500_{ix:05d}_{iy:05d}", "grid_ix": ix, "grid_iy": iy, "center_lon": center_w.x, "center_lat": center_w.y, "coverage_intersection_area_m2": float(inter.area), "grid_cell_area_m2": full, "utm_epsg": zone})
    return pd.DataFrame(rows), cov_m.area, zone


def set_cache(cache: Path):
    ring.TILE_CACHE = Path(cache)


def tile_ids_for_records(records, frame, region="DARTS_Peel_Plateau"):
    sets = []
    for r in records:
        rg = ring.make_ring(r["geometry"], region, 100, 500)
        sets.append(ring.pixel_set(rg, frame.get("exclusion", []), frame.get("coverage", [])))
    allpix = set().union(*sets) if sets else set()
    return {(r // ring.TILE) * ring.N_TX + (c // ring.TILE) for r, c in allpix}


def _modal(vals):
    if not vals:
        return "NO_DATA_SUPPORT", None, {}, 0
    raw = Counter(int(v) for v in vals)
    n = len(vals)
    water_ice = sum(raw.get(k, 0) for k in (70, 80))
    if water_ice > n / 2:
        community = "EXCLUDED_WATER_ICE"
    else:
        unified = Counter(cw.cgls_unified(int(v)) for v in vals)
        community = unified.most_common(1)[0][0]
    unified_all = Counter("EXCLUDED_WATER_ICE" if int(v) in (70, 80) else cw.cgls_unified(int(v)) for v in vals)
    props = {str(k): float(v / n) for k, v in unified_all.items()}
    return community, int(raw.most_common(1)[0][0]), props, n


def _grid_batch(grid_rows: list[dict], frame: dict, offsets=None, counts=None):
    pixel_sets = []
    for g in grid_rows:
        center = Point(float(g["center_lon"]), float(g["center_lat"]))
        rg = ring.make_ring(center, "DARTS_Peel_Plateau", 100, 500)
        pixel_sets.append(ring.pixel_set(rg, frame.get("exclusion", []), frame.get("coverage", [])))
    if offsets is None or counts is None:
        offsets, counts = ring.cgls_index()
    codes, missing = ring.assign_codes(pixel_sets, offsets, counts)
    rows = []
    for g, pix in zip(grid_rows, pixel_sets):
        vals = [codes[k] for k in pix if k in codes]
        comm, raw_modal, props, valid_n = _modal(vals)
        rows.append({
            **g,
            "community": comm,
            "raw_modal_code": raw_modal if raw_modal is not None else "",
            "raw_valid_pixel_n": int(valid_n),
            "ring_pixel_n": int(len(pix)),
            "nodata_pixel_n": int(len(pix) - valid_n),
            "ring_pixel_area_m2": float(sum(ring.cell_area_m2(k[0]) for k in pix if k in codes)),
            "vegetation_proportions_json": json.dumps(props, sort_keys=True),
            "vegetation_proportion_sum": float(sum(props.values())) if props else np.nan,
            "support_status": "NO_DATA_SUPPORT" if valid_n == 0 else ("PARTIAL_NODATA" if valid_n < len(pix) else "VALID"),
            "ring_inner_m": 100.0, "ring_outer_m": 500.0,
            "vegetation_product": "CGLS_LC100_2019_v3.0.1", "vegetation_year": 2019,
        })
    return pd.DataFrame(rows), set(missing)


def extract_grid(frame: dict, grid_df: pd.DataFrame, batch_size: int = 200, offsets=None, counts=None):
    """Return rows and missing tile IDs; caller may fetch then retry batches."""
    out = []; missing = set()
    records = grid_df.to_dict(orient="records")
    for start in range(0, len(records), batch_size):
        b, miss = _grid_batch(records[start:start + batch_size], frame, offsets, counts)
        out.append(b); missing.update(miss)
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame(), missing


def extract_rts(frame: dict):
    out, qc = ring.extract_region("DARTS_Peel_Plateau", frame)
    if not out.empty:
        out["unknown_reason"] = np.where(out["community"].eq("UNKNOWN"), np.where(out["raw_valid_pixel_n"].eq(0), "NO_VALID_CGLS_PIXELS", "UNMAPPED_PRODUCT_CODE"), "")
    return out, qc


def crop_pixel_window(frame: dict, margin_px: int = 16):
    """Global CGLS pixel window covering coverage plus ring margin."""
    g = unary_union(frame["coverage"])
    minx, miny, maxx, maxy = g.bounds
    c0 = max(0, int(math.floor((minx + 180.0) / ring.SCALE)) - margin_px)
    c1 = min(ring.N_COLS - 1, int(math.ceil((maxx + 180.0) / ring.SCALE)) + margin_px)
    r0 = max(0, int(math.floor((80.0 - maxy) / ring.SCALE)) - margin_px)
    r1 = min(ring.N_ROWS - 1, int(math.ceil((80.0 - miny) / ring.SCALE)) + margin_px)
    return r0, r1, c0, c1


def tile_ids_for_crop(frame: dict, margin_px: int = 16):
    r0, r1, c0, c1 = crop_pixel_window(frame, margin_px)
    return {(r // ring.TILE) * ring.N_TX + (c // ring.TILE) for r in range(r0, r1 + 1, ring.TILE) for c in range(c0, c1 + 1, ring.TILE)}, (r0, r1, c0, c1)


def assemble_crop(frame: dict, cache: Path, margin_px: int = 16):
    """Decode all tiles in the coverage crop and rasterize masks."""
    set_cache(cache)
    r0, r1, c0, c1 = crop_pixel_window(frame, margin_px)
    offsets, counts = ring.cgls_index()
    tids = {(r // ring.TILE) * ring.N_TX + (c // ring.TILE) for r in range(r0, r1 + 1, ring.TILE) for c in range(c0, c1 + 1, ring.TILE)}
    arrays, missing = ring.decode_cached(tids, offsets, counts)
    h, w = r1 - r0 + 1, c1 - c0 + 1
    data = np.zeros((h, w), dtype=np.uint8)
    for ti, a in arrays.items():
        tr, tc = divmod(ti, ring.N_TX)
        sr0, sr1 = max(r0, tr * ring.TILE), min(r1, (tr + 1) * ring.TILE - 1)
        sc0, sc1 = max(c0, tc * ring.TILE), min(c1, (tc + 1) * ring.TILE - 1)
        if sr0 <= sr1 and sc0 <= sc1:
            data[sr0-r0:sr1-r0+1, sc0-c0:sc1-c0+1] = a[sr0-tr*ring.TILE:sr1-tr*ring.TILE+1, sc0-tc*ring.TILE:sc1-tc*ring.TILE+1]
    west = -180.0 + c0 * ring.SCALE
    north = 80.0 - r0 * ring.SCALE
    trf = from_origin(west, north, ring.SCALE, ring.SCALE)
    cov_mask = rasterize([(unary_union(frame["coverage"]), 1)], out_shape=(h, w), transform=trf, all_touched=False).astype(bool)
    ex_mask = rasterize([(g, 1) for g in frame.get("exclusion", [])], out_shape=(h, w), transform=trf, all_touched=False).astype(bool) if frame.get("exclusion") else np.zeros((h, w), dtype=bool)
    return data, cov_mask, ex_mask, (r0, r1, c0, c1), set(missing)


def extract_grid_fast(grid_df: pd.DataFrame, frame: dict, data, cov_mask, ex_mask, window, batch_rows: int = 8):
    """Vectorized *projected* ring extraction at fixed grid centers.

    This keeps the same point-in-ring semantics as ``05_background_ring``:
    each CGLS pixel centre is transformed to the centre's UTM zone and is
    retained when its projected distance is in (100, 500] metres.  The
    calculation is batched by grid row and UTM zone so the 836k-cell Peel
    frame remains tractable; coverage and historical RTS masks are applied
    to the same pixel-centre candidates.
    """
    r0, r1, c0, c1 = window
    class_names = np.array(["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE", "OTHER"], dtype=object)
    result = []
    for _, g in grid_df.groupby("grid_iy", sort=True):
        # A single grid row can straddle a UTM-zone boundary; process each
        # zone separately so the geometry matches make_ring exactly.
        zones = ((g["center_lon"].astype(float) + 180.0) // 6.0 + 1).astype(int) + 32600
        for zone, sub in g.groupby(zones):
            sub = sub.copy()
            lat_min = float(sub["center_lat"].min())
            lat_max = float(sub["center_lat"].max())
            # Generous rectangular candidate bounds; the projected distance
            # test below supplies the exact annulus membership.
            dlat_m = 111320.0 * ring.SCALE
            dlon_m = dlat_m * max(math.cos(math.radians(lat_min)), 0.01)
            dr = np.arange(-int(math.ceil(500.0 / dlat_m)) - 3, int(math.ceil(500.0 / dlat_m)) + 4)
            dc = np.arange(-int(math.ceil(500.0 / dlon_m)) - 3, int(math.ceil(500.0 / dlon_m)) + 4)
            drr, dcc = np.meshgrid(dr, dc, indexing="ij")
            odr, odc = drr.ravel().astype(int), dcc.ravel().astype(int)
            cg = np.floor((sub["center_lon"].to_numpy(dtype=float) + 180.0) / ring.SCALE).astype(int) - c0
            rg = np.floor((80.0 - sub["center_lat"].to_numpy(dtype=float)) / ring.SCALE).astype(int) - r0
            rr = rg[:, None] + odr[None, :]
            cc = cg[:, None] + odc[None, :]
            inside = (rr >= 0) & (rr < data.shape[0]) & (cc >= 0) & (cc < data.shape[1])
            rr_safe = np.clip(rr, 0, data.shape[0] - 1)
            cc_safe = np.clip(cc, 0, data.shape[1] - 1)
            vals = data[rr_safe, cc_safe]

            # Reproduce make_ring's UTM-buffer membership at CGLS pixel
            # centres.  Transforming this bounded candidate array is much
            # cheaper than constructing 836k Shapely polygons.
            tr = Transformer.from_crs(4326, int(zone), always_xy=True)
            cx, cy = tr.transform(sub["center_lon"].to_numpy(dtype=float), sub["center_lat"].to_numpy(dtype=float))
            pix_lon = -180.0 + (cc_safe + c0 + 0.5) * ring.SCALE
            pix_lat = 80.0 - (rr_safe + r0 + 0.5) * ring.SCALE
            px, py = tr.transform(pix_lon.ravel(), pix_lat.ravel())
            px = np.asarray(px).reshape(pix_lon.shape); py = np.asarray(py).reshape(pix_lat.shape)
            dist2 = (px - np.asarray(cx)[:, None]) ** 2 + (py - np.asarray(cy)[:, None]) ** 2
            ring_keep = (dist2 <= 500.0 ** 2) & (dist2 > 100.0 ** 2)
            geo = inside & ring_keep & cov_mask[rr_safe, cc_safe] & ~ex_mask[rr_safe, cc_safe]
            valid = geo & (vals != 0) & (vals != 255)
            nvalid = valid.sum(axis=1)
            water = (valid & ((vals == 70) | (vals == 80))).sum(axis=1)
            counts = np.column_stack([
                (valid & (vals >= 111) & (vals <= 126)).sum(axis=1),
                (valid & (vals == 20)).sum(axis=1),
                (valid & (vals == 30)).sum(axis=1),
                (valid & (vals == 90)).sum(axis=1),
                (valid & (vals == 100)).sum(axis=1),
                (valid & (vals == 60)).sum(axis=1),
            ])
            other = nvalid - water - counts.sum(axis=1)
            counts = np.column_stack([counts, other])
            winner = counts.argmax(axis=1)
            max_count = counts[np.arange(len(sub)), winner]
            comm = class_names[winner].astype(object)
            comm[(nvalid == 0)] = "NO_DATA_SUPPORT"
            comm[(nvalid > 0) & (water > nvalid / 2)] = "EXCLUDED_WATER_ICE"
            prop_sum = np.where(nvalid > 0, 1.0, np.nan)
            df = sub.copy()
            df["community"] = comm
            df["raw_modal_code"] = ""
            df["raw_valid_pixel_n"] = nvalid.astype(int)
            df["ring_pixel_n"] = geo.sum(axis=1).astype(int)
            df["masked_pixel_n"] = (~geo).sum(axis=1).astype(int)
            df["nodata_pixel_n"] = (geo & ~valid).sum(axis=1).astype(int)
            df["modal_class_proportion"] = np.where(nvalid > 0, max_count / nvalid, np.nan)
            df["water_ice_fraction"] = np.where(nvalid > 0, water / nvalid, np.nan)
            df["vegetation_proportion_sum"] = prop_sum
            df["support_status"] = np.where(nvalid == 0, "NO_DATA_SUPPORT", np.where((geo & ~valid).sum(axis=1) > 0, "PARTIAL_NODATA", "VALID"))
            df["ring_inner_m"] = 100.0; df["ring_outer_m"] = 500.0
            df["vegetation_product"] = "CGLS_LC100_2019_v3.0.1"; df["vegetation_year"] = 2019
            result.append(df)
    return pd.concat(result, ignore_index=True) if result else pd.DataFrame()
