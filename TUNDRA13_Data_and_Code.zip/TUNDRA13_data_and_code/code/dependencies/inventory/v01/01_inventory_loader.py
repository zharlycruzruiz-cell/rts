"""Raw inventory loading for the three v0.1 test regions."""
from __future__ import annotations
import sqlite3
from collections import defaultdict
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import shapefile

VENDOR = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01\RTS_SAME_PLACE_LIFECYCLE_BRIDGE\_vendor")
sys.path.insert(0, str(VENDOR))
from pyproj import Transformer
from shapely import from_wkb
from shapely.geometry import shape
from shapely.ops import transform as shp_transform

ROUND = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01")
DATA = ROUND / "RTS_VEGETATION_COUPLING_BRIDGE_PUBLIC_RECHECK" / "public_sources"
DARTS = DATA / "DARTS_v1_2"
QTP = DATA / "QTP_10928346"
NS = ROUND / "RTS_SAME_PLACE_LIFECYCLE_BRIDGE" / "raw_sources" / "RTS_NESiberia"

SEED = 20260907


def read_gpkg(path: Path, where: str | None = None) -> list[dict]:
    con = sqlite3.connect(path)
    table = con.execute("select table_name from gpkg_contents where data_type='features'").fetchone()[0]
    cols = [x[1] for x in con.execute(f'pragma table_info("{table}")').fetchall()]
    attrs = [c for c in cols if c != "geom"]
    sql = f'select {", ".join(chr(34)+c+chr(34) for c in attrs)}, geom from "{table}"'
    if where:
        sql += " WHERE " + where
    rows = []
    for tup in con.execute(sql):
        d = dict(zip(attrs + ["geom"], tup))
        blob = d.pop("geom")
        flags = blob[3] & 0x0F
        env = (flags >> 1) & 0x07
        off = 8 + (32 if env == 1 else 0)
        d["geometry"] = from_wkb(blob[off:])
        rows.append(d)
    con.close()
    return rows


def in_bbox(g, bbox):
    a, b, c, d = bbox
    return g.bounds[0] <= b and g.bounds[2] >= a and g.bounds[1] <= d and g.bounds[3] >= c


def load_darts_peel() -> dict:
    bbox = (-136, -120, 64, 69)
    all_bbox = [r for r in read_gpkg(DARTS / "features_level2.gpkg") if in_bbox(r["geometry"], bbox)]
    latest = [r for r in all_bbox if int(r.get("year")) == 2023]
    rng = np.random.default_rng(SEED)
    if len(latest) > 300:
        latest = [latest[i] for i in rng.choice(len(latest), 300, replace=False)]
    for r in latest:
        r.update({"dataset": "DARTS", "region": "DARTS_Peel_Plateau", "rts_id": str(r.get("id")), "source_year": 2023})
    hist = [r["geometry"] for r in all_bbox]
    cov = [r["geometry"] for r in read_gpkg(DARTS / "coverage_level2.gpkg", '"year" = 2023') if in_bbox(r["geometry"], bbox)]
    from collections import Counter, defaultdict
    annual_keys = Counter((int(r.get("year")), str(r.get("id"))) for r in all_bbox)
    by_id_year = defaultdict(set)
    for r in all_bbox:
        by_id_year[str(r.get("id"))].add(int(r.get("year")))
    return {"records": latest, "exclusion": hist, "coverage": cov, "source_crs": "EPSG:4326", "geometry_type": "polygon", "sample_n": len(latest), "inventory_n": None, "annual_rows_in_bbox_n": len(all_bbox), "annual_duplicate_feature_n": int(sum(n - 1 for n in annual_keys.values() if n > 1)), "cross_year_id_recurrence_n": int(sum(1 for years in by_id_year.values() if len(years) > 1))}


def read_qtp_year(path: Path) -> list[dict]:
    rdr = shapefile.Reader(str(path))
    names = [f[0] for f in rdr.fields[1:]]
    out = []
    for rec, shp in zip(rdr.iterRecords(), rdr.iterShapes()):
        d = dict(zip(names, rec))
        # The public bundles use both ``Area`` and ``area`` (and one bundle
        # has a leading space in the longitude field). Normalize only lookup
        # keys; raw fields are otherwise retained in the returned dictionary.
        area_key = next((k for k in d if str(k).strip().lower() == "area"), None)
        cluster_key = next((k for k in d if str(k).strip().lower() == "cluster"), None)
        d["geometry"] = shape(shp.__geo_interface__)
        d["id"] = int(d["id"])
        d["Cluster"] = int(d[cluster_key])
        d["Area"] = float(d[area_key])
        out.append(d)
    return out


def load_qtp() -> dict:
    latest_all = read_qtp_year(QTP / "QTP_RTS_2022.shp")
    by = defaultdict(list)
    for r in latest_all:
        by[r["Cluster"]].append(r)
    rng = np.random.default_rng(SEED)
    target = min(1000, len(latest_all))
    quotas = {k: max(1, round(target * len(v) / len(latest_all))) for k, v in by.items()}
    while sum(quotas.values()) > target:
        k = max(quotas, key=lambda x: quotas[x])
        if quotas[k] > 1:
            quotas[k] -= 1
        else:
            break
    while sum(quotas.values()) < target:
        k = max(by, key=lambda x: len(by[x]) - quotas[x])
        quotas[k] += 1
    trans = Transformer.from_crs(
        "+proj=aea +lat_1=27.5 +lat_2=37.5 +lat_0=0 +lon_0=90 +datum=WGS84 +units=m +no_defs",
        4326, always_xy=True)
    selected = []
    for k, vals in by.items():
        selected.extend([vals[i] for i in rng.choice(len(vals), min(quotas[k], len(vals)), replace=False)])
    recs = []
    for r in selected:
        g = shp_transform(trans.transform, r["geometry"])
        recs.append({"dataset": "QTP", "region": "QTP", "rts_id": str(r["id"]), "cluster": r["Cluster"], "geometry": g, "rts_area_m2": r["Area"], "source_year": 2022})
    hist = []
    for path in sorted(QTP.glob("QTP_RTS_*.shp")):
        hist.extend([shp_transform(trans.transform, r["geometry"]) for r in read_qtp_year(path)])
    # ``recs`` and ``hist`` are transformed to WGS84 for spatial joins; keep
    # the native CRS as a separate provenance field so area code cannot treat
    # degree coordinates as metres.
    return {"records": recs, "exclusion": hist, "coverage": [], "source_crs": "EPSG:4326", "native_crs": "Albers WGS84", "geometry_type": "polygon", "sample_n": len(recs), "inventory_n": len(latest_all)}


def load_north_siberia() -> dict:
    rdr = shapefile.Reader(str(NS / "RTS_NESiberia.shp"))
    names = [f[0] for f in rdr.fields[1:]]
    records = []
    for rec in rdr.iterRecords():
        d = dict(zip(names, rec))
        d["rts_id"] = str(d["id"])
        d["lon"] = float(d["Longitude"])
        d["lat"] = float(d["Latitude"])
        records.append(d)
    # Deterministic spatially stratified sample: one per occupied 2° cell,
    # then fixed-seed sample to 5,000, matching the bridge sampling frame.
    by_cell = defaultdict(list)
    for i, r in enumerate(records):
        by_cell[(int(np.floor(r["lon"] / 2)), int(np.floor(r["lat"] / 2)))].append(i)
    rng = np.random.default_rng(SEED)
    first = [rng.choice(v) for v in by_cell.values()]
    remain = [i for i in range(len(records)) if i not in set(first)]
    need = min(5000, len(records)) - len(first)
    chosen = first + (list(rng.choice(remain, need, replace=False)) if need > 0 else [])
    chosen = chosen[: min(5000, len(records))]
    sample = []
    for i in chosen:
        r = records[i].copy()
        r.update({"dataset": "North Siberia", "region": "North Siberia", "source_year": "2000-2019", "geometry_type": "point"})
        sample.append(r)
    return {"records": sample, "all_records": records, "exclusion": [], "coverage": [], "source_crs": "EPSG:4326", "geometry_type": "point", "sample_n": len(sample), "inventory_n": len(records)}


def load_all() -> dict:
    return {"DARTS_Peel_Plateau": load_darts_peel(), "QTP": load_qtp(), "North_Siberia": load_north_siberia()}
