"""Metric projection and area checks."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd

VENDOR = Path(r"E:\zuom\gu\RUNS\ROUND_20260828_01\RTS_SAME_PLACE_LIFECYCLE_BRIDGE\_vendor")
sys.path.insert(0, str(VENDOR))
from pyproj import Transformer
from shapely.ops import transform as shp_transform


def utm_zone(lon: float) -> int:
    return int((lon + 180) // 6) + 1


def area_m2(geom, region: str, source_crs: str) -> float:
    if geom is None or geom.is_empty:
        return np.nan
    if "Albers" in source_crs:
        return float(geom.area)
    c = geom.centroid
    zone = 32600 + utm_zone(float(c.x))
    tr = Transformer.from_crs(4326, zone, always_xy=True)
    return float(shp_transform(tr.transform, geom).area)


def add_areas(name: str, frame: dict) -> pd.DataFrame:
    rows = []
    for r in frame["records"]:
        g = r.get("geometry")
        rows.append({"region": name, "rts_id": str(r.get("rts_id", "")), "computed_geometry_area_m2": area_m2(g, name, frame.get("source_crs", "")), "reported_area_m2": r.get("rts_area_m2", r.get("Area", np.nan))})
    out = pd.DataFrame(rows)
    out["reported_area_m2"] = pd.to_numeric(out["reported_area_m2"], errors="coerce")
    out["area_unit_check"] = "PASS" if name != "North_Siberia" else "NOT_APPLICABLE_POINT_INVENTORY"
    return out
