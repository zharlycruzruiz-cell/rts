"""Frozen vegetation crosswalk for FORMAL_PIPELINE_V0_1.

Raw product labels/codes are not overwritten.  The unified class is a
separate field and UNKNOWN is retained when a code cannot be mapped.
"""
from pathlib import Path
import pandas as pd

RAW_LABELS = {
    0: "unknown", 20: "shrubland", 30: "herbaceous", 40: "cropland",
    50: "built_up", 60: "bare_sparse", 70: "snow_ice", 80: "water",
    90: "herbaceous_wetland", 100: "moss_lichen", 200: "sea", 255: "nodata",
}
FOREST_CODES = set(range(111, 127))


def cgls_unified(code: int) -> str:
    if code in FOREST_CODES:
        return "FOREST"
    if code == 20:
        return "SHRUB"
    if code == 30:
        return "GRASS_HERBACEOUS"
    if code == 90:
        return "WETLAND"
    if code == 100:
        return "MOSS_LICHEN"
    if code == 60:
        return "SPARSE_BARE"
    if code in (0, 255):
        return "UNKNOWN"
    return "OTHER"


def crosswalk_frame() -> pd.DataFrame:
    rows = []
    for code in sorted(set(RAW_LABELS) | FOREST_CODES):
        rows.append({
            "crosswalk_version": "VEGETATION_CROSSWALK_V1",
            "product": "CGLS_LC100_2019_v3.0.1",
            "raw_code": int(code),
            "raw_label": RAW_LABELS.get(code, f"forest_code_{code}"),
            "unified_class": cgls_unified(code),
            "mapping_basis": "fixed CGLS code rule; no result-driven merging",
        })
    # TP_LC10 labels used by the existing Beiluhe bridge are documented but
    # not used to create a test-region result in v0.1.
    for label, unified in [
        ("Alpine grassland", "GRASS_HERBACEOUS"),
        ("Alpine meadow", "MEADOW"),
        ("Wetland", "WETLAND"),
        ("Alpine scree", "SPARSE_BARE"),
    ]:
        rows.append({
            "crosswalk_version": "VEGETATION_CROSSWALK_V1",
            "product": "TP_LC10_2022",
            "raw_code": "",
            "raw_label": label,
            "unified_class": unified,
            "mapping_basis": "existing product label; Beiluhe not run in formal v0.1",
        })
    # CAVM labels are kept as an explicit second product layer.  They are
    # not substituted for CGLS classes in the v0.1 test and are therefore
    # safe to use later for tundra subtyping without rewriting V1.
    for label, unified in [
        ("shrub tundra", "SHRUB_TUNDRA"),
        ("graminoid tundra", "GRAMINOID_TUNDRA"),
        ("other tundra", "OTHER"),
        ("moss lichen", "MOSS_LICHEN"),
        ("wetland", "WETLAND"),
        ("sparse vegetation", "SPARSE_BARE"),
        ("bare ground", "SPARSE_BARE"),
        ("unknown", "UNKNOWN"),
    ]:
        rows.append({
            "crosswalk_version": "VEGETATION_CROSSWALK_V1",
            "product": "CAVM",
            "raw_code": "",
            "raw_label": label,
            "unified_class": unified,
            "mapping_basis": "fixed CAVM label rule; no result-driven merging",
        })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    out = Path(__file__).resolve().parent
    crosswalk_frame().to_csv(out / "VEGETATION_CROSSWALK_V1.csv", index=False)
