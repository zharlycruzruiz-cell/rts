"""Formal full-2023 DARTS Peel run under the frozen bbox/ring/crosswalk.

This run is deliberately independent of the 300-RTS audit frame.  It uses all
2023 level-2 features whose centroids fall in the clipped 2023 coverage domain,
and keeps non-vegetation ring support out of the vegetation denominator.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=RuntimeWarning)

HERE = Path(__file__).resolve().parent
ROUND = HERE.parent
V01 = ROUND / "FORMAL_RTS_COMMUNITY_ANALYSIS_V0_1"
V02 = ROUND / "FORMAL_RTS_COMMUNITY_ANALYSIS_V0_2"
V02CLIP = ROUND / "FORMAL_RTS_COMMUNITY_ANALYSIS_V0_2_BBOX_CLIP"
DATA = ROUND / "RTS_VEGETATION_COUPLING_BRIDGE_PUBLIC_RECHECK" / "public_sources" / "DARTS_v1_2"
CACHE = V02 / "cgls_tile_cache"
BBOX = (-136.0, 64.0, -120.0, 69.0)
NONVEG_CODES = {50, 70, 80, 200}  # built-up, snow/ice, water, sea
RAW_KNOWN_CODES = {20, 30, 40, 60, 90, 100} | set(range(111, 127))
UNIFIED = ["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE", "OTHER"]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


loader = load_module("v01_loader_full", V01 / "01_inventory_loader.py")
access = load_module("v02_access_full", V02 / "02_cgls_access.py")
gridmod = load_module("v02_grid_full", V02 / "03_background_grid.py")
area_mod = load_module("v01_area_full", V01 / "03_projection_area.py")

from pyproj import Transformer
from shapely.geometry import Point, box
from shapely.ops import transform as shp_transform, unary_union
from rasterio.features import rasterize


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def crosswalk():
    d = pd.read_csv(V02 / "VEGETATION_CROSSWALK_V1.csv")
    out = {}
    for _, r in d.iterrows():
        code = pd.to_numeric(r.get("raw_code"), errors="coerce")
        if pd.notna(code):
            out[int(code)] = (str(r.get("raw_label")), str(r.get("unified_class")))
    return out


def raw_label(code, cw):
    return cw.get(int(code), (f"unmapped_code_{int(code)}", "UNKNOWN"))[0]


def build_frame():
    """Load all 2023 features and clip only the analysis-domain coverage."""
    all_features = loader.read_gpkg(DATA / "features_level2.gpkg")
    bbox_geom = box(*BBOX)
    original_2023_n = sum(int(r.get("year")) == 2023 for r in all_features)
    bbox_features = [r for r in all_features if not r["geometry"].intersection(bbox_geom).is_empty]
    bbox_2023 = [r for r in bbox_features if int(r.get("year")) == 2023]

    coverage_rows = loader.read_gpkg(DATA / "coverage_level2.gpkg")
    coverage_parts = []
    for r in coverage_rows:
        if int(r.get("year")) != 2023:
            continue
        inter = r["geometry"].intersection(bbox_geom)
        if not inter.is_empty and inter.area > 0:
            coverage_parts.append(inter)
    if not coverage_parts:
        raise RuntimeError("No 2023 coverage intersects the frozen bbox")
    analysis_domain = unary_union(coverage_parts)

    records = []
    for r in bbox_2023:
        centroid = r["geometry"].centroid
        if analysis_domain.covers(centroid):
            q = dict(r)
            q.update({"dataset": "DARTS", "region": "DARTS_Peel_Plateau", "rts_id": str(r.get("id")), "source_year": 2023})
            records.append(q)
    exclusion = [r["geometry"] for r in bbox_features]
    frame = {
        "records": records,
        "exclusion": exclusion,
        "coverage": [analysis_domain],
        "source_crs": "EPSG:4326",
        "geometry_type": "polygon",
    }
    counts = {
        "original_2023_n": int(original_2023_n),
        "bbox_intersect_2023_n": int(len(bbox_2023)),
        "final_centroid_in_domain_n": int(len(records)),
        "bbox_all_year_rows_n": int(len(bbox_features)),
        "coverage_2023_intersect_parts_n": int(len(coverage_parts)),
    }
    return frame, analysis_domain, counts


def classify_counter(counter: Counter, cw):
    """Apply the frozen class logic, excluding explicit non-vegetation codes."""
    total = int(sum(counter.values()))
    nonveg_n = int(sum(counter.get(c, 0) for c in NONVEG_CODES))
    nodata_n = 0
    if total == 0:
        return {"community": "UNKNOWN", "total": 0, "nonveg_n": 0, "nonveg_fraction": np.nan, "land_valid_n": 0, "unknown_n": 0, "class_counts": Counter(), "modal_raw_code": "", "modal_raw_label": "", "modal_class_proportion": np.nan}
    if nonveg_n / total > 0.5:
        dom = counter.most_common(1)[0][0]
        return {"community": "EXCLUDED_NON_VEGETATION", "total": total, "nonveg_n": nonveg_n, "nonveg_fraction": nonveg_n / total, "land_valid_n": total - nonveg_n, "unknown_n": 0, "class_counts": Counter(), "modal_raw_code": int(dom), "modal_raw_label": raw_label(dom, cw), "modal_class_proportion": counter[dom] / total}
    land = Counter({int(c): int(n) for c, n in counter.items() if int(c) not in NONVEG_CODES})
    class_counts = Counter()
    unknown_n = 0
    for code, n in land.items():
        label, unified = cw.get(int(code), (f"unmapped_code_{int(code)}", "UNKNOWN"))
        if unified == "UNKNOWN":
            unknown_n += int(n)
        else:
            class_counts[unified] += int(n)
    if not class_counts:
        comm = "UNKNOWN" if unknown_n else "EXCLUDED_NON_VEGETATION"
    else:
        comm = class_counts.most_common(1)[0][0]
    dom = counter.most_common(1)[0][0]
    max_class_n = class_counts.get(comm, 0) if comm in class_counts else 0
    land_valid_n = int(total - nonveg_n)
    return {"community": comm, "total": total, "nonveg_n": nonveg_n, "nonveg_fraction": nonveg_n / total, "land_valid_n": land_valid_n, "unknown_n": int(unknown_n), "class_counts": class_counts, "modal_raw_code": int(dom), "modal_raw_label": raw_label(dom, cw), "modal_class_proportion": counter[dom] / total, "class_proportion": max_class_n / land_valid_n if land_valid_n else np.nan}


def extract_rts(frame, domain, cw):
    ring = gridmod.ring
    ring.TILE_CACHE = CACHE
    offsets, tile_counts = access.load_index()
    pixsets = [ring.pixel_set(ring.make_ring(r["geometry"], "DARTS_Peel_Plateau", 100, 500), frame["exclusion"], frame["coverage"]) for r in frame["records"]]
    code_map, missing = ring.assign_codes(pixsets, offsets, tile_counts)
    rows = []
    invalid_before = 0
    invalid_after = 0
    for r, pix in zip(frame["records"], pixsets):
        cnt = Counter(int(code_map[k]) for k in pix if k in code_map)
        info = classify_counter(cnt, cw)
        geom = r["geometry"]
        clipped = geom.intersection(domain)
        invalid_before += int(not geom.is_valid)
        invalid_after += int(not clipped.is_valid)
        area_clip = area_mod.area_m2(clipped, "DARTS_Peel_Plateau", "EPSG:4326") if not clipped.is_empty else np.nan
        reported = pd.to_numeric(pd.Series([r.get("area_m2")]), errors="coerce").iloc[0]
        rows.append({
            "rts_id": str(r["rts_id"]), "source_year": 2023, "centroid_lon": float(geom.centroid.x), "centroid_lat": float(geom.centroid.y),
            "community": info["community"], "raw_modal_code": info["modal_raw_code"], "raw_modal_label": info["modal_raw_label"],
            "modal_raw_proportion": info["modal_class_proportion"], "class_support_proportion_after_nonveg_filter": info.get("class_proportion", np.nan),
            "raw_valid_pixel_n": int(info["total"]), "ring_pixel_n": int(len(pix)), "nodata_or_undecoded_pixel_n": int(len(pix) - info["total"]),
            "nonvegetation_pixel_n": int(info["nonveg_n"]), "nonvegetation_fraction": info["nonveg_fraction"], "unmapped_land_pixel_n": int(info["unknown_n"]),
            "raw_code_counts_json": json.dumps({str(k): int(v) for k, v in sorted(cnt.items())}, sort_keys=True),
            "ring_inner_m": 100.0, "ring_outer_m": 500.0, "vegetation_product": "CGLS_LC100_2019_v3.0.1", "vegetation_year": 2019,
            "geometry_valid_before_clip": bool(geom.is_valid), "geometry_valid_after_clip": bool(clipped.is_valid),
            "rts_area_reported_m2": float(reported) if pd.notna(reported) else np.nan, "rts_area_in_domain_m2": float(area_clip) if pd.notna(area_clip) else np.nan,
            "area_clip_fraction_of_reported": float(area_clip / reported) if pd.notna(area_clip) and pd.notna(reported) and reported else np.nan,
        })
    return pd.DataFrame(rows), set(missing), {"invalid_before": invalid_before, "invalid_after": invalid_after}


def extract_grid_fast_raw(grid_df, frame, data, cov_mask, ex_mask, window, cw):
    """Vectorized 500 m grid extraction, preserving raw-code group counts."""
    r0, r1, c0, c1 = window
    classes = np.array(["FOREST", "SHRUB", "GRASS_HERBACEOUS", "WETLAND", "MOSS_LICHEN", "SPARSE_BARE", "OTHER"], dtype=object)
    result = []
    ring = gridmod.ring
    for _, row_group in grid_df.groupby("grid_iy", sort=True):
        zones = ((row_group["center_lon"].astype(float) + 180.0) // 6.0 + 1).astype(int) + 32600
        for zone, sub in row_group.groupby(zones):
            sub = sub.copy()
            lat_min = float(sub["center_lat"].min())
            dlat_m = 111320.0 * ring.SCALE
            dlon_m = dlat_m * max(math.cos(math.radians(lat_min)), 0.01)
            dr = np.arange(-int(math.ceil(500.0 / dlat_m)) - 3, int(math.ceil(500.0 / dlat_m)) + 4)
            dc = np.arange(-int(math.ceil(500.0 / dlon_m)) - 3, int(math.ceil(500.0 / dlon_m)) + 4)
            drr, dcc = np.meshgrid(dr, dc, indexing="ij")
            odr, odc = drr.ravel().astype(int), dcc.ravel().astype(int)
            cg = np.floor((sub["center_lon"].to_numpy(dtype=float) + 180.0) / ring.SCALE).astype(int) - c0
            rg = np.floor((80.0 - sub["center_lat"].to_numpy(dtype=float)) / ring.SCALE).astype(int) - r0
            rr = rg[:, None] + odr[None, :]
            cc = cg[:, None] + odc[None, :]
            inside = (rr >= 0) & (rr < data.shape[0]) & (cc >= 0) & (cc < data.shape[1])
            rr_safe = np.clip(rr, 0, data.shape[0] - 1)
            cc_safe = np.clip(cc, 0, data.shape[1] - 1)
            vals = data[rr_safe, cc_safe]
            tr = Transformer.from_crs(4326, int(zone), always_xy=True)
            cx, cy = tr.transform(sub["center_lon"].to_numpy(dtype=float), sub["center_lat"].to_numpy(dtype=float))
            pix_lon = -180.0 + (cc_safe + c0 + 0.5) * ring.SCALE
            pix_lat = 80.0 - (rr_safe + r0 + 0.5) * ring.SCALE
            px, py = tr.transform(pix_lon.ravel(), pix_lat.ravel())
            px = np.asarray(px).reshape(pix_lon.shape); py = np.asarray(py).reshape(pix_lat.shape)
            dist2 = (px - np.asarray(cx)[:, None]) ** 2 + (py - np.asarray(cy)[:, None]) ** 2
            ring_keep = (dist2 <= 500.0 ** 2) & (dist2 > 100.0 ** 2)
            geo = inside & ring_keep & cov_mask[rr_safe, cc_safe] & ~ex_mask[rr_safe, cc_safe]
            valid = geo & (vals != 0) & (vals != 255)
            nvalid = valid.sum(axis=1).astype(int)
            nonveg = (valid & ((vals == 50) | (vals == 70) | (vals == 80) | (vals == 200))).sum(axis=1).astype(int)
            forest = (valid & (vals >= 111) & (vals <= 126)).sum(axis=1).astype(int)
            shrub = (valid & (vals == 20)).sum(axis=1).astype(int)
            grass = (valid & (vals == 30)).sum(axis=1).astype(int)
            wetland = (valid & (vals == 90)).sum(axis=1).astype(int)
            moss = (valid & (vals == 100)).sum(axis=1).astype(int)
            sparse = (valid & (vals == 60)).sum(axis=1).astype(int)
            cropland = (valid & (vals == 40)).sum(axis=1).astype(int)
            known_land = np.column_stack([forest, shrub, grass, wetland, moss, sparse, cropland])
            known_land_total = known_land.sum(axis=1).astype(int)
            unknown_land = np.maximum(nvalid - nonveg - known_land_total, 0).astype(int)
            land_valid = (nvalid - nonveg).astype(int)
            winner = known_land.argmax(axis=1)
            max_known = known_land[np.arange(len(sub)), winner]
            comm = classes[winner].astype(object)
            comm[(nvalid == 0)] = "NO_DATA_SUPPORT"
            comm[(nvalid > 0) & (nonveg * 2 > nvalid)] = "EXCLUDED_NON_VEGETATION"
            comm[(nvalid > 0) & (nonveg * 2 <= nvalid) & (known_land_total == 0) & (unknown_land > 0)] = "UNKNOWN"
            # In CGLS V1 code 40 is the only effective OTHER source in this
            # product; it is included after explicit non-vegetation removal.
            comm[(nvalid > 0) & (nonveg * 2 <= nvalid) & (known_land_total > 0) & (winner == 6)] = "OTHER"
            df = sub.copy()
            df["community"] = comm
            df["raw_valid_pixel_n"] = nvalid
            df["ring_pixel_n"] = geo.sum(axis=1).astype(int)
            df["nodata_or_undecoded_pixel_n"] = (geo & ~valid).sum(axis=1).astype(int)
            df["nonvegetation_pixel_n"] = nonveg
            df["nonvegetation_fraction"] = np.where(nvalid > 0, nonveg / nvalid, np.nan)
            df["unmapped_land_pixel_n"] = unknown_land
            df["class_support_proportion_after_nonveg_filter"] = np.where(land_valid > 0, max_known / land_valid, np.nan)
            df["support_status"] = np.where(nvalid == 0, "NO_DATA_SUPPORT", np.where((geo & ~valid).sum(axis=1) > 0, "PARTIAL_NODATA", "VALID"))
            df["ring_inner_m"] = 100.0; df["ring_outer_m"] = 500.0
            df["vegetation_product"] = "CGLS_LC100_2019_v3.0.1"; df["vegetation_year"] = 2019
            result.append(df)
    return pd.concat(result, ignore_index=True) if result else pd.DataFrame()


def fmt(x):
    return "NA" if pd.isna(x) else f"{float(x):,.6f}"


def main():
    frame, domain, counts = build_frame()
    if len(frame["records"]) != counts["final_centroid_in_domain_n"]:
        raise RuntimeError("Frame count mismatch")
    cw = crosswalk()
    rts, rts_missing, rts_geom_qc = extract_rts(frame, domain, cw)
    if len(rts) != len(frame["records"]):
        raise RuntimeError(f"RTS assignment count mismatch: {len(rts)} vs {len(frame['records'])}")
    if rts["rts_id"].duplicated().any():
        raise RuntimeError("Duplicate final RTS IDs")

    grid_df, projected_domain_area_m2, grid_crs = gridmod.coverage_grid(frame, spacing_m=500.0)
    data, cov_mask, ex_mask, window, grid_missing = gridmod.assemble_crop(frame, CACHE)
    if grid_missing:
        raise RuntimeError(f"Missing cached CGLS tiles: {sorted(grid_missing)}")
    background = extract_grid_fast_raw(grid_df, frame, data, cov_mask, ex_mask, window, cw)
    if background["grid_id"].duplicated().any():
        raise RuntimeError("Duplicate background grid IDs")
    grid_weight_m2 = float(background["coverage_intersection_area_m2"].sum())

    valid_classes = set(UNIFIED)
    rts["effective_for_burden"] = rts["community"].isin(valid_classes)
    effective_rts = rts[rts["effective_for_burden"]].copy()
    bg_summary = []
    for comm in UNIFIED + ["EXCLUDED_NON_VEGETATION", "NO_DATA_SUPPORT", "UNKNOWN"]:
        mask = background["community"].eq(comm)
        bg_summary.append({
            "community": comm, "background_grid_N": int(mask.sum()),
            "background_area_m2": float(background.loc[mask, "coverage_intersection_area_m2"].sum()),
            "background_area_share_of_analysis_domain": float(background.loc[mask, "coverage_intersection_area_m2"].sum() / grid_weight_m2) if grid_weight_m2 else np.nan,
        })
    bg_summary_df = pd.DataFrame(bg_summary)
    effective_bg = bg_summary_df[bg_summary_df["community"].isin(UNIFIED)].copy()
    total_effective_bg = float(effective_bg["background_area_m2"].sum())
    total_effective_rts = int(len(effective_rts))
    results = []
    for comm in UNIFIED + ["EXCLUDED_NON_VEGETATION", "NO_DATA_SUPPORT", "UNKNOWN"]:
        rr = effective_rts[effective_rts["community"].eq(comm)]
        br = bg_summary_df[bg_summary_df["community"].eq(comm)].iloc[0]
        n = int(len(rr)); bg_area = float(br["background_area_m2"]); area_sum = float(rr["rts_area_in_domain_m2"].sum(skipna=True))
        n_share = n / total_effective_rts if comm in UNIFIED and total_effective_rts else np.nan
        bg_share = bg_area / total_effective_bg if comm in UNIFIED and total_effective_bg else np.nan
        results.append({
            "community": comm, "RTS_N": n, "RTS_count_share": n_share, "RTS_total_area_m2": area_sum,
            "median_RTS_area_m2": float(rr["rts_area_in_domain_m2"].median()) if n else np.nan,
            "mean_RTS_area_m2": float(rr["rts_area_in_domain_m2"].mean()) if n else np.nan,
            "background_grid_N": int(br["background_grid_N"]), "background_area_m2": bg_area,
            "background_area_share": bg_share, "R_count": (n_share / bg_share) if pd.notna(n_share) and pd.notna(bg_share) and bg_share else np.nan,
            "R_area": (area_sum / bg_area) if bg_area else np.nan,
            "denominator_scope": "effective land vegetation classes only; non-vegetation and nodata reported separately",
        })
    results_df = pd.DataFrame(results)

    # 300-sample comparison is deliberately a read-only comparison to the
    # existing strict-bbox audit output, not a calibration or replacement.
    old = pd.read_csv(V02CLIP / "BBOX_CLIP_R_COUNT.csv").rename(columns={"R_count_bbox_clip": "R_count_300"})
    sample_compare = old[["community", "R_count_300"]].copy()
    sample_compare = sample_compare.merge(results_df[["community", "R_count"]].rename(columns={"R_count": "R_count_full"}), on="community", how="outer")
    sample_compare["difference"] = sample_compare["R_count_full"] - sample_compare["R_count_300"]
    sample_compare["comparison_note"] = "300 = existing strict-bbox audit; full = all eligible 2023 RTS with explicit non-vegetation exclusion"

    # QC rows are terminal diagnostics; they do not feed the calculations.
    unknown_rts = int((~rts["effective_for_burden"] & ~rts["community"].eq("EXCLUDED_NON_VEGETATION")).sum())
    nonveg_rts = int(rts["community"].eq("EXCLUDED_NON_VEGETATION").sum())
    unknown_bg_area = float(bg_summary_df.loc[bg_summary_df["community"].isin(["NO_DATA_SUPPORT", "UNKNOWN"]), "background_area_m2"].sum())
    nonveg_bg_area = float(bg_summary_df.loc[bg_summary_df["community"].eq("EXCLUDED_NON_VEGETATION"), "background_area_m2"].sum())
    background_partition_difference = float(grid_weight_m2 - bg_summary_df["background_area_m2"].sum())
    qrows = [
        {"check": "original_2023_rts_global", "value": counts["original_2023_n"], "status": "PASS", "detail": "all DARTS level2 features with year=2023"},
        {"check": "bbox_intersect_2023", "value": counts["bbox_intersect_2023_n"], "status": "PASS", "detail": "geometric intersection with frozen bbox"},
        {"check": "centroid_in_analysis_domain", "value": counts["final_centroid_in_domain_n"], "status": "PASS", "detail": "centroid covered by 2023 coverage clipped to bbox"},
        {"check": "analysis_domain_crs", "value": grid_crs, "status": "PASS", "detail": "equal-area EPSG:6933 for grid weights; source geometries EPSG:4326"},
        {"check": "analysis_domain_area_m2", "value": projected_domain_area_m2, "status": "PASS", "detail": "projected union of 2023 coverage intersected with bbox"},
        {"check": "grid_weight_area_m2", "value": grid_weight_m2, "status": "PASS" if abs(grid_weight_m2-projected_domain_area_m2)/projected_domain_area_m2 < 0.001 else "FAIL", "detail": "sum of coverage-intersection grid weights"},
        {"check": "grid_domain_difference_fraction", "value": (grid_weight_m2-projected_domain_area_m2)/projected_domain_area_m2, "status": "PASS" if abs(grid_weight_m2-projected_domain_area_m2)/projected_domain_area_m2 < 0.001 else "FAIL", "detail": "grid approximation vs projected domain"},
        {"check": "rts_background_same_analysis_domain", "value": "YES", "status": "PASS", "detail": "both RTS ring pixels and background grid rings use the same clipped 2023 coverage domain"},
        {"check": "rts_background_same_classification_logic", "value": "YES", "status": "PASS", "detail": "shared explicit non-vegetation exclusion and VEGETATION_CROSSWALK_V1 mapping"},
        {"check": "background_area_partition_difference_m2", "value": background_partition_difference, "status": "PASS" if abs(background_partition_difference) < 1.0 else "FAIL", "detail": "effective classes plus excluded/non-data partitions equal grid-weight total"},
        {"check": "duplicate_rts_id", "value": int(rts["rts_id"].duplicated().sum()), "status": "PASS" if not rts["rts_id"].duplicated().any() else "FAIL", "detail": "final assignments"},
        {"check": "invalid_rts_geometry_before_clip", "value": rts_geom_qc["invalid_before"], "status": "PASS" if rts_geom_qc["invalid_before"] == 0 else "CHECK_REQUIRED", "detail": "raw 2023 final RTS geometries"},
        {"check": "invalid_rts_geometry_after_clip", "value": rts_geom_qc["invalid_after"], "status": "PASS" if rts_geom_qc["invalid_after"] == 0 else "CHECK_REQUIRED", "detail": "RTS geometry intersected with analysis domain"},
        {"check": "cgls_missing_rts_tiles", "value": len(rts_missing), "status": "PASS" if not rts_missing else "FAIL", "detail": "existing cache only; no download"},
        {"check": "cgls_missing_grid_tiles", "value": len(grid_missing), "status": "PASS" if not grid_missing else "FAIL", "detail": "existing cache only; no download"},
        {"check": "nonvegetation_rts_excluded", "value": nonveg_rts, "status": "PASS", "detail": "codes 50/70/80/200 not assigned to vegetation or OTHER"},
        {"check": "nonvegetation_background_area_m2", "value": nonveg_bg_area, "status": "PASS", "detail": "excluded from formal vegetation denominator"},
        {"check": "unknown_rts_n", "value": unknown_rts, "status": "PASS", "detail": "UNKNOWN/nodata retained outside burden denominator"},
        {"check": "unknown_background_area_m2", "value": unknown_bg_area, "status": "PASS", "detail": "NO_DATA_SUPPORT/UNKNOWN retained outside burden denominator"},
        {"check": "ring_area_used_as_denominator", "value": "NO", "status": "PASS", "detail": "independent 500m coverage-grid area only"},
        {"check": "crosswalk_version", "value": "VEGETATION_CROSSWALK_V1", "status": "PASS", "detail": "byte copied from v0.2; no edits"},
    ]
    qc_df = pd.DataFrame(qrows)
    status = "PEEL_FULL_FORMAL_READY_FOR_INDEPENDENT_AUDIT" if not (qc_df["status"] == "FAIL").any() else "PEEL_FULL_FORMAL_BLOCKED"

    # Outputs
    results_df.to_csv(HERE / "PEEL_FORMAL_FULL_RESULTS.csv", index=False)
    qc_df.to_csv(HERE / "PEEL_FORMAL_FULL_QC.csv", index=False)
    rts.to_csv(HERE / "PEEL_RTS_ASSIGNMENTS_FULL.csv", index=False)
    bg_summary_df.to_csv(HERE / "PEEL_BACKGROUND_AREA_FULL.csv", index=False)
    sample_compare.to_csv(HERE / "PEEL_SAMPLE_VS_FULL.csv", index=False)

    config = {
        "pipeline": "PEEL_FORMAL_FULL_2023_V1", "seed": 20260907, "bbox_west": -136.0, "bbox_east": -120.0, "bbox_south": 64.0, "bbox_north": 69.0,
        "analysis_domain": "DARTS coverage_level2 year=2023 intersect bbox", "rts_inclusion": "2023 feature centroid covered by analysis domain", "rts_frame": "all eligible 2023 DARTS level2 features; no sampling",
        "ring_inner_m": 100, "ring_outer_m": 500, "background_grid_spacing_m": 500, "background_grid_crs": "EPSG:6933", "cgls_product": "CGLS LC100 2019 v3.0.1", "crosswalk": "VEGETATION_CROSSWALK_V1",
        "nonvegetation_raw_codes_excluded": {50: "built_up", 70: "snow_ice", 80: "water", 200: "sea"}, "historical_exclusion": "all level2 features geometrically intersecting bbox, all years", "area_unit": "m2", "status": status,
    }
    (HERE / "FORMAL_CONFIG.yaml").write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    hash_paths = [DATA / "features_level2.gpkg", DATA / "coverage_level2.gpkg", DATA / "features_level2_description.csv", DATA / "README.md", V02 / "VEGETATION_CROSSWALK_V1.csv", Path(__file__), V01 / "01_inventory_loader.py", V01 / "03_projection_area.py", V01 / "05_background_ring.py", V02 / "02_cgls_access.py", V02 / "03_background_grid.py"]
    hash_rows = []
    for p in hash_paths:
        if p.exists(): hash_rows.append({"path": str(p), "sha256": sha256(p), "size_bytes": p.stat().st_size})
    # Hash only the tiles actually needed by this run, using the frozen index.
    crop_tiles, _ = gridmod.tile_ids_for_crop(frame)
    for ti in sorted(crop_tiles):
        p = CACHE / f"tile_{int(ti):07d}.bin"
        if p.exists(): hash_rows.append({"path": str(p), "sha256": sha256(p), "size_bytes": p.stat().st_size})
    pd.DataFrame(hash_rows).to_csv(HERE / "INPUT_HASHES.csv", index=False)

    class_lines = results_df.to_string(index=False)
    qc_lines = qc_df.to_string(index=False)
    sample_lines = sample_compare[sample_compare["community"].isin(["SHRUB", "GRASS_HERBACEOUS", "FOREST"])].to_string(index=False)
    report = [
        "# PEEL_FORMAL_FULL_2023_V1", "",
        f"Status: **{status}**", "", "## Frozen scope", "",
        "DARTS Peel only. Bbox = (-136, -120, 64, 69). Analysis domain = 2023 DARTS coverage intersected with this bbox. All 2023 level-2 features whose centroid is in that domain were used; no sampling, climate, NDVI or mechanism variables.", "",
        f"Global DARTS 2023 features: {counts['original_2023_n']:,}; bbox-intersecting 2023 features: {counts['bbox_intersect_2023_n']:,}; final centroid-in-domain RTS: {counts['final_centroid_in_domain_n']:,}.", "",
        "## Classification and denominator", "",
        "RTS and independent 500 m background grids use the same CGLS LC100 2019 product, 100–500 m ring, historical RTS exclusion and VEGETATION_CROSSWALK_V1. Raw codes 50, 70, 80 and 200 are classified as EXCLUDED_NON_VEGETATION and cannot enter a vegetation class or OTHER. Code 40 remains OTHER under the frozen crosswalk.", "",
        f"The background grid has {len(background):,} cells. Coverage-grid weight = {grid_weight_m2:,.3f} m2; projected analysis-domain area = {projected_domain_area_m2:,.3f} m2; relative difference = {(grid_weight_m2-projected_domain_area_m2)/projected_domain_area_m2:.6%}. RTS ring area is not used as a landscape denominator.", "",
        "## Full formal results", "", class_lines, "",
        "## QC", "", qc_lines, "",
        "## 300-sample audit comparison", "", sample_lines, "",
        "The 300-sample values are the pre-existing strict-bbox audit reference. They are not used to calibrate the full result. Differences reflect the full 2023 frame and the explicit non-vegetation exclusion.", "",
        "## Scope boundary", "",
        "This is a formal data and burden calculation for DARTS Peel 2023 only. It does not establish causal effects or explain mechanisms.",
    ]
    (HERE / "PEEL_FORMAL_FULL_REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    (HERE / "RUN_STATE.md").write_text("\n".join(["ARTIFACT_STATUS：COMPLETE", "PIPELINE：PEEL_FORMAL_FULL_2023_V1", f"STATUS：{status}", f"RTS_GLOBAL_2023_N：{counts['original_2023_n']}", f"RTS_BBOX_INTERSECT_2023_N：{counts['bbox_intersect_2023_n']}", f"RTS_FINAL_CENTROID_IN_DOMAIN_N：{counts['final_centroid_in_domain_n']}", "NEXT_ACTION：INDEPENDENT_AUDIT_REQUIRED"]) + "\n", encoding="utf-8")

    print(results_df.to_string(index=False))
    print(qc_df.to_string(index=False))


if __name__ == "__main__":
    main()
