import json, time, sys
from pathlib import Path
from collections import Counter
import numpy as np, pandas as pd, rasterio
from rasterio.windows import Window
from pyproj import Transformer
from shapely.ops import unary_union
import run_ring_sensitivity as R

OUT=R.OUT; RES=R.RES; IDS=R.IDS; CATS=R.CATS
BASE=R.ROUND/'RTS_TUNDRA13_FULL_REANALYSIS_V1'
LOCO_TOL=1e-6

def extract_all():
    covs=R.coverage_geometries(); feats=R.read_geometry_sources(); objs={}; bgs={}; t0=time.time()
    qdf=pd.read_csv(R.QFILE,compression='gzip',usecols=['coverage_id','grid_id','community']); qdf=qdf[qdf.coverage_id.isin(IDS)]
    q_by={cid:g[['grid_id','community']].copy().rename(columns={'community':'community_q_100_500'}) for cid,g in qdf.groupby('coverage_id')}; del qdf
    with rasterio.open(R.TIF) as src:
      for cid in IDS:
        print('outer_extract_start',cid,flush=True)
        bg_done=RES/f'{cid}_BACKGROUND_500_900.csv'; obj_done=RES/f'{cid}_OBJECT_CROSSWALK.csv'; objraw_done=RES/f'{cid}_OBJECTS_500_900.csv'
        if bg_done.exists() and obj_done.exists() and objraw_done.exists():
          oo=pd.read_csv(obj_done); oo['rts_id']=oo.rts_id.astype(str)
          coords=pd.read_csv(R.source_file(cid,'RTS_ASSIGNMENTS'),usecols=['rts_id','centroid_lon','centroid_lat']); coords['rts_id']=coords.rts_id.astype(str)
          oo=oo.merge(coords,on='rts_id',how='left',validate='one_to_one')
          oo['old_sixclass']=oo.community_100_500.isin(R.CATS); oo['new_sixclass']=oo.community_500_900.isin(R.CATS)
          objs[cid]=oo; bgs[cid]=bg_done; print('outer_extract_checkpoint_reused',cid,flush=True); continue
        ar=pd.read_csv(R.source_file(cid,'RTS_ASSIGNMENTS')); bg=pd.read_csv(R.source_file(cid,'BACKGROUND_GRID'))
        features=[f for f in feats if int(f.get('year',0))==2023 and covs[cid].contains(f['geometry'].centroid)]
        byid={str(f.get('id')):f for f in features}
        if set(ar.rts_id.astype(str))!=set(byid): raise RuntimeError(f'object ID mismatch {cid}')
        exlist=[f['geometry'] for f in feats if not f['geometry'].intersection(covs[cid]).is_empty]; exgeom=unary_union(exlist)
        data,cm,em,win=R.crop(covs[cid],exlist,src)
        b=R.extract_grid(bg,data,cm,em,win,*R.RING_NEW)
        q=R.extract_grid(bg,data,cm,None,win,*R.RING_NEW)
        b=b.rename(columns={'community':'community_B_500_900','ring_pixel_n':'ring_pixel_n_B_500_900','raw_valid_pixel_n':'valid_pixel_n_B_500_900','nodata_pixel_n':'nodata_pixel_n_B_500_900','nonvegetation_pixel_n':'nonveg_pixel_n_B_500_900','other_pixel_n':'other_pixel_n_B_500_900'})
        q=q.rename(columns={'community':'community_q_500_900','ring_pixel_n':'ring_pixel_n_q_500_900','raw_valid_pixel_n':'valid_pixel_n_q_500_900','nodata_pixel_n':'nodata_pixel_n_q_500_900','nonvegetation_pixel_n':'nonveg_pixel_n_q_500_900','other_pixel_n':'other_pixel_n_q_500_900'})
        delq=q_by[cid]
        z=bg[['grid_id','grid_ix','grid_iy','center_lon','center_lat','coverage_intersection_area_m2','community','ring_pixel_n']].rename(columns={'community':'community_B_100_500','ring_pixel_n':'ring_pixel_n_B_100_500'}).merge(delq,on='grid_id',how='left',validate='one_to_one').merge(b,on=['grid_id','grid_ix','grid_iy','center_lon','center_lat','coverage_intersection_area_m2'],how='left',validate='one_to_one').merge(q[['grid_id','community_q_500_900','ring_pixel_n_q_500_900','valid_pixel_n_q_500_900','nodata_pixel_n_q_500_900','nonveg_pixel_n_q_500_900','other_pixel_n_q_500_900']],on='grid_id',how='left',validate='one_to_one')
        zp=bg_done; z.to_csv(zp,index=False); bgs[cid]=zp
        out=[]
        for a in ar.itertuples(index=False):
          g=byid[str(a.rts_id)]['geometry']; rr,cc=R.object_pixels(g,covs[cid],exgeom,*R.RING_NEW)
          if len(rr):
            r0,r1=int(rr.min()),int(rr.max()); c0,c1=int(cc.min()),int(cc.max()); arr=src.read(1,window=Window(c0,r0,c1-c0+1,r1-r0+1),boundless=True,fill_value=255); raw=arr[rr-r0,cc-c0]
          else: raw=np.array([],dtype=np.uint8)
          comm,nvalid,nnon,ninvalid=R.modal(raw)
          out.append({'rts_id':str(a.rts_id),'community_500_900':comm,'ring_pixel_n_500_900':len(rr),'valid_pixel_n_500_900':nvalid,'nonvegetation_pixel_n_500_900':nnon,'invalid_pixel_n_500_900':ninvalid})
        nd=pd.DataFrame(out); old=ar[['rts_id','community','centroid_lon','centroid_lat']].copy(); old['rts_id']=old.rts_id.astype(str); o=old.rename(columns={'community':'community_100_500'}).merge(nd,on='rts_id',validate='one_to_one')
        o['old_sixclass']=o.community_100_500.isin(CATS); o['new_sixclass']=o.community_500_900.isin(CATS)
        o.to_csv(obj_done,index=False); nd.to_csv(objraw_done,index=False); objs[cid]=o
        print('outer_extract_done',cid,'anchors',len(z),'objects',len(o),'elapsed_s',round(time.time()-t0,1),flush=True)
    return objs,bgs

def fit(q,y):
    from scipy.optimize import minimize
    from scipy.special import logsumexp
    q=np.asarray(q,float); y=np.asarray(y,float); n=y.sum(1); keep=(n>0)&(q.sum(1)>0); q=q[keep]; y=y[keep]; n=n[keep]
    if len(n)<2 or np.any((q==0)&(y>0)): raise RuntimeError('nonestimable fold')
    obs=y/n[:,None]; lq=np.full_like(q,-np.inf); np.log(q,out=lq,where=q>0); w=np.ones(len(n))/len(n)
    def fg(x):
      b=np.zeros(6); b[R.FREE]=x; z=lq+b[None,:]; lp=z-logsumexp(z,axis=1,keepdims=True); p=np.exp(lp); loss=-np.sum(w[:,None]*obs*np.where(obs>0,lp,0)); grad=np.sum(w[:,None]*(p-obs),axis=0)[R.FREE]; return float(loss),grad
    res=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':1000}); b=np.zeros(6); b[R.FREE]=res.x; loss,grad=fg(res.x)
    if np.max(np.abs(grad))>2e-6: raise RuntimeError('convergence gate')
    return b
def pred(q,b):
    from scipy.special import logsumexp
    z=np.full(6,-np.inf); np.log(q,out=z,where=q>0); z+=b; return np.exp(z-logsumexp(z))
def tv(a,b): return .5*np.abs(np.asarray(a)-np.asarray(b)).sum()

def load_cached_extractions():
    """Load completed per-object/per-anchor ring assignments without opening the raster."""
    objs={}; bgs={}
    for cid in IDS:
      p=RES/f'{cid}_OBJECT_CROSSWALK.csv'
      bp=RES/f'{cid}_BACKGROUND_500_900.csv'
      if not p.exists() or not bp.exists(): raise RuntimeError(f'missing completed extraction checkpoint {cid}')
      o=pd.read_csv(p); o['rts_id']=o.rts_id.astype(str)
      if 'centroid_lon' not in o or 'centroid_lat' not in o:
        coords=pd.read_csv(R.source_file(cid,'RTS_ASSIGNMENTS'),usecols=['rts_id','centroid_lon','centroid_lat']); coords['rts_id']=coords.rts_id.astype(str)
        o=o.merge(coords,on='rts_id',how='left',validate='one_to_one')
      if o[['centroid_lon','centroid_lat']].isna().any().any(): raise RuntimeError(f'missing object coordinates {cid}')
      o['old_sixclass']=o.community_100_500.isin(CATS); o['new_sixclass']=o.community_500_900.isin(CATS)
      objs[cid]=o; bgs[cid]=bp
    return objs,bgs

def validate_frozen_baseline(objs,bgs):
    """Hard gate the old-ring object/q inputs and 13-fold LOCO against formal 13-region outputs."""
    formal_q=pd.read_csv(BASE/'results'/'TUNDRA13_BACKGROUND_BLIND_Q.csv').set_index('coverage_id')
    formal_loco=pd.read_csv(BASE/'results'/'TUNDRA13_LOCO_FOLDS.csv').set_index('coverage_id')
    metrics=[]; yrows=[]; qrows=[]
    for cid in IDS:
      old=objs[cid]
      src=pd.read_csv(R.source_file(cid,'RTS_ASSIGNMENTS'),usecols=['rts_id','community']); src['rts_id']=src.rts_id.astype(str)
      if src.rts_id.duplicated().any() or old.rts_id.duplicated().any() or set(src.rts_id)!=set(old.rts_id):
        raise RuntimeError(f'formal object ID mismatch: {cid}')
      sy=src[src.community.isin(CATS)].community.value_counts().reindex(CATS,fill_value=0).to_numpy(int)
      oy=old.loc[old.old_sixclass,'community_100_500'].value_counts().reindex(CATS,fill_value=0).to_numpy(int)
      if not np.array_equal(sy,oy): raise RuntimeError(f'old-ring class counts differ from formal input: {cid}; {oy} != {sy}')
      if int(oy.sum())!=int(old.old_sixclass.sum()): raise RuntimeError(f'old-ring selected object count does not equal six-class counts: {cid}')
      yrows.append(oy)
      bg=pd.read_csv(bgs[cid],usecols=['community_q_100_500','coverage_intersection_area_m2'])
      valid=bg.community_q_100_500.isin(CATS)
      area=bg.loc[valid].groupby('community_q_100_500').coverage_intersection_area_m2.sum().reindex(CATS,fill_value=0).to_numpy(float)
      q=area/area.sum(); qrows.append(q)
      target=formal_q.loc[cid,[f'q_{c}' for c in CATS]].to_numpy(float)
      qerr=float(np.max(np.abs(q-target)))
      if qerr>1e-10: raise RuntimeError(f'old-ring q differs from formal blind q: {cid}; max_abs_diff={qerr}')
      metrics.append({'coverage_id':cid,'old_object_n':int(oy.sum()),'max_abs_q_share_diff':qerr,'old_class_counts_match_formal':True,'q_matches_formal':True})
    ymat=np.asarray(yrows,float); qmat=np.asarray(qrows,float)
    if int(ymat.sum())!=11189: raise RuntimeError(f'formal old-ring six-class n must be 11189, got {int(ymat.sum())}')
    baseline=[]
    for t,cid in enumerate(IDS):
      train=np.arange(len(IDS))!=t; beta=fit(qmat[train],ymat[train]); p=pred(qmat[t],beta)
      obs=ymat[t]/ymat[t].sum(); ta=tv(obs,qmat[t]); ts=tv(obs,p); g=(ta-ts)/ta if ta else np.nan
      ref=formal_loco.loc[cid]
      check={'object_n':(int(ymat[t].sum()),int(ref.heldout_RTS_n)), 'TV_area':(ta,float(ref.TV_area)), 'TV_shared':(ts,float(ref.TV_shared)), 'G':(g,float(ref.G_shared_reconstruction))}
      for name,(got,want) in check.items():
        if abs(got-want)>LOCO_TOL: raise RuntimeError(f'formal LOCO baseline mismatch {cid} {name}: {got} != {want} (tol={LOCO_TOL})')
      baseline.append({'coverage_id':cid,'object_n':int(ymat[t].sum()),'TV_area':ta,'TV_shared':ts,'G':g,'formal_TV_area':float(ref.TV_area),'formal_TV_shared':float(ref.TV_shared),'formal_G':float(ref.G_shared_reconstruction),'max_abs_LOCO_diff':max(abs(ta-ref.TV_area),abs(ts-ref.TV_shared),abs(g-ref.G_shared_reconstruction))})
    gate={'status':'PASS','old_ring_object_n':int(ymat.sum()),'q_max_abs_diff':max(x['max_abs_q_share_diff'] for x in metrics),'loco_tolerance':LOCO_TOL,'loco_max_abs_diff':max(x['max_abs_LOCO_diff'] for x in baseline),'coverage_checks':metrics,'loco_checks':baseline}
    (RES/'FORMAL_BASELINE_REPRODUCTION_GATE.json').write_text(json.dumps(gate,indent=2),encoding='utf-8')
    return gate

def validate_formal_rcount(desc):
    ref=pd.read_csv(BASE/'results'/'TUNDRA13_RCOUNT_ALL_CLASSES.csv')
    ref=ref[ref.coverage_id.isin(IDS)].copy()
    actual=pd.DataFrame(desc)
    actual=actual[(actual['support']=='ALL_RULES')&(actual['ring']=='100_500')][['coverage_id','class','object_n','object_share','B_area_share','R_count_B']]
    joined=actual.merge(ref,left_on=['coverage_id','class'],right_on=['coverage_id','vegetation'],how='outer',indicator=True,validate='one_to_one')
    if len(joined)!=13*len(CATS) or not joined._merge.eq('both').all(): raise RuntimeError('formal R_count rows/classes mismatch')
    checks=[]
    for r in joined.itertuples(index=False):
      if int(r.object_n)!=int(r.RTS_n): raise RuntimeError(f'formal R_count object count mismatch {r.coverage_id} {r._1}')
      pairs=[('object_share',r.object_share,r.RTS_share),('B_area_share',r.B_area_share,r.background_fraction),('R_count_B',r.R_count_B,r.R_count)]
      diffs=[]
      for name,got,want in pairs:
        if pd.isna(got) and pd.isna(want): diff=0.0
        elif pd.isna(got) or pd.isna(want): raise RuntimeError(f'formal R_count {name} missingness mismatch {r.coverage_id} {r.vegetation}')
        else: diff=abs(float(got)-float(want))
        if diff>LOCO_TOL: raise RuntimeError(f'formal R_count {name} mismatch {r.coverage_id} {r.vegetation}: {got} != {want}')
        diffs.append(diff)
      checks.append({'coverage_id':r.coverage_id,'class':r.vegetation,'RTS_n':int(r.RTS_n),'max_abs_diff':max(diffs)})
    result={'status':'PASS','row_n':len(checks),'tolerance':LOCO_TOL,'max_abs_diff':max(x['max_abs_diff'] for x in checks),'checks':checks}
    (RES/'FORMAL_RCOUNT_REPRODUCTION_GATE.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def summarize(objs,bgs):
    # point LOCO and per-class table for full-rule and paired common support.
    baseline_gate=validate_frozen_baseline(objs,bgs)
    folds=[]; assign=[]; desc=[]; boot_summaries=[]
    for support in ['ALL_RULES','COMMON_OBJECTS']:
      for ring in ['100_500','500_900']:
        qrows=[]; yrows=[]; percov=[]; qblock_data=[]; yblock_data=[]
        for cid in IDS:
          o=objs[cid]
          if support=='ALL_RULES': keep=o.old_sixclass if ring=='100_500' else o.new_sixclass
          else: keep=o.old_sixclass&o.new_sixclass
          oo=o.loc[keep].copy(); col='community_'+ring; yc=oo[col].value_counts().reindex(CATS,fill_value=0).to_numpy(float); yrows.append(yc)
          if int(yc.sum())!=int(keep.sum()) or not oo[col].isin(CATS).all(): raise RuntimeError(f'object support/class count mismatch {support} {ring} {cid}')
          bg=pd.read_csv(bgs[cid]); qcol='community_q_'+ring if ring=='500_900' else 'community_q_100_500'; qkeep=bg[qcol].isin(CATS)
          if support=='COMMON_OBJECTS': qkeep &= bg.community_q_100_500.isin(CATS)&bg.community_q_500_900.isin(CATS)
          qarea=bg.loc[qkeep].groupby(qcol).coverage_intersection_area_m2.sum().reindex(CATS,fill_value=0).to_numpy(float); q=qarea/qarea.sum(); qrows.append(q)
          bcol='community_B_'+ring; bk=bg[bcol].isin(CATS)
          if support=='COMMON_OBJECTS': bk &= bg.community_B_100_500.isin(CATS)&bg.community_B_500_900.isin(CATS)
          ba=bg.loc[bk].groupby(bcol).coverage_intersection_area_m2.sum().reindex(CATS,fill_value=0).to_numpy(float); bs=ba/ba.sum(); ys=yc/yc.sum()
          for j,c in enumerate(CATS): desc.append({'support':support,'ring':ring,'coverage_id':cid,'class':c,'object_n':int(yc[j]),'object_share':ys[j],'B_area_m2':ba[j],'B_area_share':bs[j],'q_area_m2':qarea[j],'q_area_share':q[j],'R_count_B':ys[j]/bs[j] if bs[j]>0 else np.nan,'R_count_q':ys[j]/q[j] if q[j]>0 else np.nan})
          percov.append((oo,qkeep,qcol))
          tr=Transformer.from_crs(4326,6933,always_xy=True)
          qb=bg.loc[qkeep,['center_lon','center_lat','coverage_intersection_area_m2',qcol]].copy()
          qx,qy=tr.transform(qb.center_lon.to_numpy(float),qb.center_lat.to_numpy(float)); qb['block']=np.floor(np.asarray(qx)/25000).astype('int64').astype(str)+'_'+np.floor(np.asarray(qy)/25000).astype('int64').astype(str)
          qmat_block=qb.pivot_table(index='block',columns=qcol,values='coverage_intersection_area_m2',aggfunc='sum',fill_value=0).reindex(columns=CATS,fill_value=0)
          ob=oo[['centroid_lon','centroid_lat',col]].copy(); ox,oy=tr.transform(ob.centroid_lon.to_numpy(float),ob.centroid_lat.to_numpy(float)); ob['block']=np.floor(np.asarray(ox)/25000).astype('int64').astype(str)+'_'+np.floor(np.asarray(oy)/25000).astype('int64').astype(str)
          om=ob.pivot_table(index='block',columns=col,values='centroid_lon',aggfunc='count',fill_value=0).reindex(columns=CATS,fill_value=0)
          blocks=qmat_block.index
          if set(om.index)-set(blocks): raise RuntimeError('object block outside q support '+cid)
          qblock_data.append(qmat_block.to_numpy(float)); yblock_data.append(om.reindex(blocks,fill_value=0).to_numpy(float))
        qmat=np.asarray(qrows); ymat=np.asarray(yrows)
        for t,cid in enumerate(IDS):
          beta=fit(qmat[np.arange(13)!=t],ymat[np.arange(13)!=t]); p=pred(qmat[t],beta); obs=ymat[t]/ymat[t].sum(); va=tv(obs,qmat[t]); vp=tv(obs,p); ll=ymat[t].sum()*np.sum(np.where(obs>0,obs*np.log(p/qmat[t]),0))
          folds.append({'support':support,'ring':ring,'coverage_id':cid,'object_n':int(ymat[t].sum()),'TV_area':va,'TV_shared':vp,'absolute_TV_improvement':va-vp,'G':(va-vp)/va if va else np.nan,'delta_LL_total_nats':ll,'delta_LL_per_RTS_nats':ll/int(ymat[t].sum())})
          for j,c in enumerate(CATS): assign.append({'support':support,'ring':ring,'coverage_id':cid,'class':c,'object_total_n':int(ymat[t].sum()),'object_class_n':int(ymat[t,j]),'object_share':obs[j],'q_area_share':qmat[t,j],'shared_prediction':p[j],'beta':beta[j],'R_count_q':obs[j]/qmat[t,j] if qmat[t,j]>0 else np.nan})
        rng=np.random.default_rng(20261407); bootrows=[]
        for rep in range(1,1001):
          qb=[]; yb=[]
          for ba0,yn0 in zip(qblock_data,yblock_data):
            ix=rng.integers(0,len(ba0),size=len(ba0)); qa=ba0[ix].sum(0); yy=yn0[ix].sum(0); qb.append(qa/qa.sum()); yb.append(yy)
          qb=np.asarray(qb); yb=np.asarray(yb); gs=[]
          for t in range(13):
            beta=fit(qb[np.arange(13)!=t],yb[np.arange(13)!=t]); pp=pred(qb[t],beta); obs=yb[t]/yb[t].sum(); va=tv(obs,qb[t]); vp=tv(obs,pp); gs.append((va-vp)/va if va else np.nan)
          bootrows.append({'support':support,'ring':ring,'replicate':rep,'median_G':float(np.nanmedian(gs)),'mean_G':float(np.nanmean(gs)),'positive_G_n':int(np.sum(np.asarray(gs)>0)),'G_by_coverage':'|'.join(f'{v:.10g}' for v in gs),'status':'PASS'})
          if rep%100==0: print('bootstrap',support,ring,rep,'/1000',flush=True)
        pd.DataFrame(bootrows).to_csv(RES/f'BOOTSTRAP_{support}_{ring}.csv',index=False)
        gv=np.array([x['median_G'] for x in bootrows if x['status']=='PASS'],float)
        boot_summaries.append({'support':support,'ring':ring,'replicates_requested':1000,'replicates_finite':int(np.isfinite(gv).sum()),'point_median_G':float(np.nanmedian([x['G'] for x in folds if x['support']==support and x['ring']==ring])),'ci025':float(np.nanquantile(gv,.025)),'ci975':float(np.nanquantile(gv,.975)),'fraction_median_G_positive':float(np.mean(gv>0)),'failed_replicates':int(1000-len(gv))})
        print('point_and_bootstrap_done',support,ring,flush=True)
    newold=pd.DataFrame(folds); oldfit=newold[(newold.support=='ALL_RULES')&(newold.ring=='100_500')].set_index('coverage_id')
    ref=pd.read_csv(BASE/'results'/'TUNDRA13_LOCO_FOLDS.csv').set_index('coverage_id')
    for cid in IDS:
      for col,refcol in [('object_n','heldout_RTS_n'),('TV_area','TV_area'),('TV_shared','TV_shared'),('G','G_shared_reconstruction')]:
        if abs(float(oldfit.loc[cid,col])-float(ref.loc[cid,refcol]))>LOCO_TOL: raise RuntimeError(f'written old-ring LOCO failed baseline gate {cid} {col}')
    rcount_gate=validate_formal_rcount(desc)
    pd.DataFrame(folds).to_csv(RES/'LOCO_13_FOLDS.csv',index=False); pd.DataFrame(assign).to_csv(RES/'LOCO_CLASS_ASSIGNMENTS.csv',index=False); pd.DataFrame(desc).to_csv(RES/'COVERAGE_CLASS_COMPARISON.csv',index=False)
    pd.DataFrame(boot_summaries).to_csv(RES/'SPATIAL_BLOCK_BOOTSTRAP_SUMMARY.csv',index=False)
    (RES/'FORMAL_BASELINE_REPRODUCTION_GATE.json').write_text(json.dumps(baseline_gate,indent=2),encoding='utf-8')
    (RES/'FORMAL_RCOUNT_REPRODUCTION_GATE.json').write_text(json.dumps(rcount_gate,indent=2),encoding='utf-8')

def main():
    if not (RES/'OLD_RING_REPRODUCTION_GATE.json').exists() or json.loads((RES/'OLD_RING_REPRODUCTION_GATE.json').read_text())['status']!='PASS_LABELS': raise RuntimeError('background reproduction gate not passed')
    if not (RES/'OLD_OBJECT_RING_REPRODUCTION_GATE.json').exists() or json.loads((RES/'OLD_OBJECT_RING_REPRODUCTION_GATE.json').read_text())['status']!='PASS_LABELS': raise RuntimeError('object reproduction gate not passed')
    objs,bgs=load_cached_extractions() if '--summarize-cached' in sys.argv else extract_all(); summarize(objs,bgs)
    summary={'input_ids':int(sum(len(o) for o in objs.values())),'old_sixclass_n':int(sum(o.old_sixclass.sum() for o in objs.values())),'new_sixclass_n':int(sum(o.new_sixclass.sum() for o in objs.values())),'common_sixclass_n':int(sum((o.old_sixclass&o.new_sixclass).sum() for o in objs.values())),'bootstrap_replicates_per_ring_and_support':1000}
    (RES/'SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
if __name__=='__main__': main()
