import json
from pathlib import Path
import numpy as np, pandas as pd
import run_ring_sensitivity as R

OUT=R.OUT; RES=R.RES; IDS=R.IDS; CATS=R.CATS

def main():
  support=[]; obj_support=[]; transitions=[]; marginals=[]
  for cid in IDS:
    b=pd.read_csv(RES/f'{cid}_BACKGROUND_500_900.csv')
    for branch,oldcol,newcol in [('B','community_B_100_500','community_B_500_900'),('q','community_q_100_500','community_q_500_900')]:
      old=b[oldcol].isin(CATS); new=b[newcol].isin(CATS); common=old&new; w=b.coverage_intersection_area_m2.astype(float)
      for state,mask in [('ALL_ANCHORS',np.ones(len(b),dtype=bool)),('OLD_ONLY',old&~new),('NEW_ONLY',new&~old),('COMMON_SIXCLASS',common),('NEITHER_SIXCLASS',~old&~new)]:
        support.append({'coverage_id':cid,'background':branch,'support_state':state,'anchor_n':int(mask.sum()),'weighted_area_m2':float(w[mask].sum()),'ring_pixel_n_old':int(b.loc[mask,'ring_pixel_n_B_100_500'].sum()) if branch=='B' else np.nan,'ring_pixel_n_new':int(b.loc[mask,'ring_pixel_n_B_500_900'].sum() if branch=='B' else b.loc[mask,'ring_pixel_n_q_500_900'].sum())})
      for ring,col in [('100_500',oldcol),('500_900',newcol)]:
        pix='ring_pixel_n_B_100_500' if branch=='B' and ring=='100_500' else ('ring_pixel_n_B_500_900' if branch=='B' else ('ring_pixel_n_q_500_900' if ring=='500_900' else None))
        for c in CATS+['EXCLUDED_NON_VEGETATION','NO_DATA_SUPPORT','OTHER']:
          m=b[col].eq(c)
          support.append({'coverage_id':cid,'background':branch,'support_state':'BY_CLASS_'+ring+'_'+c,'anchor_n':int(m.sum()),'weighted_area_m2':float(w[m].sum()),'ring_pixel_n_old':np.nan,'ring_pixel_n_new':int(b.loc[m,pix].sum()) if pix else np.nan})
    o=pd.read_csv(RES/f'{cid}_OBJECT_CROSSWALK.csv')
    oldlab=o.community_100_500.fillna('UNASSIGNED').astype(str); newlab=o.community_500_900.fillna('UNASSIGNED').astype(str)
    tab=pd.crosstab(oldlab,newlab,dropna=False)
    for oldclass in tab.index:
      for newclass in tab.columns:
        n=int(tab.loc[oldclass,newclass])
        if n: transitions.append({'coverage_id':cid,'old_class':oldclass,'new_class':newclass,'object_n':n,'label_retained':oldclass==newclass})
    labels=sorted(set(oldlab)|set(newlab)|set(CATS)|{'OTHER','EXCLUDED_NON_VEGETATION','NO_DATA_SUPPORT','UNASSIGNED'})
    for c in labels:
      no=int((oldlab==c).sum()); nn=int((newlab==c).sum())
      marginals.append({'coverage_id':cid,'class':c,'old_100_500_n':no,'new_500_900_n':nn,'delta_n':nn-no,'old_share_all_ids':no/len(o),'new_share_all_ids':nn/len(o),'delta_share_all_ids':(nn-no)/len(o)})
    for state,mask in [('ALL_IDS',np.ones(len(o),bool)),('OLD_SIXCLASS',o.old_sixclass.to_numpy(bool)),('NEW_SIXCLASS',o.new_sixclass.to_numpy(bool)),('COMMON_SIXCLASS',o.old_sixclass.to_numpy(bool)&o.new_sixclass.to_numpy(bool)),('OLD_ONLY',o.old_sixclass.to_numpy(bool)&~o.new_sixclass.to_numpy(bool)),('NEW_ONLY',~o.old_sixclass.to_numpy(bool)&o.new_sixclass.to_numpy(bool))]:
      obj_support.append({'coverage_id':cid,'support_state':state,'object_n':int(mask.sum())})
    for ring,col in [('100_500','community_100_500'),('500_900','community_500_900')]:
      q=o.loc[o[col].isin(CATS),col].value_counts().reindex(CATS,fill_value=0)
      for c in CATS: obj_support.append({'coverage_id':cid,'support_state':f'CLASS_{ring}_{c}','object_n':int(q[c])})
  pd.DataFrame(support).to_csv(RES/'BACKGROUND_SUPPORT_AUDIT.csv',index=False)
  pd.DataFrame(obj_support).to_csv(RES/'OBJECT_SUPPORT_AUDIT.csv',index=False)
  tr=pd.DataFrame(transitions); mg=pd.DataFrame(marginals)
  tr.to_csv(RES/'OBJECT_CLASS_TRANSITIONS.csv',index=False); mg.to_csv(RES/'OBJECT_CLASS_MARGINALS.csv',index=False)
  total_n=int(sum(x['object_n'] for x in obj_support if x['support_state']=='ALL_IDS'))
  retained_n=int(tr.loc[tr.label_retained,'object_n'].sum()); changed_n=total_n-retained_n
  folds=pd.read_csv(RES/'LOCO_13_FOLDS.csv')
  paired=[]
  for s in folds.support.unique():
    a=folds[(folds.support==s)&(folds.ring=='100_500')].set_index('coverage_id')
    b=folds[(folds.support==s)&(folds.ring=='500_900')].set_index('coverage_id')
    for cid in IDS:
      paired.append({'support':s,'coverage_id':cid,'delta_TV_area_old_minus_new':a.loc[cid,'TV_area']-b.loc[cid,'TV_area'],'delta_TV_shared_old_minus_new':a.loc[cid,'TV_shared']-b.loc[cid,'TV_shared'],'delta_absolute_improvement_old_minus_new':a.loc[cid,'absolute_TV_improvement']-b.loc[cid,'absolute_TV_improvement'],'delta_G_old_minus_new':a.loc[cid,'G']-b.loc[cid,'G'],'delta_LL_total_nats_old_minus_new':a.loc[cid,'delta_LL_total_nats']-b.loc[cid,'delta_LL_total_nats'],'delta_LL_per_RTS_nats_old_minus_new':a.loc[cid,'delta_LL_per_RTS_nats']-b.loc[cid,'delta_LL_per_RTS_nats']})
  pd.DataFrame(paired).to_csv(RES/'LOCO_RING_PAIRED_DIFFERENCES.csv',index=False)
  boot=pd.read_csv(RES/'SPATIAL_BLOCK_BOOTSTRAP_SUMMARY.csv')
  obj=pd.DataFrame(obj_support); bg=pd.DataFrame(support)
  class_summary=[]
  for support_name in folds.support.unique():
    for ring in ['100_500','500_900']:
      dd=pd.read_csv(RES/'COVERAGE_CLASS_COMPARISON.csv'); dd=dd[(dd.support==support_name)&(dd.ring==ring)]
      for bgname,rc in [('B','R_count_B'),('q','R_count_q')]:
        for c in CATS:
          x=dd[dd['class']==c][rc].dropna(); class_summary.append({'support':support_name,'ring':ring,'background':bgname,'class':c,'coverage_n':int(len(x)),'median_R_count':float(x.median()) if len(x) else np.nan,'R_count_gt1_n':int((x>1).sum()),'R_count_lt1_n':int((x<1).sum()),'R_count_eq1_n':int((x==1).sum())})
  class_summary=pd.DataFrame(class_summary); class_summary.to_csv(RES/'CLASS_RCOUNT_DIRECTION_SUMMARY.csv',index=False)
  gate=json.loads((RES/'FORMAL_BASELINE_REPRODUCTION_GATE.json').read_text(encoding='utf-8'))
  rcount_gate=json.loads((RES/'FORMAL_RCOUNT_REPRODUCTION_GATE.json').read_text(encoding='utf-8'))
  marginal_totals=mg.groupby('class')[['old_100_500_n','new_500_900_n','delta_n']].sum().sort_index()
  summary={'coverage_n':13,'object_input_n':int(obj[obj.support_state=='ALL_IDS'].object_n.sum()),'old_sixclass_object_n':int(obj[obj.support_state=='OLD_SIXCLASS'].object_n.sum()),'new_sixclass_object_n':int(obj[obj.support_state=='NEW_SIXCLASS'].object_n.sum()),'common_sixclass_object_n':int(obj[obj.support_state=='COMMON_SIXCLASS'].object_n.sum()),'object_labels_retained_n':retained_n,'object_labels_changed_n':changed_n,'bootstrap_replicates_per_ring_and_support':1000,'formal_baseline_gate':gate['status'],'formal_rcount_gate':rcount_gate['status'],'background_support_file':'BACKGROUND_SUPPORT_AUDIT.csv','object_support_file':'OBJECT_SUPPORT_AUDIT.csv','class_transition_file':'OBJECT_CLASS_TRANSITIONS.csv'}
  (RES/'SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
  lines=['# 500–900 m同步外移环带敏感性结果','', 'ARTIFACT_STATUS：COMPLETE','', '## 执行与样本','',f"- 固定13区；对象输入 {summary['object_input_n']:,} 个。旧100–500 m六类有效 {summary['old_sixclass_object_n']:,} 个；500–900 m六类有效 {summary['new_sixclass_object_n']:,} 个；两环带共同有效 {summary['common_sixclass_object_n']:,} 个。",f"- 对象标签完全保留 {retained_n:,}/{total_n:,}；改变 {changed_n:,}。所有观测到的类别边际变化（旧→新，Δ对象数）：" ]
  for c,row in marginal_totals.iterrows(): lines.append(f"  - {c}: {int(row.old_100_500_n):,} → {int(row.new_500_900_n):,} ({int(row.delta_n):+d})")
  lines += [ '- 类别的逐coverage转移计数见 `OBJECT_CLASS_TRANSITIONS.csv`，逐区及合计边际见 `OBJECT_CLASS_MARGINALS.csv`。', '- 外环对象与背景均直接从本地CGLS-LC100 2019原始栅格重赋值；B保留RTS footprint排除，q不排除RTS footprint。', '- 所有像元使用固定CGLS经纬网格、像元中心和逐中心UTM环带判定；面积权重仍为原500 m网格与coverage相交面积。','- 对象与背景全规则支持、两环带共同有效支持均有单独逐区审计。见 `OBJECT_SUPPORT_AUDIT.csv` 和 `BACKGROUND_SUPPORT_AUDIT.csv`。','- 修复说明：首次派生结果误将新环带有效对象筛选用于旧环带；旧派生结果已移入 `results/INVALID_PRE_FIX_20261026/` 并明确作废。修复后旧环带对象类计数、盲态q、13折LOCO及六类逐区R_count均通过正式基线复现门，见 `FORMAL_BASELINE_REPRODUCTION_GATE.json` 与 `FORMAL_RCOUNT_REPRODUCTION_GATE.json`。','', '## LOCO共享模型','', '下表为13折逐coverage等权的全域摘要；逐区逐类预测、TV、改善量、G和各类R_count见相应CSV。ΔLL总分是整区对象组成的总对数评分差（nats）；同时报告每RTS平均分差（nats/RTS）。','']
  for s in folds.support.unique():
    for ring in ['100_500','500_900']:
      d=folds[(folds.support==s)&(folds.ring==ring)]
      lines.append(f"- {s}, {ring} m：median TV(area)={d.TV_area.median():.4f}，median TV(shared)={d.TV_shared.median():.4f}，median G={d.G.median():.4f}，mean ΔLL={d.delta_LL_per_RTS_nats.mean():.4f} nats/RTS，G>0 {int((d.G>0).sum())}/13。")
  lines+=['','### 六类R_count方向核对','', '逐区逐类B/q的 R_count、对象份额、背景份额和新旧环带差值保存在 `COVERAGE_CLASS_COMPARISON.csv`；方向汇总见 `CLASS_RCOUNT_DIRECTION_SUMMARY.csv`。下表列出各支持×环带×背景分支中 R_count>1 的coverage数及中位R_count。','']
  for r in class_summary.itertuples(index=False): lines.append(f'- {r.support}, {r.ring}, {r.background}, {r[3]}：median R_count={r.median_R_count:.4g}，R_count>1 {r.R_count_gt1_n}/{r.coverage_n}。')
  lines+=['','## 25 km空间块bootstrap','', '每次在coverage内对背景支持的25 km块有放回抽样，同步搬运块内q六类面积与RTS六类计数；每个重复重新拟合13个LOCO折。每个环带×支持集1000次。']
  for r in boot.itertuples(index=False): lines.append(f'- {r.support}, {r.ring} m：median G 95%区间 [{r.ci025:.4f}, {r.ci975:.4f}]；bootstrap median G为正的比例 {r.fraction_median_G_positive:.3f}；成功 {r.replicates_finite}/1000。')
  lines+=['','## 复现与解释边界','', '旧100–500 m背景样本258个锚点的类别标签和旧对象样本78个对象的类别标签均逐项复现；q原文件不含旧逐锚点像元计数。旧缓存像元计数有6处轻微差异（B背景1处、对象5处），均已在复现门JSON/CSV登记，未改变类别。', '本敏感性回答分类与共享预测对同步环带外移的敏感程度；不验证历史滑塌边界，也不构成反向因果或独立现实机制验证。','']
  (OUT/'REPORT_CN.md').write_text('\n'.join(lines),encoding='utf-8')
  run_state=['# RUN STATE','','ARTIFACT_STATUS：COMPLETE','','- upstream_modified: NO','- original_results_or_manuscript_modified: NO','- raster_extraction_repeated_after_bug_fix: NO','- fixed_coverages: 13','- bootstrap: 1000 replicates per ring and support set','- implementation_correction: ALL_RULES selects old_sixclass for 100_500 and new_sixclass for 500_900; COMMON_OBJECTS remains the fixed intersection.','- hard_validation: formal object counts, blind q shares, LOCO TV/G, and six-class B-background R_count all PASS.','- invalid_outputs_preserved: results/INVALID_PRE_FIX_20261026/','- status: See REPORT_CN.md']
  (OUT/'RUN_STATE.md').write_text('\n'.join(run_state)+'\n',encoding='utf-8')
if __name__=='__main__': main()
