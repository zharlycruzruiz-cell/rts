# Correction to the D8 TV summary

The TV improvement point estimate in `paired_bootstrap_summary.csv` and `D8_TABLE_12.csv` is the mean of the 13 region-specific block means: 0.010997960641126105 (0.011 at the table's reported precision). The earlier summary used the mean over all scored blocks, 0.012463120454255659. The original is retained as `paired_bootstrap_summary_original.csv`.

The 95% interval is unchanged: -0.0003480676771712832 to 0.02273298862727413. It was calculated from the existing 5,000 region-then-block bootstrap draws, which use equal regional weights. The block-level scores, bootstrap draws, other estimates and interval limits are unchanged.

The corresponding summary expression in `code/methods/block_models.py` was corrected. The earlier source is retained as `block_models_original.py`. No model was refitted and no new bootstrap samples were generated for this correction.
