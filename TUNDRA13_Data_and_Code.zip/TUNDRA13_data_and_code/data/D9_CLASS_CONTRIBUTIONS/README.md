# Class contribution records

These existing records provide the regional signed class contributions to TV improvement and log-score gain, their closure checks, and aggregate summaries. Negative and zero contributions are retained. They accompany the aggregate tables already present in the JSON files.
