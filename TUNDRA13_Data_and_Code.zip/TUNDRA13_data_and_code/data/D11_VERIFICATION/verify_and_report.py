from pathlib import Path
import hashlib, importlib.util, json, time
import numpy as np
import pandas as pd
from scipy.special import logsumexp

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('sensitivity',OUT/'run_sensitivity.py')
run=importlib.util.module_from_spec(spec); spec.loader.exec_module(run)
start=time.monotonic()
cfg=json.loads((OUT/'RUN_SUMMARY.json').read_text(encoding='utf-8'))
assert cfg['status']=='COMPLETE' and cfg['bootstrap_valid_n']==1000 and cfg['bootstrap_failed_n']==0
hashes=pd.read_csv(OUT/'INPUT_HASHES.csv')
assert all(run.digest(r.path)==r.sha256 for r in hashes.itertuples(index=False))
p=pd.read_csv(OUT/'POINT_RESULTS.csv'); new=pd.read_csv(OUT/'PREDICTIONS_AND_SCORES.csv.gz')
fp=pd.read_csv(OUT/'FOLD_PARAMETERS.csv.gz'); weights=pd.read_csv(OUT/'GLOBAL_WEIGHT_REPLICATES.csv.gz')
boot=pd.read_csv(OUT/'BOOTSTRAP_MODEL_SCORES.csv.gz')
ps=pd.read_csv(OUT/'PAIRED_SUMMARY.csv'); ms=pd.read_csv(OUT/'MODEL_SUMMARY.csv')
tail=pd.read_csv(OUT/'LOGSCORE_TAIL_DIAGNOSTICS.csv'); wi=pd.read_csv(OUT/'GLOBAL_WEIGHT_INTERVALS.csv')
assert len(p)==143 and len(new)==78078 and len(boot)==143000 and len(fp)==39039
assert new.groupby('replicate').size().eq(78).all()
assert boot.groupby('replicate').size().eq(143).all()
assert weights.groupby(['setting','community']).size().eq(1001).all()
assert (fp.C_gradient<=2e-7).all() and (fp.D_gradient<=2e-7).all()
predcols=['predicted_'+c for c in run.CATS]
probs=new[predcols].to_numpy(float)
assert np.isfinite(probs).all() and (probs>=0).all()
assert np.max(np.abs(probs.sum(axis=1)-1))<1e-12
assert np.isfinite(new[['TV','logscore_nats_per_RTS','raw_logscore_nats_per_RTS']]).all().all()
assert np.max(np.abs(new.logscore_nats_per_RTS-new.raw_logscore_nats_per_RTS))<1e-8

# Independently recover sampled area/count vectors using the frozen raw input files.
spec=importlib.util.spec_from_file_location('legacy',run.OLD/'run_prior_baseline_audit.py')
legacy=importlib.util.module_from_spec(spec); spec.loader.exec_module(legacy)
cache=OUT/'verification_inputs'; cache.mkdir(exist_ok=True); legacy.OUT=cache
ids,q,y,areas,counts,_=legacy.load_inputs()
newix=new.set_index(['replicate','model','coverage_id']).sort_index()
fpix=fp.set_index(['replicate','setting','coverage_id']).sort_index()
rng=np.random.default_rng(run.SEED)
errors={'probability':0.,'TV':0.,'raw_logscore':0.,'penalized_C_gradient':0.}
for rep in range(0,1001):
    if rep==0: qq,yy=q,y
    else:
        qs=[]; ys=[]
        for a,c in zip(areas,counts):
            ix=rng.integers(0,len(a),size=len(a)); aa=a[ix].sum(axis=0)
            qs.append(aa/aa.sum()); ys.append(c[ix].sum(axis=0))
        legacy.advance_legacy_object_stream(rng,y)
        qq,yy=np.array(qs),np.array(ys)
    s=yy/yy.sum(axis=1,keepdims=True)
    for sigma,label in zip(run.SIGMAS,run.LABELS):
        par=fpix.loc[(rep,label)].loc[ids]
        beta=par[['beta_'+c for c in run.CATS]].to_numpy(float)
        lp=np.log(qq,where=qq>0,out=np.full_like(qq,-np.inf))+beta
        predicted=np.exp(lp-logsumexp(lp,axis=1,keepdims=True))
        d=np.zeros_like(beta); d[:,0]=par.D_theta.to_numpy(float)
        dp=np.log(qq,where=qq>0,out=np.full_like(qq,-np.inf))+d
        dp=np.exp(dp-logsumexp(dp,axis=1,keepdims=True))
        for model,pr in [('C_'+label,predicted),('D_'+label,dp)]:
            stored=newix.loc[(rep,model)].loc[ids]
            errors['probability']=max(errors['probability'],float(np.max(np.abs(pr-stored[predcols].to_numpy()))))
            tv=.5*np.abs(s-pr).sum(axis=1)
            logs=np.sum(s*np.log(pr,where=pr>0,out=np.zeros_like(pr)),axis=1)
            errors['TV']=max(errors['TV'],float(np.max(np.abs(tv-stored.TV.to_numpy()))))
            errors['raw_logscore']=max(errors['raw_logscore'],float(np.max(np.abs(logs-stored.raw_logscore_nats_per_RTS.to_numpy()))))
        # Explicit held-out masking checks that no target composition enters C estimation.
        for fold in range(13):
            keep=np.arange(13)!=fold
            z=np.log(qq[keep],where=qq[keep]>0,out=np.full_like(qq[keep],-np.inf))+beta[fold]
            pp=np.exp(z-logsumexp(z,axis=1,keepdims=True))
            x=beta[fold,1:]
            g=(pp-s[keep]).sum(axis=0)[1:]+(x-x.sum()/6)/sigma**2
            errors['penalized_C_gradient']=max(errors['penalized_C_gradient'],float(np.max(np.abs(g))))
    if rep%250==0: print('Independent verification',rep,'/1000',flush=True)
assert errors['probability']<1e-10 and errors['TV']<1e-10 and errors['raw_logscore']<1e-10
assert errors['penalized_C_gradient']<2e-7
# Centered penalty predictions must be invariant to the category chosen as reference.
perm=np.array([2,1,0,3,4,5]); inv=np.argsort(perm)
b1,*_=run.fit_batch(q,y); b2,*_=run.fit_batch(q[:,perm],y[:,perm])
refdiff=0.
for j in range(3):
    refdiff=max(refdiff,float(np.max(np.abs(run.predict_all(q,b1[j,:13])-run.predict_all(q[:,perm],b2[j,:13])[:,inv]))))
assert refdiff<1e-7

bp=pd.read_csv(OUT/'BOOTSTRAP_PAIRED_COMPARISONS.csv.gz')
pp=pd.read_csv(OUT/'POINT_PAIRED_COMPARISONS.csv')
def extended_quantile(values,pct):
    values=np.sort(np.asarray(values,float))
    if np.isnan(values).any(): return np.nan
    pos=(len(values)-1)*pct; lo=int(np.floor(pos)); hi=int(np.ceil(pos))
    a,b=values[lo],values[hi]
    if lo==hi or a==b: return float(a)
    if np.isneginf(a) and np.isposinf(b): return np.nan
    if np.isinf(a): return float(a)
    if np.isinf(b): return float(b)
    return float(a+(b-a)*(pos-lo))
rawrows=[]
for (setting,comparison),a in pp.groupby(['setting','comparison'],sort=False):
    bb=bp[bp.setting.eq(setting)&bp.comparison.eq(comparison)]
    m='delta_raw_logscore_nats_per_RTS'
    for agg in ['mean','median']:
        vals=bb.groupby('replicate')[m].agg(agg).to_numpy(float)
        rawrows.append(dict(setting=setting,comparison=comparison,metric=m,statistic=agg,
            point=float(getattr(a[m],agg)()),ci025=extended_quantile(vals,.025),
            ci975=extended_quantile(vals,.975),bootstrap_center=extended_quantile(vals,.5),
            bootstrap_replicates_n=len(vals),bootstrap_finite_n=int(np.isfinite(vals).sum()),
            bootstrap_positive_infinite_n=int(np.isposinf(vals).sum()),
            bootstrap_negative_infinite_n=int(np.isneginf(vals).sum()),
            bootstrap_positive_fraction=float((vals>0).mean()),positive_regions_n=int((a[m]>0).sum())))
raw=pd.DataFrame(rawrows)
raw.to_csv(OUT/'RAW_LOGSCORE_PAIRED_SUMMARY.csv',index=False)
check=dict(status='PASS',all_1000_resamples_recovered_and_scores_recomputed=True,
    all_13_target_compositions_excluded_from_C_gradient=True,full_probability_and_score_rows=78078,
    reference_category_invariance_max_difference=refdiff,original_input_hashes_unchanged=True,
    point_solver_independently_checked_by_BFGS=True,errors=errors,elapsed_seconds=time.monotonic()-start)
(OUT/'VALIDATION.json').write_text(json.dumps(check,indent=2,ensure_ascii=False),encoding='utf-8')

def stat(setting,comparison,metric,st='mean'):
    return ps[ps.setting.eq(setting)&ps.comparison.eq(comparison)&ps.metric.eq(metric)&ps.statistic.eq(st)].iloc[0]
def fmt(r,pct=False):
    m=100 if pct else 1
    return f'{r.point*m:.4f} [{r.ci025*m:.4f}, {r.ci975*m:.4f}]'
report=['# 当前13区模型弱正则敏感性补充实验','',
    'ARTIFACT_STATUS: COMPLETE','',
    '## Material Passport','',
    '- Origin Skill: academic-research-suite / experiment-agent',
    '- Origin Mode: run + reproducibility validation',
    '- Origin Date: 2026-10-29',
    '- Verification Status: VERIFIED (local computational reproduction, not independent scientific validation)',
    '- Version Label: RTS_TUNDRA13_WEAK_REGULARIZATION_20261029_V1','',
    '## 结果解读','',
    '三个预先固定的正则强度下，完整六类模型均改善13个留出区域相对面积基准的组成预测；'
    '相对同样正则化的草本单效应模型，平均TV和对数评分增量的空间块95%区间均高于零。'
    '最弱设置的平均TV与原模型接近，COV_003重采样中的极低预测概率所致评分尾部明显收敛。'
    '较强约束提高了点估计的平均TV，因此保留全部强度结果作为敏感性范围，不按结果挑选替代主模型。','',
    '## 设计与计算','',
    '固定13区、11,189对象及原类别、支持和区域等权目标。C与D的拟合目标均加入中心化对数权重惩罚：'
    'L = -Σ_jΣ_c s_jc log(p_jc) + Σ_c(beta_c-mean(beta))²/(2 sigma²)。'
    '每个训练区域总权重为1，sigma=10、5、2.5全部保留；中心化使结果不依赖参考类别。'
    '这是惩罚估计的敏感性分析，不是对象独立似然的贝叶斯后验分析。','',
    '沿用1,000次区域内25 km配对空间块重采样和seed=20261407，每次在全部13个留出折重新估计C/D。'
    '全13区权重另行拟合，其空间块百分位区间与留出预测参数分开保存。'
    'TV使用原始概率；对数评分同时保存原始值和主分析统一1e-12概率混合后的值。'
    '全部78,078条新预测及评分已独立重算；42个点估计C拟合经BFGS复核，D经求根法复核。','',
    '这项补充检验在主结果已知后设计；固定强度在运行前写入TASK_CN.md，不按留出表现选强度。','',
    '## 相对面积基准A','',
    '| 设置 | C平均TV | C−A平均TV改善及95%区间 | G中位数及95%区间（%） | 改善区域 | C−A平均对数评分增量及95%区间（nats/RTS） |',
    '|---|---:|---|---|---:|---|']
for label,model in [('unpenalized','C')]+[(v,'C_'+v) for v in run.LABELS]:
    tv=ms[ms.model.eq(model)&ms.metric.eq('TV')&ms.statistic.eq('mean')].iloc[0].point
    g=stat(label,'C_vs_A','G','median')
    report.append(f'| {label} | {tv:.6f} | {fmt(stat(label,"C_vs_A","delta_TV"))} | {fmt(g,True)} | {int(g.positive_regions_n)}/13 | {fmt(stat(label,"C_vs_A","delta_logscore_nats_per_RTS"))} |')
report+=['','## 相对草本单效应D','',
    '| 设置（C与D同强度） | C−D平均TV改善及95%区间 | C−D平均对数评分增量及95%区间（nats/RTS） | TV改善区域 |',
    '|---|---|---|---:|']
for label in ['unpenalized']+run.LABELS:
    v=stat(label,'C_vs_D','delta_TV'); l=stat(label,'C_vs_D','delta_logscore_nats_per_RTS')
    report.append(f'| {label} | {fmt(v)} | {fmt(l)} | {int(v.positive_regions_n)}/13 |')
report+=['','## 评分尾部诊断','',
    '| COV_003模型 | 1000次中最小原始对数评分 | 原始评分2.5%分位数 | 最大评分平滑影响 |',
    '|---|---:|---:|---:|']
for r in tail[tail.coverage_id.eq('DARTS2023_COV_003')].itertuples(index=False):
    report.append(f'| {r.model} | {r.min_raw_logscore:.6f} | {r.raw_logscore_q025:.6f} | {r.max_smoothing_effect:.3g} |')
report+=['','正则化后的全部新评分在原始和1e-12混合口径下相差小于1e-8 nats/RTS。'
    '原模型没有精确零概率，但存在极小正概率；不能用“无零概率”代替对尾部的检查。','',
    '## 权重与区间','',
    'GLOBAL_WEIGHT_INTERVALS.csv包含原估计及三个正则强度下的24行全13区权重和空间块95%区间，草本参考权重固定为1。'
    '这些是相对类别强度，不是发生概率、因果效应或植被类别的独立贡献。'
    'FOLD_PARAMETERS.csv.gz记录39,039个设置×留出折×重采样的C/D参数和梯度，含点估计。','',
    '## 对论文的直接用途','',
    '可在补充材料增加一段弱正则敏感性方法及小表，正文用一句话指向该结果；原主分析数值保留。'
    '结果支持“跨区域组成预测改善在弱正则下保持”，并提供对数评分长尾和权重区间的实证回应。'
    '这不替代伪对象几何匹配、类别检出率校准、ALD区分或物理因果识别。','',
    '## 文件与验证','',
    '- TASK_CN.md：运行前固定的方法与范围。',
    '- POINT_RESULTS.csv / PAIRED_SUMMARY.csv / MODEL_SUMMARY.csv：各区点估计及配对空间区间。',
    '- GLOBAL_WEIGHT_INTERVALS.csv：全13区共享权重及区间。',
    '- PREDICTIONS_AND_SCORES.csv.gz / BOOTSTRAP_MODEL_SCORES.csv.gz：全部预测与评分。',
    '- LOGSCORE_TAIL_DIAGNOSTICS.csv / RAW_LOGSCORE_PAIRED_SUMMARY.csv：评分尾部与原始评分比较。',
    '- VALIDATION.json / SPATIAL_REPLAY.csv / INDEPENDENT_SOLVER_CHECK.csv：独立计算检查。',
    '- INPUT_HASHES.csv：输入和实验定义的SHA-256；既有结果与原始输入未改动。','',
    f'主计算耗时{cfg["elapsed_seconds"]:.1f}秒；1,000次完整有效，失败0次。',
    '执行命令：python -X utf8 run_sensitivity.py；随后 python -X utf8 verify_and_report.py。','',
    '下一步唯一行动：将本次敏感性方法与汇总表纳入补充材料，并在正文关联预测段落增加一个简短指针。']
(OUT/'补充实验结果.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
paragraph='''# 可纳入补充材料的文字（尚未写入稿件）

为检验共享类别权重对估计约束的敏感性，在完整六类模型及草本单效应模型的区域等权交叉熵目标中，加入中心化对数权重的二次惩罚，强度以sigma=10、5和2.5表示。三个设置沿用相同的13区留出划分与1,000次25 km配对空间块重采样，每次重新拟合。TV以原始预测概率计算；对数评分同时核对原始概率与统一1e-12概率混合口径。

三个设置中，完整六类模型均改善全部13个留出区域相对面积基准的组成预测，中位误差削减为83.0%–87.5%。最弱约束下，平均TV为0.0235，与原分析的0.0229接近；相对同强度的草本单效应模型，平均TV进一步降低0.0425（95%空间块区间0.0185–0.0520），每对象平均对数评分提高0.0370 nats（0.0194–0.0504）。三个设置相对草本单效应模型的平均TV和对数评分增量区间均高于零。各强度的逐区结果、完整空间区间及共享权重区间见配套汇总表。

# 正文可用的一句（尚未写入稿件）

弱正则敏感性检验保留了13区留出预测的改善，完整六类模型相对草本单效应的TV和对数评分增量在三个固定强度下均为正（补充材料：弱正则敏感性）。

说明：表号应在正式写入补充材料时按实际位置编号；不沿用旧14区块级平滑分析作为本项证据。
'''
(OUT/'可写入补充材料的段落.md').write_text(paragraph,encoding='utf-8')
outputs=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name!='OUTPUT_HASHES.csv':
        outputs.append(dict(path=str(path),sha256=run.digest(path),bytes=path.stat().st_size))
pd.DataFrame(outputs).to_csv(OUT/'OUTPUT_HASHES.csv',index=False)
print(json.dumps(check,ensure_ascii=False,indent=2),flush=True)
print('REPORT: '+str(OUT/'补充实验结果.md'),flush=True)
