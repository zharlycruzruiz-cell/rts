from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import hashlib, importlib.util, json, sys, time, traceback
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize, brentq
from scipy.special import logsumexp, expit

OUT = Path(__file__).resolve().parent
ROUND = OUT.parent
OLD = ROUND / 'RTS_TUNDRA13_PRIOR_BASELINE_AUDIT_V1'
BASE = ROUND / 'RTS_TUNDRA13_FULL_REANALYSIS_V1'
SIGMAS = np.array([10., 5., 2.5])
NBOOT, SEED, EPS = 1000, 20261407, 1e-12
CATS = ['GRASS_HERBACEOUS','SHRUB','MOSS_LICHEN','FOREST','WETLAND','SPARSE_BARE']
LABELS = ['sigma_10', 'sigma_5', 'sigma_2p5']
P = np.eye(5)-np.ones((5,5))/6

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def logq(q):
    z=np.full_like(q,-np.inf); np.log(q,out=z,where=q>0); return z

def fit_batch(q,y):
    """42 joint jobs: 3 fixed sigmas x (13 LOCO fits + one all-region fit)."""
    s=y/y.sum(axis=1,keepdims=True)
    masks=np.vstack([1-np.eye(13),np.ones((1,13))])
    masks=np.tile(masks,(3,1)); lam=np.repeat(1/SIGMAS**2,14)
    lq=logq(q)[None,:,:]
    def objective(x,deriv=False):
        beta=np.column_stack([np.zeros(len(x)),x]); z=lq+beta[:,None,:]
        lp=z-logsumexp(z,axis=2,keepdims=True); p=np.exp(lp)
        ll=-np.sum(np.sum(s[None,:,:]*np.where(s[None,:,:]>0,lp,0),axis=2)*masks,axis=1)
        loss=ll+.5*lam*np.einsum('ni,ij,nj->n',x,P,x)
        if not deriv: return loss
        g=np.sum((p-s[None,:,:])*masks[:,:,None],axis=1)[:,1:]+lam[:,None]*(x@P)
        pp=p[:,:,1:]
        diag=np.sum(pp*masks[:,:,None],axis=1)
        h=-np.einsum('nri,nrj,nr->nij',pp,pp,masks)+lam[:,None,None]*P
        h[:,np.arange(5),np.arange(5)]+=diag
        return loss,g,h
    x=np.zeros((42,5))
    for it in range(80):
        loss,g,h=objective(x,True)
        active=np.max(np.abs(g),axis=1)>1e-10
        if not active.any(): break
        step=np.linalg.solve(h,g[...,None])[...,0]; step[~active]=0
        t=np.ones(42); gd=np.sum(g*step,axis=1)
        for ls in range(40):
            candidate=x-t[:,None]*step
            ok=objective(candidate)<=loss-1e-4*t*gd+2e-14
            if ok.all(): break
            t[~ok]*=.5
        x=candidate
    loss,g,h=objective(x,True)
    if not np.isfinite(x).all() or np.max(np.abs(g))>2e-7:
        raise RuntimeError('penalized C gradient failed: '+str(np.max(np.abs(g))))
    beta=np.column_stack([np.zeros(42),x]).reshape(3,14,6)
    # D occupies the same six-category log-weight space, with only grass differing.
    a=q[:,0]; mixed=(a>0)&(a<1)
    offsets=np.zeros(13); offsets[mixed]=np.log(a[mixed])-np.log1p(-a[mixed])
    theta=np.zeros(42); lmd=lam*5/6
    for _ in range(80):
        pred=np.broadcast_to(a,(42,13)).copy()
        pred[:,mixed]=expit(offsets[mixed][None,:]+theta[:,None])
        dg=np.sum((pred-s[None,:,0])*masks,axis=1)+lmd*theta
        dh=np.sum(pred*(1-pred)*masks,axis=1)+lmd
        if np.max(np.abs(dg))<1e-10: break
        theta-=np.clip(dg/dh,-5,5)
    if np.max(np.abs(dg))>2e-7: raise RuntimeError('penalized D gradient failed')
    return beta,theta.reshape(3,14),np.max(np.abs(g),axis=1).reshape(3,14),np.abs(dg).reshape(3,14)

def fit_global_unpenalized(q,y):
    s=y/y.sum(axis=1,keepdims=True); lq=logq(q)
    def fg(x):
        z=lq+np.r_[0.,x]; lp=z-logsumexp(z,axis=1,keepdims=True)
        loss=-np.mean(np.sum(s*np.where(s>0,lp,0),axis=1))
        return loss,np.mean(np.exp(lp)-s,axis=0)[1:]
    r=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':1000})
    g=fg(r.x)[1]
    if not np.isfinite(r.x).all() or np.max(np.abs(g))>2e-6:
        raise RuntimeError('unpenalized all-region weight fit failed')
    return np.r_[0.,r.x],float(np.max(np.abs(g)))

def predict_all(q,b):
    z=logq(q)+b; return np.exp(z-logsumexp(z,axis=1,keepdims=True))

def metric_rows(q,y,p,ids,model,rep):
    s=y/y.sum(axis=1,keepdims=True); support=q>0
    p=p.copy(); p[~support]=0; p/=p.sum(axis=1,keepdims=True)
    ps=(1-EPS)*p+EPS*support/support.sum(axis=1,keepdims=True)
    rows=[]
    for i,cid in enumerate(ids):
        active=s[i]>0
        raw=float(np.sum(s[i,active]*np.log(p[i,active]))) if np.all(p[i,active]>0) else -np.inf
        rows.append(dict(replicate=rep,coverage_id=cid,model=model,
            TV=float(.5*np.abs(s[i]-p[i]).sum()),
            logscore_nats_per_RTS=float(np.sum(s[i,active]*np.log(ps[i,active]))),
            raw_logscore_nats_per_RTS=raw,
            min_positive_probability=float(p[i,p[i]>0].min()),
            min_observed_probability=float(p[i,active].min()),
            **{'predicted_'+c:float(p[i,j]) for j,c in enumerate(CATS)}))
    return rows

def paired(df):
    rows=[]
    for label in ['unpenalized']+LABELS:
        cm='C' if label=='unpenalized' else 'C_'+label
        dm='D' if label=='unpenalized' else 'D_'+label
        for cand,ref in [(cm,'A'),(cm,'B_equal'),(cm,'B_object'),(cm,dm),(dm,'A')]:
            a=df[df.model.eq(cand)].set_index(['replicate','coverage_id'])
            b=df[df.model.eq(ref)].set_index(['replicate','coverage_id']).reindex(a.index)
            z=pd.DataFrame({'delta_TV':b.TV-a.TV,
              'delta_logscore_nats_per_RTS':a.logscore_nats_per_RTS-b.logscore_nats_per_RTS,
              'delta_raw_logscore_nats_per_RTS':a.raw_logscore_nats_per_RTS-b.raw_logscore_nats_per_RTS,
              'G':(b.TV-a.TV)/b.TV}).reset_index()
            z['setting']=label; z['comparison']=('D_vs_A' if cand==dm else 'C_vs_'+('D' if ref==dm else ref))
            rows.append(z)
    return pd.concat(rows,ignore_index=True)

def summaries(point,boot,keys,metrics):
    rows=[]
    for name,a in point.groupby(keys,sort=False):
        name=name if isinstance(name,tuple) else (name,)
        mask=np.ones(len(boot),bool)
        for k,v in zip(keys,name): mask &= boot[k].eq(v).to_numpy()
        b=boot[mask]
        for m in metrics:
            for stat in ['mean','median']:
                v=float(getattr(a[m],stat)()); vals=b.groupby('replicate')[m].agg(stat)
                finite=np.isfinite(vals.to_numpy())
                rows.append(dict(zip(keys,name),metric=m,statistic=stat,point=v,
                  ci025=float(vals.quantile(.025)),ci975=float(vals.quantile(.975)),
                  bootstrap_center=float(vals.median()),bootstrap_replicates_n=len(vals),
                  bootstrap_finite_n=int(finite.sum()),bootstrap_positive_fraction=float((vals>0).mean()),
                  positive_regions_n=int((a[m]>0).sum())))
    return pd.DataFrame(rows)

def main():
    start=time.monotonic()
    if (OUT/'RUN_SUMMARY.json').exists(): raise RuntimeError('Existing completed run; do not overwrite')
    if 'ARTIFACT_STATUS: COMPLETE' not in (OLD/'TUNDRA13_PRIOR_BASELINE_AUDIT.md').read_text(encoding='utf-8'):
        raise RuntimeError('upstream incomplete')
    index=pd.read_csv(OLD/'OUTPUT_HASHES.csv')
    for name in ['POINT_RESULTS.csv','BOOTSTRAP_MODEL_REPLICATES.csv','FORMAL_SPATIAL_BOOTSTRAP_REPLAY.csv','run_prior_baseline_audit.py']:
        rr=index[index.path.eq(str(OLD/name))]
        if len(rr)!=1 or digest(OLD/name)!=rr.iloc[0].sha256: raise RuntimeError('historical hash mismatch '+name)
    spec=importlib.util.spec_from_file_location('legacy',OLD/'run_prior_baseline_audit.py')
    legacy=importlib.util.module_from_spec(spec); spec.loader.exec_module(legacy)
    legacy.OUT=OUT
    ids,q,y,areas,counts,hashes=legacy.load_inputs()
    oldpoint=pd.read_csv(OLD/'POINT_RESULTS.csv')
    oldboot=pd.read_csv(OLD/'BOOTSTRAP_MODEL_REPLICATES.csv')
    extra=[OLD/n for n in ['POINT_RESULTS.csv','BOOTSTRAP_MODEL_REPLICATES.csv','FORMAL_SPATIAL_BOOTSTRAP_REPLAY.csv','run_prior_baseline_audit.py','OUTPUT_HASHES.csv']]
    hashes += [dict(path=str(p),sha256=digest(p),role='historical_replay') for p in extra]
    hashes += [dict(path=str(OUT/n),sha256=digest(OUT/n),role='new_analysis_definition') for n in ['TASK_CN.md','run_sensitivity.py']]
    pd.DataFrame(hashes).to_csv(OUT/'INPUT_HASHES.csv',index=False)
    replay_point,_,_=legacy.evaluate(q,y,ids)
    max_point=float(np.max(np.abs(replay_point.TV.to_numpy()-oldpoint.TV.to_numpy())))
    if max_point>1e-6: raise RuntimeError('point replay failed')
    oldreplay=pd.read_csv(OLD/'FORMAL_SPATIAL_BOOTSTRAP_REPLAY.csv')
    if len(oldreplay)!=1000 or oldreplay.abs_difference.max()>1e-6: raise RuntimeError('historical C replay gate')
    print('Input hashes, 13 regions / 11189 objects, original point replay: PASS',flush=True)
    predictions=[]; params=[]; weights=[]; failures=[]; replay=[]
    betas,thetas,grads,dgrads=fit_batch(q,y)
    check=[]
    for si,(sigma,label) in enumerate(zip(SIGMAS,LABELS)):
        for fold in range(14):
            keep=np.arange(13)!=fold if fold<13 else np.ones(13,bool)
            qq=q[keep]; ss=y[keep]/y[keep].sum(axis=1,keepdims=True); lq=logq(qq); lam=1/sigma**2
            def fg(x):
                z=lq+np.r_[0.,x]; lp=z-logsumexp(z,axis=1,keepdims=True)
                return (-np.sum(ss*np.where(ss>0,lp,0))+.5*lam*(x@P@x),
                    np.sum(np.exp(lp)-ss,axis=0)[1:]+lam*(P@x))
            r=minimize(fg,np.zeros(5),jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':2000})
            diff=float(np.max(np.abs(predict_all(qq,np.r_[0.,r.x])-predict_all(qq,betas[si,fold]))))
            if diff>1e-6: raise RuntimeError('independent BFGS point check failed')
            aa=qq[:,0]; gg=ss[:,0]; mixed=(aa>0)&(aa<1)
            offsets=np.log(aa[mixed])-np.log1p(-aa[mixed])
            def dg(t):
                pr=aa.copy(); pr[mixed]=expit(offsets+t)
                return float(np.sum(pr-gg)+lam*5/6*t)
            other=brentq(dg,-100,100,xtol=1e-12)
            if abs(other-thetas[si,fold])>1e-6: raise RuntimeError('independent D check')
            check.append(dict(setting=label,fold=fold,max_prediction_difference_BFGS=diff,D_theta_difference=abs(other-thetas[si,fold])))
    pd.DataFrame(check).to_csv(OUT/'INDEPENDENT_SOLVER_CHECK.csv',index=False)
    def collect(rep,qq,yy,b,t,g,dg):
        for si,label in enumerate(LABELS):
            p=predict_all(qq,b[si,:13]); d=np.zeros((13,6)); d[:,0]=t[si,:13]
            predictions.extend(metric_rows(qq,yy,p,ids,'C_'+label,rep))
            predictions.extend(metric_rows(qq,yy,predict_all(qq,d),ids,'D_'+label,rep))
            for f,cid in enumerate(ids):
                params.append(dict(replicate=rep,setting=label,coverage_id=cid,C_gradient=g[si,f],D_gradient=dg[si,f],
                    D_theta=t[si,f],**{'beta_'+c:float(b[si,f,j]) for j,c in enumerate(CATS)}))
            for j,c in enumerate(CATS): weights.append(dict(replicate=rep,setting=label,community=c,beta=float(b[si,13,j]),weight=float(np.exp(b[si,13,j]))))
        ub,ug=fit_global_unpenalized(qq,yy)
        for j,c in enumerate(CATS): weights.append(dict(replicate=rep,setting='unpenalized',community=c,beta=float(ub[j]),weight=float(np.exp(ub[j]))))
    collect(0,q,y,betas,thetas,grads,dgrads)
    original_point=oldpoint.copy(); original_point['replicate']=0
    rng=np.random.default_rng(SEED)
    for rep in range(1,NBOOT+1):
        if time.monotonic()-start>1800: raise TimeoutError('30 minute hard timeout')
        qs=[]; ys=[]
        for a,c in zip(areas,counts):
            ix=rng.integers(0,len(a),size=len(a)); aa=a[ix].sum(axis=0); yy=c[ix].sum(axis=0)
            qs.append(aa/aa.sum()); ys.append(yy)
        legacy.advance_legacy_object_stream(rng,y)
        qq=np.asarray(qs); yy=np.asarray(ys)
        ref=oldboot[oldboot.replicate.eq(rep)&oldboot.model.eq('A')].set_index('coverage_id').loc[ids]
        am=metric_rows(qq,yy,qq,ids,'A',rep)
        atv=np.array([a['TV'] for a in am]); allv=np.array([a['logscore_nats_per_RTS'] for a in am])
        diff=max(float(np.max(np.abs(atv-ref.TV.to_numpy()))),float(np.max(np.abs(allv-ref.logscore_nats_per_RTS.to_numpy()))))
        if diff>1e-10: raise RuntimeError('spatial draw A replay gate failed '+str(rep))
        replay.append(dict(replicate=rep,max_A_TV_logscore_difference=diff,original_C_median_G_difference=float(oldreplay.set_index('replicate').loc[rep,'abs_difference'])))
        try:
            if np.any(yy.sum(axis=1)<=0) or np.any((qq==0)&(yy>0)): raise ValueError('nonestimable sample support')
            b,t,g,dg=fit_batch(qq,yy); collect(rep,qq,yy,b,t,g,dg)
        except Exception as e:
            failures.append(dict(replicate=rep,reason=str(e)))
        if rep%50==0:
            progress=dict(completed_resamples=rep,requested=NBOOT,failed=len(failures),elapsed_seconds=time.monotonic()-start)
            (OUT/'PROGRESS.json').write_text(json.dumps(progress),encoding='utf-8')
            print(json.dumps(progress),flush=True)
    new=pd.DataFrame(predictions); pd.DataFrame(params).to_csv(OUT/'FOLD_PARAMETERS.csv.gz',index=False,compression='gzip')
    new.to_csv(OUT/'PREDICTIONS_AND_SCORES.csv.gz',index=False,compression='gzip')
    valid=new[new.replicate>0].groupby('replicate').size()
    valid_ids=valid[valid.eq(78)].index
    pd.DataFrame(failures,columns=['replicate','reason']).to_csv(OUT/'FAILURE_LOG.csv',index=False)
    pd.DataFrame(replay).to_csv(OUT/'SPATIAL_REPLAY.csv',index=False)
    if len(valid_ids)!=1000: raise RuntimeError('Incomplete sensitivity: '+str(len(valid_ids))+' complete replicates; see failures')
    point=pd.concat([original_point,new[new.replicate.eq(0)]],ignore_index=True)
    boot=pd.concat([oldboot,new[new.replicate.gt(0)]],ignore_index=True)
    cols=['replicate','coverage_id','model','TV','logscore_nats_per_RTS','raw_logscore_nats_per_RTS']
    point.to_csv(OUT/'POINT_RESULTS.csv',index=False)
    boot[cols].to_csv(OUT/'BOOTSTRAP_MODEL_SCORES.csv.gz',index=False,compression='gzip')
    pp=paired(point); bp=paired(boot)
    pp.to_csv(OUT/'POINT_PAIRED_COMPARISONS.csv',index=False)
    bp.to_csv(OUT/'BOOTSTRAP_PAIRED_COMPARISONS.csv.gz',index=False,compression='gzip')
    ps=summaries(pp,bp,['setting','comparison'],['delta_TV','delta_logscore_nats_per_RTS','G'])
    ms=summaries(point,boot,['model'],['TV','logscore_nats_per_RTS'])
    ps.to_csv(OUT/'PAIRED_SUMMARY.csv',index=False); ms.to_csv(OUT/'MODEL_SUMMARY.csv',index=False)
    w=pd.DataFrame(weights); w.to_csv(OUT/'GLOBAL_WEIGHT_REPLICATES.csv.gz',index=False,compression='gzip')
    wr=[]
    for (setting,cat),a in w.groupby(['setting','community'],sort=False):
        v=a[a.replicate.eq(0)].iloc[0]; bb=a[a.replicate.gt(0)]
        wr.append(dict(setting=setting,community=cat,point_beta=v.beta,point_weight=v.weight,
          beta_ci025=bb.beta.quantile(.025),beta_ci975=bb.beta.quantile(.975),
          weight_ci025=bb.weight.quantile(.025),weight_ci975=bb.weight.quantile(.975),bootstrap_n=len(bb)))
    pd.DataFrame(wr).to_csv(OUT/'GLOBAL_WEIGHT_INTERVALS.csv',index=False)
    tail=[]
    for (cid,model),a in boot.groupby(['coverage_id','model'],sort=False):
        if not model.startswith('C'): continue
        tail.append(dict(coverage_id=cid,model=model,min_raw_logscore=a.raw_logscore_nats_per_RTS.min(),
          raw_logscore_q025=a.raw_logscore_nats_per_RTS.quantile(.025),raw_logscore_median=a.raw_logscore_nats_per_RTS.median(),
          min_finite_logscore=a.logscore_nats_per_RTS.min(),finite_logscore_q025=a.logscore_nats_per_RTS.quantile(.025),
          max_smoothing_effect=(a.logscore_nats_per_RTS-a.raw_logscore_nats_per_RTS).max(),
          exact_negative_infinite_scores=int(np.isneginf(a.raw_logscore_nats_per_RTS).sum())))
    pd.DataFrame(tail).to_csv(OUT/'LOGSCORE_TAIL_DIAGNOSTICS.csv',index=False)
    cfg=dict(status='COMPLETE',date='2026-10-29',coverage_n=13,RTS_n=int(y.sum()),grass_RTS_n=int(y[:,0].sum()),
      sigma_settings=SIGMAS.tolist(),bootstrap_n=NBOOT,bootstrap_valid_n=len(valid_ids),bootstrap_failed_n=len(failures),
      bootstrap_seed=SEED,max_point_replay_difference=max_point,max_A_spatial_replay_difference=max(r['max_A_TV_logscore_difference'] for r in replay),
      input_hashes_unchanged=all(digest(r['path'])==r['sha256'] for r in hashes),elapsed_seconds=time.monotonic()-start,
      interpretation='post-hoc sensitivity; no strength selected using held-out scores; no new independent validation',
      python=sys.version,numpy=np.__version__,pandas=pd.__version__)
    if not cfg['input_hashes_unchanged']: raise RuntimeError('inputs changed')
    (OUT/'RUN_SUMMARY.json').write_text(json.dumps(cfg,indent=2,ensure_ascii=False),encoding='utf-8')
    print('COMPLETE '+json.dumps(cfg,ensure_ascii=False),flush=True)

if __name__=='__main__':
    try: main()
    except BaseException:
        (OUT/'ERROR.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise
