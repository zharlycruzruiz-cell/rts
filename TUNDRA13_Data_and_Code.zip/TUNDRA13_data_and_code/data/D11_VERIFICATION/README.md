# Existing independent numerical verification

The 42 point-fit checks in INDEPENDENT_SOLVER_CHECK.csv cover three fixed regularization strengths and 14 fits per strength (13 held-out regions plus the full-region fit). The original VALIDATION.json and SPATIAL_REPLAY.csv describe the saved probability, score, gradient and resampling checks. These records were restored from the existing analysis; they are not a new independent empirical validation or a newly performed computation.

The numerical datasets they check are already supplied as bootstrap_scores.csv.xz, regularized_predictions.csv.xz, fold_parameters.csv.xz and weight_replicates.csv.xz. Their decompressed bytes match the corresponding original GZIP datasets exactly.

The two original Python scripts are retained as verification source records, including their original upstream dependencies and path references. They are not additional portable entry points; the portable model runner remains code/reproduce.py.
