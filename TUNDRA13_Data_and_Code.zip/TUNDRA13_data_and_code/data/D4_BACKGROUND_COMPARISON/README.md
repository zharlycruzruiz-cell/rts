# Background comparison records

The original anchor-level change file contains the 39 records whose class or six-class inclusion differs between B and q: 12 matched anchors change class, 26 enter q support and one leaves it. Unchanged anchors are not duplicated. Weights are square metres; the coverage/class comparison reports square kilometres and percentage-point differences. `_merge` is the B/q join status; missing class/weight fields indicate absence from that six-class support. Source files were copied without changing their contents.
