# Additional composition and slope checks

The class-identity check contains all 720 permutations and its original summary. This is distinct from the region-label distance-matrix permutation, whose saved result is also included. Neither replaces the other.

SLOPE contains the original regional densities and ratio records, regional block intervals, equal-region summaries, support diagnostics and frozen parameters. The exploratory interaction is `E_INTERACTION_LOW_OVER_HIGH`; both PRIMARY_COVERAGE_SLOPE and STRICT_BLOCK_COMMON_SUPPORT are retained. Zero, infinite and undefined ratios retain their original statuses. GAM and GBM use the same slope-margin counts and areas and are not independent replications. Their resampling intervals are retained separately. The GAM primary interaction is 0.4662761554 with a 95% interval of 0 to 1.1840153723; the interval includes one. This exploratory result is not evidence of a robust interaction.
